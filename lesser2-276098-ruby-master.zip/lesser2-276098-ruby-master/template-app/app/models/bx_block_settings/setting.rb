module BxBlockSettings
  class Setting < ApplicationRecord

    self.table_name = :settings

  end
end
