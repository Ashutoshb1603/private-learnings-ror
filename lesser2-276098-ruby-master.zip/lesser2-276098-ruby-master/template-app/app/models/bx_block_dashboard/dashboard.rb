module BxBlockDashboard
  class Dashboard < BxBlockDashboard::ApplicationRecord
    self.table_name = :dashboards
  end
end

