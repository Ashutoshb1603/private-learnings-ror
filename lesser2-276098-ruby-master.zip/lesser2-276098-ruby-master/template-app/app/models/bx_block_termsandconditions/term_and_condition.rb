module BxBlockTermsandconditions
  class TermAndCondition < ApplicationRecord
    self.table_name = :term_and_conditions
  end
end
