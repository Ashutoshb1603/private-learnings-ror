module BxBlockInvitefriends
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
