module BxBlockMatchalgorithm2
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
