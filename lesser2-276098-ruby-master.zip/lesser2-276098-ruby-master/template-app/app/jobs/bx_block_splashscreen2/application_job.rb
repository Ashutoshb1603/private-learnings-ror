module BxBlockSplashscreen2
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
