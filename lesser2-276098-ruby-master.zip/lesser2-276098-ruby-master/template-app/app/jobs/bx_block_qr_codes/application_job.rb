module BxBlockQrCodes
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
