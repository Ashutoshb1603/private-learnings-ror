module BxBlockCameraaccess2
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
