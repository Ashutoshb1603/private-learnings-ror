module BxBlockCftimelinehistory
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
