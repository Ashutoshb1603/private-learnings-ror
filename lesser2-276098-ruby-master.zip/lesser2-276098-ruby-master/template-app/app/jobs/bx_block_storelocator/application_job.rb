module BxBlockStorelocator
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
