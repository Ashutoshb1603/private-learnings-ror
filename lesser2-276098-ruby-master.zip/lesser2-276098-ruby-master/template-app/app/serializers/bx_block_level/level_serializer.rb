module BxBlockLevel
  class LevelSerializer < BuilderBase::BaseSerializer
  end
end
