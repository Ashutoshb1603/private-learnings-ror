
Rename this folder to `tests` and push your changes to run.