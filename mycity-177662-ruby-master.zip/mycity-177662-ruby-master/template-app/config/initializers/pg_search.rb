PgSearch.multisearch_options = {
  using: {
    tsearch: { prefix: true }
  }
}