module BxBlockUsergroups
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
