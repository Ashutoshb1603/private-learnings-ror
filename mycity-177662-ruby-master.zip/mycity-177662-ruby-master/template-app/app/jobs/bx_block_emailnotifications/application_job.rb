module BxBlockEmailnotifications
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
