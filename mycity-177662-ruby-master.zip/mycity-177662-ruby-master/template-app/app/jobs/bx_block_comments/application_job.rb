module BxBlockComments
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
