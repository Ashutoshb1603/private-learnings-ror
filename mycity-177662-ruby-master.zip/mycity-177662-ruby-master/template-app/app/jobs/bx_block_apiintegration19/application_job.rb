module BxBlockApiintegration19
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
