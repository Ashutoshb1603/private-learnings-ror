module BxBlockEventregistration
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
