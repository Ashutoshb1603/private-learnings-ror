module BxBlockAdmin
  class ApplicationController < BuilderBase::ApplicationController
    # protect_from_forgery with: :exception
  end
end
