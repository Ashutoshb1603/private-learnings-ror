module BxBlockChat
  class MessagesController < BxBlockChat::ApplicationController
  end
end
