# frozen_string_literal: true

module BxBlockProfileBio
  module ApplicationHelper
  end
end
