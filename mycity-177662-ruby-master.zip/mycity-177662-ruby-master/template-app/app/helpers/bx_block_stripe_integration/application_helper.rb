module BxBlockStripeIntegration
  module ApplicationHelper
  end
end
