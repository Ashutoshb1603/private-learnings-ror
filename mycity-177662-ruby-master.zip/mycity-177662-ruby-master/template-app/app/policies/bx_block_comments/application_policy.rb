module BxBlockComments
  class ApplicationPolicy < ::ApplicationPolicy
  end
end
