module BxBlockCategories
  def self.table_name_prefix
    'bx_block_categories_'
  end
end
