module BxBlockAdmin
  def self.table_name_prefix
    'bx_block_admin_'
  end
end
