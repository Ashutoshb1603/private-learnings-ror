module BxBlockInterests
  def self.table_name_prefix
    'bx_block_interests_'
  end
end
