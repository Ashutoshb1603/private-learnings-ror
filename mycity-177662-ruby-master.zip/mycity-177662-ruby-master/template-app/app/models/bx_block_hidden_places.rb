module BxBlockHiddenPlaces
  def self.table_name_prefix
    'bx_block_hidden_places_'
  end
end
