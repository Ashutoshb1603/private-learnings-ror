module BxBlockItemavailability
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
