module BxBlockProductdescription
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
