module BxBlockLandingpage
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
