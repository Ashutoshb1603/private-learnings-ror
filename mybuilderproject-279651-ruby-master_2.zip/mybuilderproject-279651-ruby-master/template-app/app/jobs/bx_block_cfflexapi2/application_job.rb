module BxBlockCfflexapi2
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
