module BxBlockDashboard
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
