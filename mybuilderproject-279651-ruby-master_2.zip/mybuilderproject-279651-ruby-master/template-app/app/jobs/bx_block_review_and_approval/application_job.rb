module BxBlockReviewAndApproval
  class ApplicationJob < ActiveJob::Base
  end
end
