module BxBlockStripeIntegration
  class ApplicationJob < ActiveJob::Base
  end
end
