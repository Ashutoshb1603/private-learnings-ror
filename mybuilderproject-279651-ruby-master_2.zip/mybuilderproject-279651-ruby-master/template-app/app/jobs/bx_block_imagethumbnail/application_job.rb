module BxBlockImagethumbnail
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
