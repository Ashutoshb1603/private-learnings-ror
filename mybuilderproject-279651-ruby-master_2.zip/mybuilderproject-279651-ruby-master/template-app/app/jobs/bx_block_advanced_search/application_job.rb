module BxBlockAdvancedSearch
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
