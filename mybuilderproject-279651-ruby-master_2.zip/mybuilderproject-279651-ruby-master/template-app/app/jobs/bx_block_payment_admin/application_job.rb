module BxBlockPaymentAdmin
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
