module BxBlockTermsandconditions3
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
