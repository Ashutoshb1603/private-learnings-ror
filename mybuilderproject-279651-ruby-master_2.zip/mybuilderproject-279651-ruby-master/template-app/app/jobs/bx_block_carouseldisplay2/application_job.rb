module BxBlockCarouseldisplay2
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
