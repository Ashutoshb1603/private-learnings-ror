module BxBlockAnalytics3
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
