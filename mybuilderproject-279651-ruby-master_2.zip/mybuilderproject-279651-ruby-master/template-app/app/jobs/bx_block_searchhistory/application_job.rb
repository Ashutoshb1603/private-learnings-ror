module BxBlockSearchhistory
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
