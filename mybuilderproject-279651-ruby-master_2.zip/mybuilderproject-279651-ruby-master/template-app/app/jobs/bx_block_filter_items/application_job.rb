module BxBlockFilterItems
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
