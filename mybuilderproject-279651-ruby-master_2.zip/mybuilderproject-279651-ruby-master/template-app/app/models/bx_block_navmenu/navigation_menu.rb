module BxBlockNavmenu
  class NavigationMenu < BxBlockNavmenu::ApplicationRecord
    self.table_name = :navigation_menus
  end
end
