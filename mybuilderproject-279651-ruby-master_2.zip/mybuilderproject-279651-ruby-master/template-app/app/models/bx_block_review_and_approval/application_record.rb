module BxBlockReviewAndApproval
  class ApplicationRecord < ActiveRecord::Base
    self.abstract_class = true
  end
end
