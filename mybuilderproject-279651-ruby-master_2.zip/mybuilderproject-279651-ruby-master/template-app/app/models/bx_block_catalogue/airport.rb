module BxBlockCatalogue
  class Airport < BxBlockCatalogue::ApplicationRecord
    self.table_name = :airports
  end
end
