module BxBlockCatalogue
  class CatalogueVariantColor < BxBlockCatalogue::ApplicationRecord
    self.table_name = :catalogue_variant_colors
  end
end
