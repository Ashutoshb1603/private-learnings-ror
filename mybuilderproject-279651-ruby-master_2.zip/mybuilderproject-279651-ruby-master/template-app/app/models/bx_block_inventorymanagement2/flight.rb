module BxBlockInventorymanagement2
class Flight < ApplicationRecord
end
end