module BxBlockCfaviaapi2
    class Aviapage < BxBlockCfaviaapi2::ApplicationRecord
        self.table_name = :aviapages
    end
end