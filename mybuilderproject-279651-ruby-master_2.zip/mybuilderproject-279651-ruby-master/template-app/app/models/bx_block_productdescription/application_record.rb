module BxBlockProductdescription
  class ApplicationRecord < BuilderBase::ApplicationRecord
    self.abstract_class = true
  end
end
