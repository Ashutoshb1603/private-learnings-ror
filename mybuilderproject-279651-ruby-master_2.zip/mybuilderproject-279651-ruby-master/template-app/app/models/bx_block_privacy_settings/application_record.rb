# frozen_string_literal: true

module BxBlockPrivacySettings
  class ApplicationRecord < BuilderBase::ApplicationRecord
    self.abstract_class = true
  end
end
