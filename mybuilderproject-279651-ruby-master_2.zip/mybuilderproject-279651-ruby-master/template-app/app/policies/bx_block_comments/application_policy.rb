# frozen_string_literal: true

module BxBlockComments
  class ApplicationPolicy < ::ApplicationPolicy
  end
end
