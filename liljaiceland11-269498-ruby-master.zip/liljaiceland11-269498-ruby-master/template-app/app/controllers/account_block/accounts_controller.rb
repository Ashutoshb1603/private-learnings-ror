module AccountBlock
  class AccountsController < ApplicationController
    include BuilderJsonWebToken::JsonWebTokenValidation

    before_action :validate_json_web_token, only: [:update, :search, :show]

    def create
      case params[:data][:type] #### rescue invalid API format
      when 'sms_account'
        validate_json_web_token

        unless valid_token?
          return render json: {errors: [
            {token: 'Invalid Token'},
          ]}, status: :bad_request
        end

        begin
          @sms_otp = SmsOtp.find(@token[:id])
        rescue ActiveRecord::RecordNotFound => e
          return render json: {errors: [
            {phone: 'Confirmed Phone Number was not found'},
          ]}, status: :unprocessable_entity
        end

        params[:data][:attributes][:full_phone_number] =
          @sms_otp.full_phone_number
        @account = SmsAccount.new(jsonapi_deserialize(params))
        @account.activated = true
        if @account.save
          render json: SmsAccountSerializer.new(@account, meta: {
            token: encode(@account.id)
          }).serializable_hash, status: :created
        else
          render json: {errors: format_activerecord_errors(@account.errors)},
            status: :unprocessable_entity
        end

      when 'email_account'
        account_params = jsonapi_deserialize(params)

        query_email = account_params['email'].downcase
        account = EmailAccount.where('LOWER(email) = ?', query_email).first

        validator = EmailValidation.new(account_params['email'])

        return render json: {errors: [
          {account: 'Email invalid'},
        ]}, status: :unprocessable_entity if account || !validator.valid?

        password_validation = AccountBlock::PasswordValidation
          .new(account_params['password'])
        is_valid = password_validation.valid?

        unless is_valid
          return render json: {
            errors: [{
              password: password_validation.errors['password'][0],
            }],
          }, status: :unprocessable_entity
        else
          @account = EmailAccount.new(account_params)
          @account.platform = request.headers['platform'].downcase if request.headers.include?('platform')

          if @account.save
            # Stripe account is not required as per requirement
            # EmailAccount.create_stripe_customers(@account)
            EmailValidationMailer
              .with(account: @account, host: request.base_url)
              .activation_email.deliver
            render json: EmailAccountSerializer.new(@account, meta: {
              token: encode(@account.id),
            }).serializable_hash, status: :created
          else
            render json: {errors: format_activerecord_errors(@account.errors)},
              status: :unprocessable_entity
          end
        end
      end
    end

    def update
      account_params = jsonapi_deserialize(params)

      @account = EmailAccount.find(params['id'])
      @account.platform = request.headers['platform'].downcase if request.headers.include?('platform')

      if @account.update_attributes(account_params)
        render json: EmailAccountSerializer.new(@account, meta: {
          token: encode(@account.id),
        }).serializable_hash, status: :ok
      else
        render json: {errors: format_activerecord_errors(@account.errors)},
          status: :unprocessable_entity
      end
    end

    def show
      @account = EmailAccount.find_by_id(params['id'])

      if @account
        render json: EmailAccountSerializer.new(@account, meta: {
          token: encode(@account.id),
        }).serializable_hash, status: :ok
      else
        render json: {errors: [{message: 'User does not exists.'}]},
          status: :unprocessable_entity
      end
    end

    def search
      @accounts = Account.where(activated: true)
                    .where('first_name ILIKE :search OR '\
                           'last_name ILIKE :search OR '\
                           'email ILIKE :search', search: "%#{search_params[:query]}%")
      if @accounts.present?
        render json: AccountSerializer.new(@accounts, meta: {message: 'List of users.'
        }).serializable_hash, status: :ok
      else
        render json: {errors: [{message: 'Not found any user.'}]}, status: :ok
      end
    end

    private

    def encode(id)
      BuilderJsonWebToken.encode id
    end

    def search_params
      params.permit(:query)
    end
  end
end
