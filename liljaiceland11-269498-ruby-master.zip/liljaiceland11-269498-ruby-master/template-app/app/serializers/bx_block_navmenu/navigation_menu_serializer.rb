module BxBlockNavmenu
  class NavigationMenuSerializer < BuilderBase::BaseSerializer
    attributes :id, :position, :items
  end
end
