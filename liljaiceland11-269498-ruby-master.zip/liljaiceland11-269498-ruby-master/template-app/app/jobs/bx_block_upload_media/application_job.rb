module BxBlockUploadMedia
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
