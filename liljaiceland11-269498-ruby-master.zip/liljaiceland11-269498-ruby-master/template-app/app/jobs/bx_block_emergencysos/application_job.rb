module BxBlockEmergencysos
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
