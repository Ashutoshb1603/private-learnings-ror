module BxBlockCoremachinelearning
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
