module BxBlockLivefeedcapture
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
