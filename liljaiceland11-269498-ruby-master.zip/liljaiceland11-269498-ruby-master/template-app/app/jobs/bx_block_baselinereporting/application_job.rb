module BxBlockBaselinereporting
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
