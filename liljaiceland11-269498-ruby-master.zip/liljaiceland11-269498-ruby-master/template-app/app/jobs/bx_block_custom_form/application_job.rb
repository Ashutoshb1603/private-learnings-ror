module BxBlockCustomForm
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
