module BxBlockSelfdestructmessaging
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
