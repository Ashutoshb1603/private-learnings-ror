module BxBlockCouponCg
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
