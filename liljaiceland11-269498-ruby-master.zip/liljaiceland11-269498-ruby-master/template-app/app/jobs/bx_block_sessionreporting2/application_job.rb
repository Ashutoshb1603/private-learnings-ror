module BxBlockSessionreporting2
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
