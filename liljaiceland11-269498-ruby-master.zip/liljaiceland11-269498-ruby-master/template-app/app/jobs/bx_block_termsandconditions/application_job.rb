module BxBlockTermsandconditions
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
