module BxBlockGamification
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
