module BxBlockImagemanagement
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
