module BxBlockCfemergencyservicesapiintegration
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
