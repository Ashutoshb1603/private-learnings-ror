module BuilderBase
  class ApplicationJob < ::ApplicationJob
  end
end
