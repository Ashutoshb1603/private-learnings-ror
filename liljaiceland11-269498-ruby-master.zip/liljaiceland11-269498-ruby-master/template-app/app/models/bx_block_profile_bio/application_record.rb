# frozen_string_literal: true

module BxBlockProfileBio
  class ApplicationRecord < BuilderBase::ApplicationRecord
    self.abstract_class = true
  end
end
