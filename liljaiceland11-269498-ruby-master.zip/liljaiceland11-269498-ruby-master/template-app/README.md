# **Ruby** | _**LiljaIceland11**_ | _**269498** | _**studio_pro**_

## **Catalog ProjectId: 142059** | **Catalog BuildId: 16652**

## NOTE FOR DEVELOPERS:
Clone the code-engine branch into your working branch. The contents of the branch may get overwritten.
## Author:
Code-Engine
## Assembled Features To Block Status

| **Feature-Name**        | **Block-Name**        | **Path**  | **Status**  |
|:-------------|:-------------|:-------------|:-------------|
| SignuploginModule2      | bx_block_login<br>bx_block_forgot_password<br>account_block<br>      | {+app/controllers/bx_block_login+}<br>{+app/controllers/bx_block_forgot_password+}<br>{+app/controllers/account_block+}<br> | {+Non-Empty+} |
| LanguageOptions      | bx_block_language_options<br>      | {+app/controllers/bx_block_language_options+}<br> | {+Non-Empty+} |
| AdminConsole3      | bx_block_admin<br>      | {+app/controllers/bx_block_admin+}<br> | {+Non-Empty+} |
| RolesPermissions2      | bx_block_roles_permissions<br>      | {+app/controllers/bx_block_roles_permissions+}<br> | {+Non-Empty+} |
| PostCreation2      | bx_block_posts<br>      | {+app/controllers/bx_block_posts+}<br> | {+Non-Empty+} |
| Profilebio      | bx_block_profile<br>bx_block_profile_bio<br>      | {+app/controllers/bx_block_profile+}<br>{+app/controllers/bx_block_profile_bio+}<br> | {+Non-Empty+} |
| UploadMedia2      | bx_block_upload_media<br>      | {+app/controllers/bx_block_upload_media+}<br> | {+Non-Empty+} |
| VisualAnalytics2      | bx_block_visual_analytics<br>      | {++}<br> | {+Non-Empty+} |
| ForgotPassword3      | bx_block_forgot_password<br>      | {+app/controllers/bx_block_forgot_password+}<br> | {+Non-Empty+} |
| ContentManagement      | bx_block_content_management<br>      | {+app/controllers/bx_block_content_management+}<br> | {+Non-Empty+} |
| CouponCodeGenerator      | bx_block_coupon_cg<br>      | {+app/controllers/bx_block_coupon_cg+}<br> | {+Non-Empty+} |
| NavigationMenu2      | bx_block_navmenu<br>      | {+app/controllers/bx_block_navmenu+}<br> | {+Non-Empty+} |
| Settings5      | bx_block_settings<br>      | {+app/controllers/bx_block_settings+}<br> | {+Non-Empty+} |
| Notifications3      | bx_block_notifications<br>bx_block_push_notifications<br>      | {+app/controllers/bx_block_notifications+}<br>{+app/controllers/bx_block_push_notifications+}<br> | {+Non-Empty+} |
| Calendar3      | bx_block_scheduling<br>      | {+app/controllers/bx_block_scheduling+}<br> | {+Non-Empty+} |
| GeolocationReporting2      | bx_block_location<br>      | {+app/controllers/bx_block_location+}<br> | {+Non-Empty+} |
| ContactUs5      | bx_block_contact_us<br>      | {+app/controllers/bx_block_contact_us+}<br> | {+Non-Empty+} |
| BaselineReporting      | bx_block_baselinereporting      | {-app/controllers/bx_block_baselinereporting-} | {-Empty-} |
| SelfdestructMessaging      | bx_block_selfdestructmessaging      | {-app/controllers/bx_block_selfdestructmessaging-} | {-Empty-} |
| SplashScreen2      | bx_block_splashscreen2      | {-app/controllers/bx_block_splashscreen2-} | {-Empty-} |
| DataEncryption      | bx_block_dataencryption      | {-app/controllers/bx_block_dataencryption-} | {-Empty-} |
| EmergencySos      | bx_block_emergencysos      | {-app/controllers/bx_block_emergencysos-} | {-Empty-} |
| Gamification      | bx_block_gamification      | {-app/controllers/bx_block_gamification-} | {-Empty-} |
| ImageManagement      | bx_block_imagemanagement      | {-app/controllers/bx_block_imagemanagement-} | {-Empty-} |
| Surveys      | bx_block_surveys      | {-app/controllers/bx_block_surveys-} | {-Empty-} |
| TermsAndConditions      | bx_block_termsandconditions      | {-app/controllers/bx_block_termsandconditions-} | {-Empty-} |
| ChatBackuprestore      | bx_block_chatbackuprestore      | {-app/controllers/bx_block_chatbackuprestore-} | {-Empty-} |
| CoreMachineLearning      | bx_block_coremachinelearning      | {-app/controllers/bx_block_coremachinelearning-} | {-Empty-} |
| LiveFeedCapture      | bx_block_livefeedcapture      | {-app/controllers/bx_block_livefeedcapture-} | {-Empty-} |
| Analytics9      | bx_block_analytics9      | {-app/controllers/bx_block_analytics9-} | {-Empty-} |
| Geofence2      | bx_block_geofence2      | {-app/controllers/bx_block_geofence2-} | {-Empty-} |
| SessionReporting2      | bx_block_sessionreporting2      | {-app/controllers/bx_block_sessionreporting2-} | {-Empty-} |
| CfEmergencyServicesApiIntegration      | bx_block_cfemergencyservicesapiintegration      | {-app/controllers/bx_block_cfemergencyservicesapiintegration-} | {-Empty-} |

## GRAFANA BACKEND URL
 - https://grafana.project-name-notfound-269498-ruby.b269498.none.eastus.az.svc.builder.ai

This application is a Ruby API. Full README coming soon...