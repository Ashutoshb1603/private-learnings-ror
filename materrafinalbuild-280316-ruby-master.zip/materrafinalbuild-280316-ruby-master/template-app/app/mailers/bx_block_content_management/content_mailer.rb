module BxBlockContentManagement
  class ContentMailer < ApplicationMailer
  end
end
