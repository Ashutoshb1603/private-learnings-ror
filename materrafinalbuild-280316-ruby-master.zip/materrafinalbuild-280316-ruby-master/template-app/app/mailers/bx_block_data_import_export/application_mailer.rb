module BxBlockDataImportExport
  class ApplicationMailer < BuilderBase::ApplicationMailer
    default from: 'from@example.com'
    layout 'mailer'
  end
end
