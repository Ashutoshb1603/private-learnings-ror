module Admin
	class SendOtpMailer < ApplicationMailer
		
		def send_otp_to_email(email, otp)
      @otp = otp
      mail(
          to: email,
          from: 'builder.bx_dev@engineer.ai',
          subject: 'Your OTP code') do |format|
        format.html { render 'send_otp_to_email' }
    	end
    end
	end
end
