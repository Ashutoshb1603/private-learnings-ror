module AccountBlock
  class DevicesController < ApplicationController
    include BuilderJsonWebToken::JsonWebTokenValidation
    before_action :validate_json_web_token
    rescue_from ActiveRecord::RecordNotFound, :with => :not_found

    before_action :set_current_user

    def index
      render json: {
      	data: {
      	  account: EmailAccountSerializer.new(@account),
      	  devices: DeviceTokenSerializer.new(@account.devices)
      	}
      }
    end

    def create
      params[:data][:attributes] = params[:data][:attributes].merge(account_id: @account.id)
      devices = Device.where(token: device_params[:token]) if device_params[:token].present?
      call_devices = Device.where(call_token: device_params[:call_token]) if device_params[:call_token].present?

      unless devices.present? || call_devices.present?
        if (old_devices = current_user.devices.order('created_at DESC')) && (diff = old_devices.count - 5) && diff > 0
          ids = old_devices.last(diff).map(&:id)
          old_devices.where(id: ids).destroy_all
        end
        device = Device.new(device_params)
        device.save!
      else
        devices.destroy_all if devices.present? && devices.count > 0
        call_devices.destroy_all if call_devices.present? && call_devices.count > 0

        device = Device.new(device_params)
        device.save!
      end

      render json: {
        data: {
          account: EmailAccountSerializer.new(@account),
          devices: DeviceTokenSerializer.new(device)
        }
      }, status: :ok
    end

    def update
      device = Device.find(params[:id])
      device.update(device_params)
      render json: {
      	data: {
      	  account: EmailAccountSerializer.new(@account),
      	  devices: DeviceTokenSerializer.new(device)
      	}
      }
    end

    def delete_token
      if params[:call_token].present?
        device_tokens = @account.devices.where(call_token: params[:call_token])
      else
        device_tokens = @account.devices.where(token: params[:device_token])
      end

      if device_tokens.present?
      	device_tokens.destroy_all
      end
      render json: {message: "Device token deleted successfully"}
    end

    private

    def device_params
      params.require(:data).require(:attributes).permit(:token, :platform, :call_token, :account_id)
    end

    def set_current_user
      @account ||= AccountBlock::Account.find(@token.id) if @token.present?
    end

    def not_found
      render :json => {'errors' => ['Record not found']}, :status => :not_found
    end
  end
end
