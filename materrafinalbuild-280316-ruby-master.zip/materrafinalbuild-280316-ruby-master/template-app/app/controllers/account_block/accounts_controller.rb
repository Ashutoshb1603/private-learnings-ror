# frozen_string_literal: true

module AccountBlock
  class AccountsController < ApplicationController
    include BuilderJsonWebToken::JsonWebTokenValidation
    include ActiveStorageSupport::SupportForBase64
    include ActiveStorage::Blob::Analyzable
    require 'mini_magick'

    before_action :validate_json_web_token, only: %i[update show resend_otp index search field_executive get_farmers farmer_details]
    before_action :current_farmer, only: [:farmer_details]
    before_action :check_fe, only: [:get_farmers]

    def create
      case params[:data][:type] #### rescue invalid API format
      when 'sms_account'
        @account = SmsAccount.new(jsonapi_deserialize(params))
        @account.role_id = 2
        account = SmsAccount.where('full_phone_number = ?', @account['full_phone_number']).first
        validator = PhoneValidation.new(@account['full_phone_number'])

        if !validator.valid? || @account['full_phone_number'].chars[0] != '+'
          return render json: { errors: [
            { account: 'phone number invalid' }
          ] }, status: :unprocessable_entity
        end

        if account
          return render json: { errors: [
            { account: 'Phone Number Already Exists' }
          ] }, status: :unprocessable_entity
        end

        sms_otp = SmsOtp.new(full_phone_number: @account.full_phone_number)
        if @account.save(validate: false) && sms_otp.save
          render json: SmsAccountSerializer.new(@account, meta: { otp: sms_otp.pin,
                                                                  token: encode(sms_otp.id) }).serializable_hash, status: :created
        else
          render json: { errors: @account.errors.full_messages || sms_otp.errors.full_messages },
                 status: :unprocessable_entity
        end
      end
    end

    def index
      @account = AccountBlock::Account.find(@token.id)
      if @account.present?
        render json: AccountSerializer.new(@account).serializable_hash, status: 200
      else
        render json: { errors: 'Account Not Found' },
               status: :unprocessable_entity
      end
    end

    def search
      accounts = AccountBlock::Account.where(role_id: 2, village_id: params[:village_id])

      @account_search = accounts.where('first_name LIKE ? OR last_name LIKE ?', "%#{params[:name]}%", "%#{params[:name]}%")
      
      if @account_search.present?
        search_data = ::AccountBlock::AccountSearchSerializer.new(@account_search).serializable_hash
        render json: search_data, status: :ok
      else
        render json: { errors: 'Record Not Present' },
               status: :unprocessable_entity
      end
    end

    def show
      @account = AccountBlock::Account.find(params[:id])
      if @account.present?
        render json: AccountSerializer.new(@account, serialization_options).serializable_hash, status: 200
      else
        render json: { errors: 'Account Not Found' },
               status: :unprocessable_entity
      end
    end

    def update
      @account = AccountBlock::Account.find(params[:id])
      @account.avatar.variant(resize_to_limit: [100, 100]) if @account.avatar.attached?
      @account.farmer_update_count += 1
      @account.fe_update_count += 1
      if @account.update(update_params)
        render json: AccountSerializer.new(@account, serialization_options).serializable_hash, status: 200
      else
        render json: { errors: @account.errors.full_messages },
               status: :unprocessable_entity
      end
    end

    def remove_profile_image
      @account = AccountBlock::Account.find(params[:id])
      @account.avatar.purge
      if @account.save
        render json: AccountSerializer.new(@account, serialization_options).serializable_hash, status: 200
      else
        render json: { errors: @account.errors.full_messages },
               status: :unprocessable_entity
      end
    end

    def resend_otp
      @sms = SmsOtp.where(full_phone_number: params['full_phone_number']).last
      @account = AccountBlock::Account.find_by('full_phone_number = ?', params['full_phone_number'])
      if @sms.valid_until > Time.current
        render json: SmsAccountSerializer.new(@account, meta: { otp: @sms.pin,
                                                                token: encode(@sms.id) }).serializable_hash, status: :ok
      elsif @account.present?
        sms_otp = SmsOtp.new(full_phone_number: @account.full_phone_number)
        if sms_otp.save
          render json: SmsAccountSerializer.new(@account, meta: { otp: sms_otp.pin,
                                                                  token: encode(sms_otp.id) }).serializable_hash, status: :created
        else
          render json: { errors: sms_otp.errors.full_messages },
                 status: :unprocessable_entity
        end
      else
        render json: { errors: 'Account Not Found' },
               status: :unprocessable_entity
      end
    end

    def field_executive
      account = AccountBlock::Account.find(@token.id)
      data = {}
      vil_ids = account.accounts_villages.pluck(:village_id)
      districts = BxBlockLocationDetails::District.includes(:villages).references(:villages).where("villages.id IN (?)", vil_ids)

      districts.each do |district|
        district.villages.each do |village|
          next unless vil_ids.include?(village.id)
          data[district.name] = {} unless data[district.name].present?
          data[district.name][village.name] = AccountBlock::Account.where(role_id: 2, village_id: village.id).count
        end
      end
      render json: {
        account: AccountSerializer.new(account).serializable_hash,
        profile: data
      }, status: 200
    end

    def get_farmers 
     villages_ids = current_user&.accounts_villages&.pluck(:village_id)
     @accounts = AccountBlock::Account.where(role_id: 2, village_id: villages_ids)
     @account_search = @accounts.where('first_name LIKE ? OR last_name LIKE ?', "%#{params[:name]}%", "%#{params[:name]}%")

      if params.present?
        search_data = ::AccountBlock::AccountSearchSerializer.new(@account_search).serializable_hash
        render json: search_data, status: :ok
      else
        farmers =  ::AccountBlock::AccountSearchSerializer.new(@accounts).serializable_hash
        render json: farmers, status: :ok
      end
    end

    def farmer_details
      push_notifications = current_farmer.push_notifications
      farmer_notifications = ::BxBlockPushNotifications::PushNotificationSerializer.new(push_notifications).serializable_hash
      render json: farmer_notifications, status: :ok
    end

    private

    def encode(id)
      BuilderJsonWebToken.encode id
    end

    def update_params
      params.require(:data).require(:attributes).permit(:role_id, :first_name, :last_name, :middle_name, :gender, :email,
                                                        :full_phone_number, :total_family_members, :date_of_birth, :highest_education_id, :age, :number_belongs_to_id, :mobile_type_id, :state_id, :district_id, :taluka_id, :village_id, :user_type, :aadhaar_number,avatar: :data)
    end

    def serialization_options
      { params: { host: request.protocol + request.host_with_port } }
    end

    def check_fe
      render json: {error: "user not a field executive"} if current_user.role_id == 2
    end
  end
end
