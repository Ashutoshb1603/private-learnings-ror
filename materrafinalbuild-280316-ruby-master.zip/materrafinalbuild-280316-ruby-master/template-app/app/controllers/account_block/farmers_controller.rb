module AccountBlock
	class FarmersController < ApplicationController
    before_action :check_fe, only: [:show]

    def update_farmer
    	if current_farmer.role_id == 2
	     	if current_farmer.update(update_params)
	          render json: FarmerSerializer.new(current_farmer).serializable_hash, status: 200
	        else
	          render json: { errors: current_farmer.errors.full_messages },
	               status: :unprocessable_entity
	        end
        end
	end


    def show
     @account = AccountBlock::Account.find_by(id: params[:id])
     if @account.role_id == 2
	     village_ids = current_user.accounts_villages.map{|vill| vill.village_id}
	     farmer = AccountBlock::Account.where(id: params[:id], village_id: village_ids)
	     if farmer.present?
          push_notifications = farmer.first.push_notifications
	      farmer_notifications = ::BxBlockPushNotifications::PushNotificationSerializer.new(push_notifications).serializable_hash
	      render json: farmer_notifications, status: :ok
	     else
          render json: {error: "farmer is not associated"}, status: :unprocessable_entity
	     end
     else
       render json: {error: "user is not a farmer"}, status: :unprocessable_entity
     end
    end


	private

	def update_params
      params.require(:data).require(:attributes).permit(:role_id, :first_name, :last_name, :middle_name, :gender, :email,
                                                        :full_phone_number, :total_family_members, :date_of_birth, :highest_education_id, :age, :number_belongs_to_id, :mobile_type_id, :state_id, :district_id, :taluka_id, :village_id, :user_type, :aadhaar_number,avatar: :data)
    end

    def check_fe
      render json: {error: "user not a field executive"} if current_user.role_id == 2
    end
end
end