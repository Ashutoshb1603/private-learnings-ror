# frozen_string_literal: true

module AccountBlock
  module Accounts
    class SmsConfirmationsController < ApplicationController
      include BuilderJsonWebToken::JsonWebTokenValidation

      before_action :validate_json_web_token

      def create
        begin
          @sms_otp = SmsOtp.find(@token.id)
        rescue ActiveRecord::RecordNotFound => e
          return render json: {errors: [
            {phone: 'Phone Number Not Found'},
          ]}, status: :unprocessable_entity
        end

        if @sms_otp.valid_until < Time.current
          @sms_otp.destroy

          return render json: {errors: [
            {pin: 'This Pin has expired, please request a new pin code.'},
          ]}, status: :unauthorized
        end

        #if @sms_otp.activated?
         # return render json: ValidateAvailableSerializer.new(@sms_otp, meta: {
          #  message: 'Phone Number Already Activated',
          #}).serializable_hash, status: :ok
        #end

        if @sms_otp.pin.to_s == params['pin'].to_s
          @sms_otp.activated = true
          @sms_otp.save
          account=AccountBlock::Account.find_by(full_phone_number:@sms_otp.full_phone_number)
          account = AccountBlock::SmsAccount.create(full_phone_number:@sms_otp.full_phone_number,user_type:params['user_type']) unless account
          token, refresh_token = generate_tokens(account.id)

          render json: {meta: {
            token: token,
            refresh_token: refresh_token,
            id: account.id,
            role_id: account.role_id
          }}

          #render json: ValidateAvailableSerializer.new(@sms_otp, meta: {
           # message: 'Phone Number Confirmed Successfully',
            #token: BuilderJsonWebToken.encode(@sms_otp.id),
          #}).serializable_hash, status: :ok
        else
          return render json: {errors: [
            {pin: 'Invalid Pin for Phone Number'},
          ]}, status: :unprocessable_entity
        end
      end

      def generate_tokens(account_id)
      [
        BuilderJsonWebToken.encode(account_id, 2.month.from_now, token_type: 'login'),
        BuilderJsonWebToken.encode(account_id, 1.year.from_now, token_type: 'refresh')
      ]
      end
    end
  end
end
