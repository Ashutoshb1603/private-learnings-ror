# frozen_string_literal: true

module BxBlockProfileBio
  class SoilTexturesController < ApplicationController
    def index
      @soil_textures = BxBlockProfileBio::SoilTexture.where(active: true)
      render json: @soil_textures, status: :ok
    end
  end
end
