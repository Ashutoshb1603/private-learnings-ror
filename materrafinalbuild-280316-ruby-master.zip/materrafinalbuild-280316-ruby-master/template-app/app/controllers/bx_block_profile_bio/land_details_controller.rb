module BxBlockProfileBio
  class LandDetailsController < ApplicationController
    include ActiveStorage::Blob::Analyzable
    require 'mini_magick'
    # before_action :check_account_activated
    before_action :current_farmer, only: [:update_fe_as_farmer]

    def create
      land_detail = BxBlockProfileBio::LandDetail.new(land_details_params)
      if params[:land_detail][:farm_image]
        farm_img = params[:land_detail][:farm_image] #.each do |image|
        mini_image = MiniMagick::Image.new(farm_img.tempfile.path)
        mini_image.resize '1000x1000'
      end
      if params[:land_detail][:farm_mapping_image]
        farm_mapping_img = params[:land_detail][:farm_mapping_image] #.each do |image|
        mini_image = MiniMagick::Image.new(farm_mapping_img.tempfile.path)
        mini_image.resize '1000x1000'
      end
      if land_detail.save
        serializer = BxBlockProfileBio::LandDetailSerializer.new(land_detail)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{land_detail: land_detail.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def show
      land_detail = BxBlockProfileBio::LandDetail.find(params[:id])
      
      if land_detail.present?
        serializer = BxBlockProfileBio::LandDetailSerializer.new(land_detail)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{land_detail: land_detail.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end  
  
    def update
      land_detail = BxBlockProfileBio::LandDetail.find(params[:id])
      if params[:land_detail][:farm_image].present? 
        land_detail.farm_image.purge 
      end
      if params[:land_detail][:farm_mapping_image].present?
        land_detail.farm_mapping_image.purge 
      end
      if params[:land_detail][:farm_image]
        farm_img = params[:land_detail][:farm_image] #.each do |image|
        mini_image = MiniMagick::Image.new(farm_img.tempfile.path)
        mini_image.resize '1000x1000'
      end
      if params[:land_detail][:farm_mapping_image]
        farm_mapping_img = params[:land_detail][:farm_mapping_image] #.each do |image|
        mini_image = MiniMagick::Image.new(farm_mapping_img.tempfile.path)
        mini_image.resize '1000x1000'
      end
      land_detail.fe_update_count += 1
      land_detail.farmer_update_count += 1
      if land_detail.update(land_details_params)
        serializer = BxBlockProfileBio::LandDetailSerializer.new(land_detail)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{land_detail: land_detail.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def update_fe_as_farmer
      update()
    end

    private
    def land_details_params
      params.require(:land_detail).permit(:farm_image, :farm_mapping_image, :name, :survey_number, :owner, :unit_farm_area_for_cotton,
                                          :farm_area_for_cotton, :horizontal_distance, :motor_horse_power, :pump_depth, :farm_area, :account_id,
                                          :unit_farm_area, :soil_texture_id, :land_type_id, :source_irrigation_id, :type_irrigation_id, :distance_in, :latitude_longitude, :search_farm_name
                                          )
    end
  end
end