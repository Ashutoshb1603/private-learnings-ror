# frozen_string_literal: true

module BxBlockProfileBio
  class TypeIrrigationsController < ApplicationController
    def index
      @owners = BxBlockProfileBio::TypeIrrigation.where(active: true)
      render json: @owners, status: :ok
    end
  end
end
