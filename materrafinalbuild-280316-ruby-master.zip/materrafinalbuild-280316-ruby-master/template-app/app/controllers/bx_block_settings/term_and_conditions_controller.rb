# frozen_string_literal: true

module BxBlockSettings
  class TermAndConditionsController < ApplicationController
    def index
      @terms_and_condition = BxBlockSettings::TermAndCondition.all
      render json: @terms_and_condition, status: 200
    end
  end
end
