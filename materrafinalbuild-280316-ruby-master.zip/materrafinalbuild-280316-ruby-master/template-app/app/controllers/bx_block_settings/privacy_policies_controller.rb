# frozen_string_literal: true

module BxBlockSettings
  class PrivacyPoliciesController < ApplicationController
    def index
      @policy = BxBlockSettings::PrivacyPolicy.all
      render json: @policy
    end
  end
end
