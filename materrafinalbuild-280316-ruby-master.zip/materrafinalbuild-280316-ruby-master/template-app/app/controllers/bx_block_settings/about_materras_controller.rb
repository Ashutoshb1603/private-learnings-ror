# frozen_string_literal: true

module BxBlockSettings
  class AboutMaterrasController < ApplicationController
    def index
      @about_materra = BxBlockSettings::AboutMaterra.all
      render json: @about_materra, status: 200
    end
  end
end
