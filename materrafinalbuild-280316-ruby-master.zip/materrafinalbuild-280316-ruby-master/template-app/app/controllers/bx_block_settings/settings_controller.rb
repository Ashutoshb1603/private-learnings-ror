# frozen_string_literal: true

module BxBlockSettings
  class SettingsController < ApplicationController
    SETTING_TYPE_LIST = %w[terms_and_conditions privacy_policy about_materra].freeze
    def index
      data = {}
      setting = BxBlockSettings::Setting.where(setting_type: SETTING_TYPE_LIST)
      setting.each do |setting|
        data[setting.setting_type] = setting.content
      end
      render json: [data.as_json], status: 200
    end
  end
end
