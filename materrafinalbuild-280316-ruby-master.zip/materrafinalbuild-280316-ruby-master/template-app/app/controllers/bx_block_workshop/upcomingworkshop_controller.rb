# frozen_string_literal: true

module BxBlockWorkshop
  class UpcomingworkshopController < ApplicationController
    def index
      workshop = BxBlockWorkshop::Upcomingworkshop.all
      render json: { workshop: workshop }, status: 200
    end
  end
end
