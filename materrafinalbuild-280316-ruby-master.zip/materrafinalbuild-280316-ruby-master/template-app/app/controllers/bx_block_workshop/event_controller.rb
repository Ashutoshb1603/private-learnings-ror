# frozen_string_literal: true

module BxBlockWorkshop
  class EventController < ApplicationController
    def index
      events = BxBlockWorkshop::Event.all
      render json: EventSerializer.new(events, serialization_options).serializable_hash, status: 200
    end

    def show
      event = BxBlockWorkshop::Event.find(params[:id])
      render json: EventSerializer.new(event, serialization_options).serializable_hash, status: 200  
    end

    def search
      users = AccountBlock::Account.where('first_name LIKE ?', "%#{params[:search]}%")
      groups = BxBlockChat::Chat.where('name LIKE ? ', "%#{params[:search]}%")
      data = { users: users, groups: groups }
      if data.present?
        render json: data, status: :ok
      else
        render json: { errors: 'Record Not Present' },
               status: :unprocessable_entity
      end
    end
    private

    def serialization_options
      { params: { host: request.protocol + request.host_with_port } }
    end
  end
end
