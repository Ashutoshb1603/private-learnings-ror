# frozen_string_literal: true

module BxBlockWorkshop
  class NewsController < ApplicationController
    def index
      news = BxBlockWorkshop::News.all
      render json: NewsSerializer.new(news, serialization_options).serializable_hash, status: 200
    end

    def show
      news = BxBlockWorkshop::News.find(params[:id])
      render json: NewsSerializer.new(news, serialization_options).serializable_hash, status: 200
    end
    private

    def serialization_options
      { params: { host: request.protocol + request.host_with_port } }
    end
  end
end
