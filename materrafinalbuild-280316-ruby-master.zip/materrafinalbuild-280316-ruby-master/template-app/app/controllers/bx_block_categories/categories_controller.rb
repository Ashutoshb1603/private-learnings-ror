module BxBlockCategories
  class CategoriesController < ApplicationController
    def index
      category = BxBlockCategories::Category.all
      render json: category, status: 200
    end
  end
end

