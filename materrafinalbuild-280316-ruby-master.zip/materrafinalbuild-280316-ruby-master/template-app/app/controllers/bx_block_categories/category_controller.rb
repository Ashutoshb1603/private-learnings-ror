# frozen_string_literal: true

module BxBlockCategories
  class CategoryController < ApplicationController
    def index
      category = BxBlockCategories::Category.all
      render json: category, status: 200
    end
  end
end
