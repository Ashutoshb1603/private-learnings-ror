module BxBlockChat
  class ChatsController < ApplicationController
    before_action :find_chat, only: [:read_messages, :update_chat]

    def index
      chats = current_user.chats
      render json: BxBlockChat::ChatListSerializer.new(chats, serialization_options).serializable_hash, status: :ok
    end

    def search_chats
      chat = BxBlockChat::Chat.find(params[:chat_id])

      serialization_options_obj = serialization_options
      serialization_options_obj[:params][:message_search] = params[:message_search]
      serialization_options_obj[:params][:page] = params[:page]

      chat_search_data = ::BxBlockChat::ChatSerializer.new(chat, serialization_options_obj).serializable_hash
      render json: chat_search_data, status: :ok
    end

    def show
      chat = BxBlockChat::Chat.includes(:accounts, :admin_users).find(params[:id])
      render json: ::BxBlockChat::ChatSerializer.new(chat, serialization_options).serializable_hash, status: :ok
    end

    def create
      chat_ids = BxBlockChat::AccountsChatsBlock.where(account_id: current_user.id).pluck(:chat_id)
      chat_boxs = BxBlockChat::AccountsChatsBlock.where(chat_id: chat_ids).where(account_id: params[:account_id])
      account_ids = chat_boxs.pluck(:account_id)
      accounts = ::AccountBlock::Account.where(id: account_ids)
      if chat_boxs.empty?
          account = ::AccountBlock::Account.find_by(id: params[:account_id])
          if account.present?
            friendly_name = "#{account.first_name}_#{account.last_name}"
            chat = account.chats.create(name: friendly_name, chat_type: 1)
            ::BxBlockChat::AccountsChatsBlock.create(account_id: current_user.id, chat_id: chat.id)
            render json: {data: {
                  chat_id: chat.id,
                  current_chat_participant: {
                    current_chat_participant_id: current_user,
                  },
                    participants: account,
                  
              }}, status: :ok
          else
            render json: {errors: "account does'nt exist"}, status: :unprocessable_entity
          end
      else
        render json: {data: {
                chat_id: chat_boxs.first.chat_id,
                current_chat_participant: {
                  current_chat_participant_id: current_user,
                },
                  participants: accounts,
            }}, status: :ok
      end
      # chat = BxBlockChat::Chat.new(chat_params)
      # chat.chat_type = 'multiple_user'
      # if chat.save
      #   BxBlockChat::AccountsChatsBlock.create(account_id: current_user.id,
      #                                             chat_id: chat.id,
      #                                              status: :admin)
      #   render json: ::BxBlockChat::ChatSerializer.new(chat, serialization_options).serializable_hash, status: :created
      # else
      #   render json: {errors: chat.errors}, status: :unprocessable_entity
      # end
    end

    def history
      chat = BxBlockChat::Chat.find(params[:chat_id])
      chat_data = ::BxBlockChat::ChatSerializer.new(chat, serialization_options).serializable_hash
      render json: chat_data, status: :ok
    end

    def media_history
      chat = BxBlockChat::Chat.find(params[:chat_id])
      
      serialization_options_obj = serialization_options
      serialization_options_obj[:params][:attachment_only] = true
      serialization_options_obj[:params][:page] = params[:page]

      chat_media_data = ::BxBlockChat::ChatSerializer.new(chat, serialization_options_obj).serializable_hash
      render json: chat_media_data, status: :ok
      
    end

    def read_messages
      begin
        @chat.messages&.all.update(is_mark_read: true )
        render json: ::BxBlockChat::ChatSerializer.new(@chat, serialization_options).serializable_hash, status: :ok
      rescue Exception=> e
        render json: { error: e }
      end
    end

    def update
      chat = Chat.find(params[:id])
      if chat.update!(is_notification_mute: params[:is_notification_mute])
        render json: ::BxBlockChat::ChatSerializer.new(
          chat, serialization_options
        ).serializable_hash, status: :ok
      else
        render json: { errors: format_activerecord_errors(chat.errors) },
               status: :unprocessable_entity
      end
    end

    def search
      @chats = current_user
        .chats
        .where('name ILIKE :search', search: "%#{search_params[:query]}%")
      render json: ChatSerializer.new(@chats, serialization_options).serializable_hash, status: :ok
    end

    def search_messages
      @messages = ChatMessage
                    .where(chat_id: current_user.chat_ids)
                    .where('message ILIKE :search', search: "%#{search_params[:query]}%")
      render json: ChatMessageSerializer.new(@messages, serialization_options).serializable_hash, status: :ok
    end

    def update_chat
      if current_user.role_id == 1
        if @chat.update!(chat_params)
          chat_data = ::BxBlockChat::ChatSerializer.new(@chat, serialization_options).serializable_hash
          render json: chat_data, status: :ok
        else
          render json: {errors: "chat can't be updated"}, status: :unprocessable_entity
        end
      else
        render json: {errors: "current user is not a field executive"}, status: :unprocessable_entity
      end
    end

    private

    def chat_params
      params.require(:chat).permit(:name, :chat_type, :logo)
    end

    def search_params
      params.permit(:query)
    end

    def find_chat
      @chat = Chat.find_by_id(params[:chat_id])
      render json: {message: "Chat room is not valid or no longer exists" } unless @chat
    end
  end
end
