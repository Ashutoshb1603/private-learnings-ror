module BxBlockChat
  class MessagesController < BxBlockChat::ApplicationController
    def create
      @chat = current_user.chats.find_by_id(message_params[:chat_id])
      unless @chat
        render json: {message: "Chat room is not valid or no longer exists" } and return
      end
      message = @chat.messages.new(message_params)
      message.account_id = current_user.id

      if message.save
        admin_user_ids = @chat.accounts_chats.select{|ac| ac.account_id != current_user.id }.pluck(:admin_user_id).compact
        user_ids = @chat.accounts_chats.select{|ac| ac.account_id != current_user.id }.pluck(:account_id).compact
        title = "New Message from user #{current_user.first_name.capitalize} #{current_user.last_name.capitalize}"
        message_data = message.message&.present? ? message&.message : message&.attachment&.url
        response = BxBlockPushNotifications::SendPushNotification.new(title: title, message: message, user_ids: user_ids, admin_user_ids: admin_user_ids, current_user: current_user, type: "new_message", chat_id: @chat.id, reply_message_user_id: message.reply_message_user_id, reply_message_admin_id: message.reply_message_admin_id).call
        created_dates = message.chat.accounts_chats.select{|ac| ac.account_id != current_user.id }.map{|acc_chat|  BxBlockChat::ChatMessage.find_by(id: acc_chat.last_read_msg_id)&.created_at || Time.zone.now-100.years}
        serialization_options_obj = serialization_options
        serialization_options_obj[:params][:created_dates] = created_dates
        messages_hash = ::BxBlockChat::ChatMessageSerializer.new(message, serialization_options_obj).serializable_hash
        BxBlockPushNotifications::PushNotification.create(account_id: message.account_id, push_notificable_type: "BxBlockChat::ChatMessage", push_notificable_id: message.id, remarks: message.message) if response && (response.last && response.last[:status_code] == 200)
        messages_hash[:data][:attributes][:push_notification_response] = response

        render json: {:data => messages_hash[:data][:attributes]}, status: :created
      else
        render json: {errors: message.errors}, status: :unprocessable_entity
      end
    end

    def messages_delete
      messages = ::BxBlockChat::ChatMessage.where(id: params[:message_ids])
      if messages.present?
        messages.update_all(deleted: true)
        title = "Message deleted by user #{current_user&.first_name&.capitalize} #{current_user&.last_name&.capitalize}"
        user_ids = messages.last&.chat&.accounts_chats&.select{|ac| ac.account_id != current_user.id }&.pluck(:account_id)
        response = BxBlockPushNotifications::SendPushNotification.new(title: title, message: messages.pluck(:id), user_ids: user_ids, current_user: current_user, type: "message_deleted", chat_id: messages.last&.chat&.id).call
        if response && (response.last && response.last[:status_code] == 200)
          messages.map{|msg|  BxBlockPushNotifications::PushNotification.create(account_id: msg.account_id, push_notificable_type: "BxBlockChat::ChatMessage", push_notificable_id: msg.id, remarks: msg.message)}
        end
        render json: {deleted: true}
      else
        render json: {errors: "No message selected for delete"}, status: :unprocessable_entity
      end
    end

    def mark_read_unread
      message = ::BxBlockChat::ChatMessage.find_by(id: message_params["message_id"])
      accounts_chat = message.chat&.accounts_chats&.where(account_id: current_user&.id)
      if message_params["read"] && accounts_chat
        accounts_chat.update(last_read_msg_id: message_params["message_id"])
        title = "Message deleted by user #{current_user&.first_name&.capitalize} #{current_user&.last_name&.capitalize}"
        user_ids = message.chat&.accounts_chats&.select{|ac| ac.account_id != current_user.id }&.pluck(:account_id)
        BxBlockPushNotifications::SendPushNotification.new(title: title, message: message, user_ids: user_ids, current_user: current_user, type: "message_read", chat_id: message&.chat&.id).call
        BxBlockPushNotifications::PushNotification.create(account_id: message.account_id, push_notificable_type: "BxBlockChat::ChatMessage", push_notificable_id: message.id, remarks: message.message) if response && (response[:status_code] == 200)
        render json: {data: {last_read_msg: accounts_chat, status: "Marked Read"}}
      else
        render json: {errors: "Not found"}
      end
    end

    private

    def message_params
      params.require(:data).require(:attributes).permit(:message, :account_id, :admin_user_id, :chat_id, :attachment, :read, :message_id, :reply_message_user_id, :reply_message_id, :reply_message_admin_id)
    end
  end
end
