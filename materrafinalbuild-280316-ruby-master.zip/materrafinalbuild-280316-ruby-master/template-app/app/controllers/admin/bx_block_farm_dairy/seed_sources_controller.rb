class Admin::BxBlockFarmDairy::SeedSourcesController < ApplicationController
	include BuilderJsonWebToken::JsonWebTokenValidation
	before_action :validate_json_web_token, :check_token_type, :check_admin_user
	before_action :set_seed_source, only: [:update, :show, :destroy]
	def index
		seed_sources = BxBlockFarmDairy::SeedSource.all
    render json: seed_sources, status: :ok
	end

	def create
		seed_source = BxBlockFarmDairy::SeedSource.new(seed_source_params)

		if seed_source.save
			render json: seed_source, status: :created
		else
			render json: { errors: seed_source.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	def update
		if @seed_source.update(seed_source_params)
			render json: @seed_source, status: 200
		else
			render json: { errors: @seed_source.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	def show
		render json: @seed_source, status: 200
	end

	def destroy
		if @seed_source.destroy
			render json: {deleted: true}
		else
			render json: { errors: @seed_source.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	private

	def check_admin_user
  	@admin_account = AdminUser.admins.find_by_id(@token.id)
  	unless @admin_account.present?
  		return render json: {errors: [{account: 'Not Found'},]},
             status: :bad_request
  	end
  end

  def check_token_type
    return render json: { errors: { 'token' => ['is invalid'] } }, status: :bad_request unless ["admin_login", "admin_login_refresh"].include?(@token.token_type)
  end

  def seed_source_params
  	params.require(:data).require(:attributes).permit(:name, :name_hindi, :name_gujrati, :active)
  end

  def set_seed_source
  	@seed_source = BxBlockFarmDairy::SeedSource.find_by(id: params[:id])
  	return render json: { errors: 'Not found' },
               status: :not_found unless @seed_source.present?
  end
end
