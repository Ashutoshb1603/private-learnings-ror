class Admin::BxBlockFarmDairy::CropNamesController < ApplicationController
	include BuilderJsonWebToken::JsonWebTokenValidation
	before_action :validate_json_web_token, :check_token_type, :check_admin_user
	before_action :set_crop_name, only: [:update, :show, :destroy]
	def index
		crop_names = BxBlockFarmDairy::CropName.all
    render json: crop_names, status: :ok
	end

	def create
		crop_name = BxBlockFarmDairy::CropName.new(crop_name_params)

		if crop_name.save
			render json: crop_name, status: :created
		else
			render json: { errors: crop_name.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	def update
		if @crop_name.update(crop_name_params)
			render json: @crop_name, status: 200
		else
			render json: { errors: @crop_name.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	def show
		render json: @crop_name, status: 200
	end

	def destroy
		if @crop_name.destroy
			render json: {deleted: true}
		else
			render json: { errors: @crop_name.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	private

	def check_admin_user
  	@admin_account = AdminUser.admins.find_by_id(@token.id)
  	unless @admin_account.present?
  		return render json: {errors: [{account: 'Not Found'},]},
             status: :bad_request
  	end
  end

  def check_token_type
    return render json: { errors: { 'token' => ['is invalid'] } }, status: :bad_request unless ["admin_login", "admin_login_refresh"].include?(@token.token_type)
  end

  def crop_name_params
  	params.require(:data).require(:attributes).permit(:name, :name_hindi, :name_gujrati, :active)
  end

  def set_crop_name
  	@crop_name = BxBlockFarmDairy::CropName.find_by(id: params[:id])
  	return render json: { errors: 'Not found' },
               status: :not_found unless @crop_name.present?
  end
end
