class Admin::BxBlockFarmDairy::BioAgentReleasesController < ApplicationController
	include BuilderJsonWebToken::JsonWebTokenValidation
	before_action :validate_json_web_token, :check_token_type, :check_admin_user
	before_action :set_bio_agent_release, only: [:update, :show, :destroy]
	def index
		bio_agent_releases = BxBlockFarmDairy::BioAgentRelease.all
    render json: bio_agent_releases, status: :ok
	end

	def create
		bio_agent_release = BxBlockFarmDairy::BioAgentRelease.new(bio_agent_release_params)

		if bio_agent_release.save
			render json: bio_agent_release, status: :created
		else
			render json: { errors: bio_agent_release.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	def update
		if @bio_agent_release.update(bio_agent_release_params)
			render json: @bio_agent_release, status: 200
		else
			render json: { errors: @bio_agent_release.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	def show
		render json: @bio_agent_release, status: 200
	end

	def destroy
		if @bio_agent_release.destroy
			render json: {deleted: true}
		else
			render json: { errors: @bio_agent_release.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	private

	def check_admin_user
  	@admin_account = AdminUser.admins.find_by_id(@token.id)
  	unless @admin_account.present?
  		return render json: {errors: [{account: 'Not Found'},]},
             status: :bad_request
  	end
  end

  def check_token_type
    return render json: { errors: { 'token' => ['is invalid'] } }, status: :bad_request unless ["admin_login", "admin_login_refresh"].include?(@token.token_type)
  end

  def bio_agent_release_params
  	params.require(:data).require(:attributes).permit(:name, :name_hindi, :name_gujrati, :active)
  end

  def set_bio_agent_release
  	@bio_agent_release = BxBlockFarmDairy::BioAgentRelease.find_by(id: params[:id])
  	return render json: { errors: 'Not found' },
               status: :not_found unless @bio_agent_release.present?
  end
end
