class Admin::BxBlockFarmDairy::WeedingTypesController < ApplicationController
	include BuilderJsonWebToken::JsonWebTokenValidation
	before_action :validate_json_web_token, :check_token_type, :check_admin_user
	before_action :set_weeding_type, only: [:update, :show, :destroy]
	def index
		weeding_types = BxBlockFarmDairy::WeedingType.all
    render json: weeding_types, status: :ok
	end

	def create
		weeding_type = BxBlockFarmDairy::WeedingType.new(weeding_type_params)

		if weeding_type.save
			render json: weeding_type, status: :created
		else
			render json: { errors: weeding_type.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	def update
		if @weeding_type.update(weeding_type_params)
			render json: @weeding_type, status: 200
		else
			render json: { errors: @weeding_type.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	def show
		render json: @weeding_type, status: 200
	end

	def destroy
		if @weeding_type.destroy
			render json: {deleted: true}
		else
			render json: { errors: @weeding_type.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	private

	def check_admin_user
  	@admin_account = AdminUser.admins.find_by_id(@token.id)
  	unless @admin_account.present?
  		return render json: {errors: [{account: 'Not Found'},]},
             status: :bad_request
  	end
  end

  def check_token_type
    return render json: { errors: { 'token' => ['is invalid'] } }, status: :bad_request unless ["admin_login", "admin_login_refresh"].include?(@token.token_type)
  end

  def weeding_type_params
  	params.require(:data).require(:attributes).permit(:name, :name_hindi, :name_gujrati, :active)
  end

  def set_weeding_type
  	@weeding_type = BxBlockFarmDairy::WeedingType.find_by(id: params[:id])
  	return render json: { errors: 'Not found' },
               status: :not_found unless @weeding_type.present?
  end
end
