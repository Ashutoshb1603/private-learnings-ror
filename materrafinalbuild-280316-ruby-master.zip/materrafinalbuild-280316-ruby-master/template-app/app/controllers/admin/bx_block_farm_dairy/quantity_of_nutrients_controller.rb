class Admin::BxBlockFarmDairy::QuantityOfNutrientsController < ApplicationController
	include BuilderJsonWebToken::JsonWebTokenValidation
	before_action :validate_json_web_token, :check_token_type, :check_admin_user
	before_action :set_quantity_of_nutrient, only: [:update, :show, :destroy]
	def index
		quantity_of_nutrients = BxBlockFarmDairy::QuantityOfNutrient.all
    render json: quantity_of_nutrients, status: :ok
	end

	def create
		quantity_of_nutrient = BxBlockFarmDairy::QuantityOfNutrient.new(quantity_of_nutrient_params)

		if quantity_of_nutrient.save
			render json: quantity_of_nutrient, status: :created
		else
			render json: { errors: quantity_of_nutrient.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	def update
		if @quantity_of_nutrient.update(quantity_of_nutrient_params)
			render json: @quantity_of_nutrient, status: 200
		else
			render json: { errors: @quantity_of_nutrient.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	def show
		render json: @quantity_of_nutrient, status: 200
	end

	def destroy
		if @quantity_of_nutrient.destroy
			render json: {deleted: true}
		else
			render json: { errors: @quantity_of_nutrient.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	private

	def check_admin_user
  	@admin_account = AdminUser.admins.find_by_id(@token.id)
  	unless @admin_account.present?
  		return render json: {errors: [{account: 'Not Found'},]},
             status: :bad_request
  	end
  end

  def check_token_type
    return render json: { errors: { 'token' => ['is invalid'] } }, status: :bad_request unless ["admin_login", "admin_login_refresh"].include?(@token.token_type)
  end

  def quantity_of_nutrient_params
  	params.require(:data).require(:attributes).permit(:name, :name_hindi, :name_gujrati, :active)
  end

  def set_quantity_of_nutrient
  	@quantity_of_nutrient = BxBlockFarmDairy::QuantityOfNutrient.find_by(id: params[:id])
  	return render json: { errors: 'Not found' },
               status: :not_found unless @quantity_of_nutrient.present?
  end
end
