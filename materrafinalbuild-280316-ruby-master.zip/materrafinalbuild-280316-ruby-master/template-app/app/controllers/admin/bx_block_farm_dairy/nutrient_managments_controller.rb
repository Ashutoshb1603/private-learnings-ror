class Admin::BxBlockFarmDairy::NutrientManagmentsController < ApplicationController
	include BuilderJsonWebToken::JsonWebTokenValidation
	before_action :validate_json_web_token, :check_token_type, :check_admin_user
	before_action :set_nutrient_managment, only: [:update, :show, :destroy]
	def index
		nutrient_managments = BxBlockFarmDairy::NutrientManagment.all
    render json: nutrient_managments, status: :ok
	end

	def create
		nutrient_managment = BxBlockFarmDairy::NutrientManagment.new(nutrient_managment_params)

		if nutrient_managment.save
			render json: nutrient_managment, status: :created
		else
			render json: { errors: nutrient_managment.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	def update
		if @nutrient_managment.update(nutrient_managment_params)
			render json: @nutrient_managment, status: 200
		else
			render json: { errors: @nutrient_managment.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	def show
		render json: @nutrient_managment, status: 200
	end

	def destroy
		if @nutrient_managment.destroy
			render json: {deleted: true}
		else
			render json: { errors: @nutrient_managment.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	private

	def check_admin_user
  	@admin_account = AdminUser.admins.find_by_id(@token.id)
  	unless @admin_account.present?
  		return render json: {errors: [{account: 'Not Found'},]},
             status: :bad_request
  	end
  end

  def check_token_type
    return render json: { errors: { 'token' => ['is invalid'] } }, status: :bad_request unless ["admin_login", "admin_login_refresh"].include?(@token.token_type)
  end

  def nutrient_managment_params
  	params.require(:data).require(:attributes).permit(:name, :name_hindi, :name_gujrati, :active)
  end

  def set_nutrient_managment
  	@nutrient_managment = BxBlockFarmDairy::NutrientManagment.find_by(id: params[:id])
  	return render json: { errors: 'Not found' },
               status: :not_found unless @nutrient_managment.present?
  end
end
