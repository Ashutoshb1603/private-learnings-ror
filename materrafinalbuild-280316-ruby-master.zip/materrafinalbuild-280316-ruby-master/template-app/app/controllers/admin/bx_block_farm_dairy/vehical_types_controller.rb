class Admin::BxBlockFarmDairy::VehicalTypesController < ApplicationController
	include BuilderJsonWebToken::JsonWebTokenValidation
	before_action :validate_json_web_token, :check_token_type, :check_admin_user
	before_action :set_vehical_type, only: [:update, :show, :destroy]
	def index
		vehical_types = BxBlockFarmDairy::VehicalType.all
    render json: vehical_types, status: :ok
	end

	def create
		vehical_type = BxBlockFarmDairy::VehicalType.new(vehical_type_params)

		if vehical_type.save
			render json: vehical_type, status: :created
		else
			render json: { errors: vehical_type.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	def update
		if @vehical_type.update(vehical_type_params)
			render json: @vehical_type, status: 200
		else
			render json: { errors: @vehical_type.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	def show
		render json: @vehical_type, status: 200
	end

	def destroy
		if @vehical_type.destroy
			render json: {deleted: true}
		else
			render json: { errors: @vehical_type.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	private

	def check_admin_user
  	@admin_account = AdminUser.admins.find_by_id(@token.id)
  	unless @admin_account.present?
  		return render json: {errors: [{account: 'Not Found'},]},
             status: :bad_request
  	end
  end

  def check_token_type
    return render json: { errors: { 'token' => ['is invalid'] } }, status: :bad_request unless ["admin_login", "admin_login_refresh"].include?(@token.token_type)
  end

  def vehical_type_params
  	params.require(:data).require(:attributes).permit(:name, :name_hindi, :name_gujrati, :active)
  end

  def set_vehical_type
  	@vehical_type = BxBlockFarmDairy::VehicalType.find_by(id: params[:id])
  	return render json: { errors: 'Not found' },
               status: :not_found unless @vehical_type.present?
  end
end
