class Admin::BxBlockFarmDairy::BioAgentsController < ApplicationController
	include BuilderJsonWebToken::JsonWebTokenValidation
	before_action :validate_json_web_token, :check_token_type, :check_admin_user
	before_action :set_bio_agent, only: [:update, :show, :destroy]
	def index
		bio_agents = BxBlockFarmDairy::BioAgent.all
    render json: bio_agents, status: :ok
	end

	def create
		bio_agent = BxBlockFarmDairy::BioAgent.new(bio_agent_params)

		if bio_agent.save
			render json: bio_agent, status: :created
		else
			render json: { errors: bio_agent.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	def update
		if @bio_agent.update(bio_agent_params)
			render json: @bio_agent, status: 200
		else
			render json: { errors: @bio_agent.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	def show
		render json: @bio_agent, status: 200
	end

	def destroy
		if @bio_agent.destroy
			render json: {deleted: true}
		else
			render json: { errors: @bio_agent.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	private

	def check_admin_user
  	@admin_account = AdminUser.admins.find_by_id(@token.id)
  	unless @admin_account.present?
  		return render json: {errors: [{account: 'Not Found'},]},
             status: :bad_request
  	end
  end

  def check_token_type
    return render json: { errors: { 'token' => ['is invalid'] } }, status: :bad_request unless ["admin_login", "admin_login_refresh"].include?(@token.token_type)
  end

  def bio_agent_params
  	params.require(:data).require(:attributes).permit(:name, :name_hindi, :name_gujrati, :active)
  end

  def set_bio_agent
  	@bio_agent = BxBlockFarmDairy::BioAgent.find_by(id: params[:id])
  	return render json: { errors: 'Not found' },
               status: :not_found unless @bio_agent.present?
  end
end
