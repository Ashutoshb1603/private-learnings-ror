module Admin
  class SessionsController < Devise::SessionsController
    before_action :set_admin_user

    def create
      return render json: { errors: { 'email or password' => ['is invalid'] } }, status: :unprocessable_entity unless @user.valid_password?(params[:password])
      email_otp = AccountBlock::EmailOtp.new(email: @user.email)
    	if email_otp.save
        # send_email_for email_otp
        render json: serialized_email_otp(email_otp, @user.id),
          status: :ok
      else
        render json: {
          errors: [email_otp.errors],
        }, status: :unprocessable_entity
      end
    end

    private

    def send_email_for(otp_record)
      SendOtpMailer.send_otp_to_email(@user.email, otp_record.pin).deliver_now
    end

    def serialized_email_otp(email_otp, account_id)
      token = token_for(email_otp, account_id)
      BxBlockForgotPassword::EmailOtpSerializer.new(
        email_otp,
        meta: { otp: email_otp.pin, otp_token: token }
      ).serializable_hash
    end

    def token_for(otp_record, account_id)
      BuilderJsonWebToken.encode(
        otp_record.id,
        1.months.from_now,
        token_type: "admin_email_otp",
        account_id: account_id
      )
    end

    def set_admin_user
      @user = AdminUser.admins.find_by_email(params[:email])
      return render json: {errors: [{email: 'is invalid'},]}, status: :unprocessable_entity unless @user.present?
    end
  end
end
