class Admin::BxBlockUserProfile::DistrictsController < ApplicationController
	include BuilderJsonWebToken::JsonWebTokenValidation
	before_action :validate_json_web_token, :check_token_type, :check_admin_user
	before_action :set_district, only: [:update, :show, :destroy]

	def index
		districts = BxBlockLocationDetails::District.all
    render json: districts, status: :ok
	end

	def create
		district = BxBlockLocationDetails::District.new(district_params)

		if district.save
			render json: district, status: :created
		else
			render json: { errors: district.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	def update
		if @district.update(district_params)
			render json: @district, status: 200
		else
			render json: { errors: @district.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	def show
		render json: @district, status: 200
	end

	def destroy
		if @district.destroy
			render json: {deleted: true}
		else
			render json: { errors: @district.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	private

	def check_admin_user
  	@admin_account = AdminUser.admins.find_by_id(@token.id)
  	unless @admin_account.present?
  		return render json: {errors: [{account: 'Not Found'},]},
             status: :bad_request
  	end
  end

  def check_token_type
    return render json: { errors: { 'token' => ['is invalid'] } }, status: :bad_request unless ["admin_login", "admin_login_refresh"].include?(@token.token_type)
  end

  def district_params
  	params.require(:data).require(:attributes).permit(:name, :state_id, :name_hindi, :name_gujrati, :active)
  end

  def set_district
  	@district = BxBlockLocationDetails::District.find_by(id: params[:id])
  	return render json: { errors: 'Not found' },
               status: :not_found unless @district.present?
  end
end