class Admin::BxBlockUserProfile::NumberBelongsTosController < ApplicationController
  include BuilderJsonWebToken::JsonWebTokenValidation
	before_action :validate_json_web_token, :check_token_type, :check_admin_user
	before_action :set_number_belongs_to, only: [:update, :show, :destroy]

	def index
		number_belongs_tos = BxBlockUserProfile::NumberBelongsTo.all
    render json: number_belongs_tos, status: :ok
	end

	def create
		number_belongs_to = BxBlockUserProfile::NumberBelongsTo.new(number_belongs_to_params)

		if number_belongs_to.save
			render json: number_belongs_to, status: :created
		else
			render json: { errors: number_belongs_to.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	def update
		if @number_belongs_to.update(number_belongs_to_params)
			render json: @number_belongs_to, status: 200
		else
			render json: { errors: @number_belongs_to.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	def show
		render json: @number_belongs_to, status: 200
	end

	def destroy
		if @number_belongs_to.destroy
			render json: {deleted: true}
		else
			render json: { errors: @number_belongs_to.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	private

	def check_admin_user
  	@admin_account = AdminUser.admins.find_by_id(@token.id)
  	unless @admin_account.present?
  		return render json: {errors: [{account: 'Not Found'},]},
             status: :bad_request
  	end
  end

  def check_token_type
    return render json: { errors: { 'token' => ['is invalid'] } }, status: :bad_request unless ["admin_login", "admin_login_refresh"].include?(@token.token_type)
  end

  def number_belongs_to_params
  	params.require(:data).require(:attributes).permit(:name, :name_hindi, :name_gujrati, :active)
  end

  def set_number_belongs_to
  	@number_belongs_to = BxBlockUserProfile::NumberBelongsTo.find_by(id: params[:id])
  	return render json: { errors: 'Not found' },
               status: :not_found unless @number_belongs_to.present?
  end
end
