class Admin::BxBlockUserProfile::HighestEducationsController < ApplicationController
	include BuilderJsonWebToken::JsonWebTokenValidation
	before_action :validate_json_web_token, :check_token_type, :check_admin_user
	before_action :set_highest_education, only: [:update, :show, :destroy]

	def index
		highest_educations = BxBlockUserProfile::HighestEducation.all
    render json: highest_educations, status: :ok
	end

	def create
		highest_education = BxBlockUserProfile::HighestEducation.new(highest_education_params)

		if highest_education.save
			render json: highest_education, status: :created
		else
			render json: { errors: highest_education.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	def update
		if @highest_education.update(highest_education_params)
			render json: @highest_education, status: 200
		else
			render json: { errors: @highest_education.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	def show
		render json: @highest_education, status: 200
	end

	def destroy
		if @highest_education.destroy
			render json: {deleted: true}
		else
			render json: { errors: @highest_education.errors.full_messages },
               status: :unprocessable_entity
		end
	end

	private

	def check_admin_user
  	@admin_account = AdminUser.admins.find_by_id(@token.id)
  	unless @admin_account.present?
  		return render json: {errors: [{account: 'Not Found'},]},
             status: :bad_request
  	end
  end

  def check_token_type
    return render json: { errors: { 'token' => ['is invalid'] } }, status: :bad_request unless ["admin_login", "admin_login_refresh"].include?(@token.token_type)
  end

  def highest_education_params
  	params.require(:data).require(:attributes).permit(:name, :name_hindi, :name_gujrati, :active)
  end

  def set_highest_education
  	@highest_education = BxBlockUserProfile::HighestEducation.find_by(id: params[:id])
  	return render json: { errors: 'Not found' },
               status: :not_found unless @highest_education.present?
  end
end
