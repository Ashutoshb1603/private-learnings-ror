class Admin::BxBlockAdminChat::ChatMessagesController < Admin::BxBlockAdminChat::ApplicationController
	include BuilderJsonWebToken::JsonWebTokenValidation
	before_action :validate_json_web_token, :check_token_type, :check_admin_user
	

	def create
    @chat = @admin_account.chats.find_by_id(message_params[:chat_id])
    unless @chat
      render json: {message: "Chat room is not valid or no longer exists" } and return
    end
    message = @chat.messages.new(message_params)
    message.admin_user_id = @admin_account.id

    if message.save
    	admin_user_ids = @chat.accounts_chats.select{|ac| ac.admin_user_id != @admin_account.id }.pluck(:admin_user_id).compact
    	user_ids = @chat.accounts_chats.select{|ac| ac.admin_user_id != @admin_account.id }.pluck(:account_id).compact
      title = "New Message from user #{@admin_account.first_name&.capitalize} #{@admin_account.last_name&.capitalize}"
      response = BxBlockPushNotifications::SendPushNotification.new(title: title, message: message, user_ids: user_ids, admin_user_ids: admin_user_ids, current_user: @admin_account, type: "new_message", chat_id: @chat.id, reply_message_user_id: message.reply_message_user_id, reply_message_admin_id: message.reply_message_admin_id).call
      created_dates = message.chat.accounts_chats.select{|ac| ac.admin_user_id != @admin_account.id }.map{|acc_chat|  BxBlockChat::ChatMessage.find_by(id: acc_chat.last_read_msg_id)&.created_at || Time.zone.now-100.years}
      serialization_options_obj = serialization_options
      serialization_options_obj[:params][:created_dates] = created_dates
      messages_hash = ::BxBlockChat::ChatMessageSerializer.new(message, serialization_options_obj).serializable_hash
      BxBlockPushNotifications::PushNotification.create(admin_user_id: message.admin_user_id, push_notificable_type: "BxBlockChat::ChatMessage", push_notificable_id: message.id, remarks: message.message) if response && (response.last && response.last[:status_code] == 200)
      messages_hash[:data][:attributes][:push_notification_response] = response

      render json: {:data => messages_hash[:data][:attributes]}, status: :created
    else
      render json: {errors: message.errors}, status: :unprocessable_entity
    end
  end

  def messages_delete
    messages = ::BxBlockChat::ChatMessage.where(id: params[:message_ids])
    if messages.present?
      messages.update_all(deleted: true)
      title = "Message deleted by user #{@admin_account&.first_name&.capitalize} #{@admin_account&.last_name&.capitalize}"
      admin_user_ids = messages.last&.chat&.accounts_chats&.select{|ac| ac.admin_user_id != @admin_account.id }&.pluck(:admin_user_id)
      user_ids = messages.last&.chat&.accounts_chats&.select{|ac| ac.admin_user_id != @admin_account.id }&.pluck(:account_id)
      response = BxBlockPushNotifications::SendPushNotification.new(title: title, message: messages.pluck(:id), user_ids: user_ids, admin_user_ids: admin_user_ids, current_user: @admin_account, type: "message_deleted", chat_id: messages.last&.chat&.id).call
      if response && (response.last && response.last[:status_code] == 200)
        messages.map{|msg|  BxBlockPushNotifications::PushNotification.create(admin_user_id: msg.admin_user_id, push_notificable_type: BxBlockChat::ChatMessage.to_s, push_notificable_id: msg.id, remarks: msg.message)}
      end
      render json: {deleted: true}
    else
      render json: {errors: "No message selected for delete"}, status: :unprocessable_entity
    end
  end

  def mark_read
    message = ::BxBlockChat::ChatMessage.find_by(id: message_params["message_id"])
    return render json: {errors: "Message Not found"} unless message.present?
    accounts_chat = message.chat&.accounts_chats&.where(admin_user_id: @admin_account&.id)
    if message_params["read"] && accounts_chat
      accounts_chat.update(last_read_msg_id: message_params["message_id"])
      title = "Message deleted by user #{@admin_account&.first_name&.capitalize} #{@admin_account&.last_name&.capitalize}"
      admin_user_ids = message.chat&.accounts_chats&.select{|ac| ac.admin_user_id != @admin_account.id }&.pluck(:admin_user_id)
      user_ids = message.chat&.accounts_chats&.select{|ac| ac.admin_user_id != @admin_account.id }&.pluck(:account_id)
      BxBlockPushNotifications::SendPushNotification.new(title: title, message: message, user_ids: user_ids, admin_user_ids: admin_user_ids, current_user: @admin_account, type: "message_read", chat_id: message&.chat&.id).call
      BxBlockPushNotifications::PushNotification.create(admin_user_id: message.admin_user_id, push_notificable_type: BxBlockChat::ChatMessage.to_s, push_notificable_id: message.id, remarks: message.message) if response && (response[:status_code] == 200)
      render json: {data: {last_read_msg: accounts_chat, status: "Marked Read"}}
    else
      render json: {errors: "Not found"}
    end
  end

  private

  def check_admin_user
  	@admin_account = AdminUser.admins.find_by_id(@token.id)
  	unless @admin_account.present?
  		return render json: {errors: [{account: 'Not Found'},]},
             status: :unprocessable_entity
  	end
  end

  def check_token_type
    return render json: { errors: { 'token' => ['is invalid'] } }, status: :unprocessable_entity unless ["admin_login", "admin_login_refresh"].include?(@token.token_type)
  end

  def message_params
    params.require(:data).require(:attributes).permit(:message, :account_id, :admin_user_id, :chat_id, :attachment, :read, :message_id, :reply_message_user_id, :reply_message_id)
  end
end
