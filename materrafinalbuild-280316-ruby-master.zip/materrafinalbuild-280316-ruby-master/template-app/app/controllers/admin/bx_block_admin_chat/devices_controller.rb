class Admin::BxBlockAdminChat::DevicesController < ApplicationController
	include BuilderJsonWebToken::JsonWebTokenValidation
	before_action :validate_json_web_token, :check_token_type, :check_admin_user

	def index
    render json: {
    	data: {
    	  account: @admin_account,
    	  devices: AccountBlock::DeviceTokenSerializer.new(@admin_account.devices)
    	}
    }, status: :ok
  end

  def create
    params[:data][:attributes] = params[:data][:attributes].merge(admin_user_id: @admin_account.id)
    devices = AccountBlock::Device.where(token: device_params[:token]) if device_params[:token].present?
    call_devices = AccountBlock::Device.where(call_token: device_params[:call_token]) if device_params[:call_token].present?

    unless devices.present? || call_devices.present?
      device = AccountBlock::Device.new(device_params)
      device.save!
    else
      devices.destroy_all if devices.present? && devices.count > 0
      call_devices.destroy_all if call_devices.present? && call_devices.count > 0

      device = AccountBlock::Device.new(device_params)
      device.save!
    end

    render json: {
      data: {
        account: @admin_account,
        devices: AccountBlock::DeviceTokenSerializer.new(device)
      }
    }, status: :ok
  end

  def update
    device = AccountBlock::Device.find_by_id(params[:id])
    if device.present?
      device.update(device_params)
      render json: {
      	data: {
      	  account: @admin_account,
      	  devices: AccountBlock::DeviceTokenSerializer.new(device)
      	}
      }, status: 200
    else
      render :json => {'errors' => ['Record not found']}, :status => :not_found
    end
  end

  private

  def device_params
    params.require(:data).require(:attributes).permit(:token, :platform, :call_token, :account_id, :admin_user_id)
  end

  def check_admin_user
  	@admin_account = AdminUser.admins.find_by_id(@token.id)
  	unless @admin_account.present?
  		return render json: {errors: [{account: 'Not Found'},]},
             status: :unprocessable_entity
  	end
  end

  def check_token_type
    return render json: { errors: { 'token' => ['is invalid'] } }, status: :unprocessable_entity unless ["admin_login", "admin_login_refresh"].include?(@token.token_type)
  end
end
