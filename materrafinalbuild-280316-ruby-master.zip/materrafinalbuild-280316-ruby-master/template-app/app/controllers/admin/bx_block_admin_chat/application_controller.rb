module Admin
  module BxBlockAdminChat
    class ApplicationController < BuilderBase::ApplicationController
      include BuilderJsonWebToken::JsonWebTokenValidation

      before_action :validate_json_web_token

      rescue_from ActiveRecord::RecordNotFound, :with => :not_found

      private

      def not_found
        render :json => {'errors' => ['Record not found']}, :status => :not_found
      end

      def current_admin_user
        begin
          @current_admin_user = AdminUser.admins.find(@token.id)
        rescue ActiveRecord::RecordNotFound => e
          return render json: {errors: [
            {message: 'Please login again.'},
          ]}, status: :unprocessable_entity
        end
      end

      def serialization_options
        { params: { host: request.protocol + request.host_with_port, page: params[:page], current_user: current_admin_user } }
      end


      def chat_message_serialization_options
        { params: { host: request.protocol + request.host_with_port, chat_id: params[:chat_id] } }
      end
    end
  end
end
