module Admin
	module BxBlockAdminChat
		class AdminChatsController < ApplicationController
			include BuilderJsonWebToken::JsonWebTokenValidation
			before_action :validate_json_web_token, :check_token_type, :check_admin_user

			def index
				chats = @admin_account.chats
				render json: ChatListApiSerializer.new(chats, serialization_options).serializable_hash, status: :ok
			end

			def create
				normal_accounts = AccountBlock::Account.where(id: params[:account_ids])
				admin_accounts = AdminUser.admins.where(id: params[:admin_ids])
				accounts = normal_accounts + admin_accounts
				return render json: { 'errors' => ['Record not found'] }, status: :not_found unless accounts.present?
				if accounts.count < 2
					account = accounts.first
					chat_ids = BxBlockChat::AccountsChatsBlock.where(admin_user_id: @admin_account.id).pluck(:chat_id)
					chat_boxs = BxBlockChat::AccountsChatsBlock.where(chat_id: chat_ids).where(account_id: account.id)
					if chat_boxs.empty?
						friendly_name = "#{account.first_name}_#{account.last_name}"
						chat = @admin_account.chats.create(name: friendly_name, chat_type: 1)
						BxBlockChat::AccountsChatsBlock.create(account_id: account.id, chat_id: chat.id)
            render json: {data: {
                  chat_id: chat.id,
                  current_chat_participant: {
                    current_chat_admin_participant_id: @admin_account.id,
                  },
                    participants: [account, @admin_account],
                  
              }}, status: :ok
					else
						render json: {data: {
	                chat_id: chat_boxs.first.chat_id,
	                current_chat_participant: {
	                  current_chat_admin_participant_id: @admin_account.id,
	                },
	                  participants: [account, @admin_account],
	            }}, status: :ok
					end
				else
					chat = @admin_account.chats.create(name: params[:name], chat_type: 2)
					normal_accounts.each do |account|
						BxBlockChat::AccountsChatsBlock.create(account_id: account.id, chat_id: chat.id)
					end
					admin_accounts.each do |admin_account|
						BxBlockChat::AccountsChatsBlock.create(admin_user_id: admin_account.id, chat_id: chat.id)
					end
					render json: {data: {
                  chat_id: chat.id,
                  current_chat_participant: {
                    current_chat_admin_participant_id: @admin_account.id,
                  },
                    participants: chat.accounts + chat.admin_users,
                  
              }}, status: :ok
				end if accounts.present?
			end

			def show
		    chat = BxBlockChat::Chat.includes(:accounts, :admin_users).find(params[:id])
		    render json: Admin::BxBlockAdminChat::ChatApiSerializer.new(chat, serialization_options).serializable_hash, status: :ok
		  end

			def search_chats
		    chat = BxBlockChat::Chat.find(params[:chat_id])

		    serialization_options_obj = serialization_options
		    serialization_options_obj[:params][:message_search] = params[:message_search]
		    serialization_options_obj[:params][:page] = params[:page].present? ? params[:page] : 1 

		    chat_search_data = Admin::BxBlockAdminChat::ChatApiSerializer.new(chat, serialization_options_obj).serializable_hash
		    render json: chat_search_data, status: :ok
		  end

		  def search
	      @chats = @admin_account
	        .chats
	        .where('name ILIKE :search', search: "%#{search_params[:query]}%")
	      render json: Admin::BxBlockAdminChat::ChatApiSerializer.new(@chats, serialization_options).serializable_hash, status: :ok
	    end

	    def history
	      chat = BxBlockChat::Chat.find(params[:chat_id])
	      chat_data = Admin::BxBlockAdminChat::ChatApiSerializer.new(chat, serialization_options).serializable_hash
	      render json: chat_data, status: :ok
	    end

	    def media_history
	      chat = BxBlockChat::Chat.find(params[:chat_id])
	      
	      serialization_options_obj = serialization_options
	      serialization_options_obj[:params][:attachment_only] = true
	      serialization_options_obj[:params][:page] = params[:page]

	      chat_media_data = Admin::BxBlockAdminChat::ChatApiSerializer.new(chat, serialization_options_obj).serializable_hash
	      render json: chat_media_data, status: :ok
	      
	    end

	    def add_chat_user
        @new_cats = []
        accounts = AccountBlock::Account.where(id: params[:account_ids])
        admin_accounts = AdminUser.admins.where(id: params[:admin_ids])
        if accounts.present? || admin_accounts.present?
          accounts.each do |account|
            chat_user = BxBlockChat::AccountsChatsBlock.new(chat_id: params[:chat_id],
                                              account_id: account.id)

            if chat_user.save
              @new_cats.push(chat_user.chat)
            else
              return render json: {errors: chat_user.errors}, status: :unprocessable_entity
            end
          end

          admin_accounts.each do |account|
            chat_user = BxBlockChat::AccountsChatsBlock.new(chat_id: params[:chat_id],
                                              admin_user_id: account.id)

            if chat_user.save
              @new_cats.push(chat_user.chat)
            else
              return render json: {errors: chat_user.errors}, status: :unprocessable_entity
            end
          end


          render json: BxBlockChat::ChatOnlySerializer.new(@new_cats, meta: {}).serializable_hash, status: :created
        else
          return render json: { 'errors' => ['Record not found'] }, status: :not_found
        end
      end

      def leave_chat
        chat = BxBlockChat::Chat.find(params[:chat_id])
        return render json: {errors: [
          {account: 'Add new adimin before leaving this chat'},
        ]}, status: :unprocessable_entity if chat&.last_admin?(@admin_account)

        total_users = chat.accounts + chat.admin_users
        if total_users.count <= 2
          chat.delete
        else
          BxBlockChat::AccountsChatsBlock
            .where(admin_user_id: @admin_account.id, chat_id: params[:chat_id])
            .last
            .delete
        end

        render json: 'Left the chat successfully', status: :ok
      end

      def remove_chat_user
      	chat = BxBlockChat::Chat.find_by_id(params[:chat_id])
      	user = AccountBlock::Account.find_by_id(params[:account_id])
        admin_user = AdminUser.admins.find_by_id(params[:admin_user_id])
        account = admin_user.present? ? admin_user : user
        return render json: {errors: [
          {account: 'Add new adimin before leaving this chat'},
        ]}, status: :unprocessable_entity if chat&.last_admin?(account)

        total_users = chat.accounts + chat.admin_users
        if total_users.count <= 2
          chat.delete
        else
          chat_account = admin_user.present? ? BxBlockChat::AccountsChatsBlock
            .where(admin_user_id: account.id, chat_id: params[:chat_id])
            .last : BxBlockChat::AccountsChatsBlock
            .where(account_id: account.id, chat_id: params[:chat_id])
            .last

          chat_account.delete
        end

        render json: 'Removed from the chat successfully', status: :ok
      end

			private

			def check_admin_user
	    	@admin_account = AdminUser.admins.find_by_id(@token.id)
	    	unless @admin_account.present?
	    		return render json: {errors: [{account: 'Not Found'},]},
	               status: :unprocessable_entity
	    	end
	    end

	    def search_params
	      params.permit(:query)
	    end

	    def check_token_type
	      return render json: { errors: { 'token' => ['is invalid'] } }, status: :unprocessable_entity unless ["admin_login", "admin_login_refresh"].include?(@token.token_type)
	    end
	  end
	end
end
