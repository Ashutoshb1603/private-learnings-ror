module Admin
  module BxBlockPhase
    class PhasesController < ApplicationController
      include BuilderJsonWebToken::JsonWebTokenValidation
      before_action :validate_json_web_token

      def create
        @phase_group = ::BxBlockCalendar::PhaseGroup.new(phase_params)
        if @phase_group.save
          data = ::BxBlockCalendar::PhaseGroupSerializer.new(@phase_group).serializable_hash
          render json: data, status: :ok
        else
          render json: {errors: @phase_group.errors}, status: :unprocessable_entity
        end
      end

      def update
        @phase_group = ::BxBlockCalendar::PhaseGroup.find(params[:id])
        if @phase_group.update(phase_params)
          data = ::BxBlockCalendar::PhaseGroupSerializer.new(@phase_group).serializable_hash
          render json: data, status: :ok
        else
          render json: {errors: @phase_group.errors}, status: :unprocessable_entity
        end
      end

      def index
        phases = ::BxBlockCalendar::Phase.all
        data = ::BxBlockCalendar::PhaseSerializer.new(phases, serialization_options).serializable_hash
        render json: data, status: :ok
      end

      def show
        phase_group = ::BxBlockCalendar::PhaseGroup.find(params[:id])
        if phase_group.present?
         data = ::BxBlockCalendar::PhaseGroupSerializer.new(phase_group).serializable_hash
         render json: data, status: :ok
        else
          render json: {errors: phase_group.errors}, status: :unprocessable_entity
        end
      end

      def get_phase_activity_progress
        phase_activity_progress = ::BxBlockCalendar::PhaseActivityProgress.find(params[:phase_activity_progress_id])
        data = ::BxBlockCalendar::PhaseActivityProgressSerializer.new(phase_activity_progress).serializable_hash
        render json: data, status: :ok
      end

      def get_sub_activity_progress
        sub_activity_progress = ::BxBlockCalendar::SubActivityProgress.find_by(id: params[:sub_activity_progress])
        data = ::BxBlockCalendar::SubActivityProgressSerializer.new(sub_activity_progress, serialization_options).serializable_hash
        render json: data, status: :ok
      end

      def destroy
        phase_group = ::BxBlockCalendar::PhaseGroup.find(params[:id])
        if phase_group.destroy
          render json: {deleted: true}
        else
          render json: {errors: "phase group is not deleted"}, status: :unprocessable_entity
        end
      end

      private
      def phase_params
        params.permit(phases_attributes: [:id, :language, :name, :start_day, :end_day, :_destroy, phase_activity_progresses_attributes: [:id, :start_day, :end_day, :phase_activity_id, :_destroy, sub_activity_progresses_attributes: [:id, :before_after_day, :description, :attachment, :is_completed, :phase_sub_activity_id, :_destroy, input_details_attributes: [:id, :key, :value, :_destroy]]]]).merge({ owner_type: "AdminUser", owner_id: current_admin_user.id })
      end
    end
  end
end
