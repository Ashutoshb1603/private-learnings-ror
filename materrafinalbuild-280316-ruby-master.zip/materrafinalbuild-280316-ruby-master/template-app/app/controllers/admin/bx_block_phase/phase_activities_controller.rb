module Admin
	module BxBlockPhase
		class PhaseActivitiesController < ApplicationController
			include BuilderJsonWebToken::JsonWebTokenValidation
			before_action :validate_json_web_token
      
      def index
	      phase_activities = BxBlockCalendar::PhaseActivity.all
	      data = ::BxBlockCalendar::PhaseActivitySerializer.new(phase_activities).serializable_hash
	      render json: data, status: :ok
	    end

			def create
        phase_activity = ::BxBlockCalendar::PhaseActivity.new(phase_activity_params)
        if phase_activity.save
	        data = ::BxBlockCalendar::PhaseActivitySerializer.new(phase_activity).serializable_hash
	        render json: data, status: :ok
	      else
          render json: phase_activity.errors.full_messages, status: :unprocessable_entity
        end
			end

			def update
	     	phase_activity = ::BxBlockCalendar::PhaseActivity.find(params[:id])
	       if phase_activity.update(phase_activity_params)
	     	  data = ::BxBlockCalendar::PhaseActivitySerializer.new(phase_activity).serializable_hash
	        render json: data, status: :ok
	      else
          render json: phase_activity.errors.full_messages, status: :unprocessable_entity
	      end
		  end

	    def destroy
        phase_activity = ::BxBlockCalendar::PhaseActivity.find(params[:id])
        if phase_activity.destroy
        	render json: {deleted: true}
	      else
	        render json: phase_activity.errors.full_messages, status: :unprocessable_entity
	      end
	    end

	    def show
        phase_activity = ::BxBlockCalendar::PhaseActivity.find(params[:id])
        if phase_activity.present?
	        data = ::BxBlockCalendar::PhaseActivitySerializer.new(phase_activity).serializable_hash
	        render json: data, status: :ok
	      else
         render json: {errors: phase_activity.errors}, status: :unprocessable_entity
	      end
	    end

	    def get_sub_activity
	        sub_activity = ::BxBlockCalendar::PhaseSubActivity.find(params[:phase_sub_activity_id])
	        render json: {data: {
	        	      id: sub_activity.phase_activity.id,
	                  name: sub_activity.phase_activity.name,
	                  type: "phase activity",
	                  phase_sub_activity: {
	                  	id: sub_activity.id,
	                    name: sub_activity.name,
	                  }
	              }}, status: :ok
	    end

	    private

	    def phase_activity_params
	      params.require(:phase_activity).permit(:name, :name_hindi, :name_gujarati, phase_sub_activities_attributes: [:id, :name, :name_hindi, :name_gujarati, :_destroy])
	    end
		end
	end
end
