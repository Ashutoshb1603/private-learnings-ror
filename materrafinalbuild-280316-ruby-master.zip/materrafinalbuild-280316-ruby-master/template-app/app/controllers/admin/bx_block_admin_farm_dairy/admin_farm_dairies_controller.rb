# frozen_string_literal: true
module Admin
  module BxBlockAdminFarmDairy
    class AdminFarmDairiesController < ApplicationController
      include BuilderJsonWebToken::JsonWebTokenValidation
      before_action :validate_json_web_token

      def show
        data = []
        AccountBlock::Account::FARM_DAIRY_MODEL.each do |farm|
          farm.each do |key, values|
            values.each do |final_value|
              records = final_value.constantize.where(account_id: params[:id])
              serializer = final_value + "Serializer"
              data << serializer.constantize.new(records)
            end
          end
        end
        render json: data
      end

      def update
        account = AccountBlock::Account.find_by(id: params[:id])
        data = []
        ActiveRecord::Base.transaction do
          AccountBlock::Account::ADMIN_FARM_DAIRY_MODEL.each do |farm|
            farm.each do |key, values|
              values.each do |final_value|
                const = ("#{key.to_s.parameterize(separator: '_')}_params")
                 parameters = (eval const) 
                 next if parameters.empty?
                 first_key = parameters.keys[0]
                 parameters[first_key].each do |param|
                  param_data = param.merge(account_id: account.id)
                  if(param.keys.include?("id") && !param.keys.include?("_destroy")) 
                    activity = final_value.constantize.find_by(id: param[:id])
                    if activity&.update(param_data)
                      serializer = final_value + "Serializer"   
                      data << serializer.constantize.new(activity)
                    else
                      return render json: {errors: "record not found"}
                    end
                  elsif(param.keys.include?("id") && param.keys.include?("_destroy"))
                    activity = final_value.constantize.find_by(id: param[:id])
                    if activity.destroy
                      data << "deleted true"
                    else
                      return render json: {errors: "record not found"}
                    end
                  else
                   new_record = final_value.constantize.create(param_data)
                   serializer = final_value + "Serializer"
                   data << serializer.constantize.new(new_record)
                  end
                 end
              end
            end
          end
        end
         render json: data 
      end

      private

      def nutrient_management_params
       params.require(:farm_dairy).permit(nutrient: [:id, :nutrient_managment_id, :quantity_of_nutrient_id, :unit_of_measure_id, :date_of_application, :labor_cost, :fertilizer_cost, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year, :_destroy])
      end

      def sowing_params
       params.require(:farm_dairy).permit(sowing: [:id, :date_of_sowing, :crop_name_id, :crop_area_id, :unit_of_measure_id, :crop_season_id, :crop_type_id, :crop_mapping, :variety_id, :seed_source_id, :number_of_packet, :quantity_in_kg, :seed_price, :gmo_seed, :seed_treatment, :bio_agent_id, :bio_agent_cost, :account_id, :land_detail_id, :_destroy])
      end

      def pest_management_bio_params
        params.require(:farm_dairy).permit(pest_management_bio: [:id, :date_of_release, :quantity, :cost_of_input, :bio_agent_release_id, :labor_cost, :pest_managment_id, :unit_of_measure_id, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year, :_destroy])
      end

      def pest_management_foliar_spray_params
        params.require(:farm_dairy).permit(pest_management_foliar_spray: [:id, :date_of_application, :quantity_of_pesticide, :machine_cost_of_spraying, :pesticide_cost, :labor_cost, :pest_managment_id, :unit_of_measure_id, :pesticide_id, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year, :_destroy])
      end

      def pest_management_trap_params
        params.require(:farm_dairy).permit(pest_management_trap: [:id, :date_of_installation, :number_of_trap, :cost_of_trap, :type_of_trap_id, :labor_cost, :pest_managment_id, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year, :_destroy])
      end

      def pre_sowing_params
        params.require(:farm_dairy).permit(pre_sowing: [:pre_sowing_activity_id, :date, :cost, :account_id, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year, :_destroy])
      end

      def pre_sowing_compost_params
        params.require(:farm_dairy).permit(pre_sowing_compost: [:pre_sowing_activity_id, :date, :compost_cost, :labor_cost, :account_id, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year, :_destroy])
      end

      def irrigation_params
        params.require(:farm_dairy).permit(irrigation: [:id, :date_of_irrigation, :hours_of_irrigation, :labor_cost, :source_irrigation_id, :account_id, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year, :_destroy])
      end

      def irrigation_drip_params
        params.require(:farm_dairy).permit(irrigation_drip: [:id, :date_of_irrigation, :hours_of_irrigation, :spacing_of_dripper, :drip_irrigated_area, :row_to_row_spacing, :type_irrigation_id, :source_irrigation_id, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year, :_destroy])
      end

      def irrigation_sprinkler_params
        params.require(:farm_dairy).permit(irrigation_sprinkler: [:id, :hours_of_irrigation, :labor_cost, :number_of_nozels, :type_irrigation_id, :source_irrigation_id, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year, :_destroy])
      end

      def harvest_params
        params.require(:farm_dairy).permit(harvest: [:id, :date_of_picking, :quantity_picked, :total_picking_cost, :storage_type_id, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year, :_destroy])
      end

      def gap_filling_params
        params.require(:farm_dairy).permit(gap_filling: [:id, :date, :labor_cost, :price_of_seed, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year, :_destroy])
      end

      def sale_params
        params.require(:farm_dairy).permit(sale: [:id, :date_of_sale, :quantity_of_cotton_sold, :cotton_price, :total_amount, :distance_from_farmer_location_to_buyer, :buyer_name, :transportation_cost, :labor_cost_of_load_and_unload, :vehical_type_id, :crop_season_id, :crop_start_year, :crop_end_year, :_destroy])
      end

      def weed_management_params
        params.require(:farm_dairy).permit(weed_management: [:id, :weeding_date, :machine_charges, :labor_cost, :quantity_of_weedicide, :cost_of_weedicide, :labor_cost_of_spraying, :weeding_type_id, :weedicide_id, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year, :_destroy])
      end
    end
  end
end