class Admin::BxBlockProfileBio::TypeIrrigationsController < ApplicationController
  include BuilderJsonWebToken::JsonWebTokenValidation
  before_action :validate_json_web_token, :check_token_type, :check_admin_user
  before_action :set_type_irrigation, only: [:update, :show, :destroy]

  def index
    type_irrigations = BxBlockProfileBio::TypeIrrigation.all
    render json: type_irrigations, status: :ok
  end

  def create
    type_irrigation = BxBlockProfileBio::TypeIrrigation.new(type_irrigation_params)

    if type_irrigation.save
      render json: type_irrigation, status: :created
    else
      render json: { errors: type_irrigation.errors.full_messages },
               status: :unprocessable_entity
    end
  end

  def update
    if @type_irrigation.update(type_irrigation_params)
      render json: @type_irrigation, status: 200
    else
      render json: { errors: @type_irrigation.errors.full_messages },
               status: :unprocessable_entity
    end
  end

  def show
    render json: @type_irrigation, status: 200
  end

  def destroy
    if @type_irrigation.destroy
      render json: {deleted: true}
    else
      render json: { errors: @type_irrigation.errors.full_messages },
               status: :unprocessable_entity
    end
  end

  private

  def check_admin_user
    @admin_account = AdminUser.admins.find_by_id(@token.id)
    unless @admin_account.present?
      return render json: {errors: [{account: 'Not Found'},]},
             status: :bad_request
    end
  end

  def check_token_type
    return render json: { errors: { 'token' => ['is invalid'] } }, status: :bad_request unless ["admin_login", "admin_login_refresh"].include?(@token.token_type)
  end

  def type_irrigation_params
    params.require(:data).require(:attributes).permit(:label, :label_hindi, :label_gujrati, :active)
  end

  def set_type_irrigation
    @type_irrigation = BxBlockProfileBio::TypeIrrigation.find_by(id: params[:id])
    return render json: { errors: 'Not found' },
               status: :not_found unless @type_irrigation.present?
  end
end