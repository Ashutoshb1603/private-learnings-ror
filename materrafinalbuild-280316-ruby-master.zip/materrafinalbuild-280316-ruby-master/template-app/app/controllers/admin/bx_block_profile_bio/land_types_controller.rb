class Admin::BxBlockProfileBio::LandTypesController < ApplicationController
  include BuilderJsonWebToken::JsonWebTokenValidation
  before_action :validate_json_web_token, :check_token_type, :check_admin_user
  before_action :set_land_type, only: [:update, :show, :destroy]

  def index
    land_types = BxBlockProfileBio::LandType.all
    render json: land_types, status: :ok
  end

  def create
    land_type = BxBlockProfileBio::LandType.new(land_type_params)

    if land_type.save
      render json: land_type, status: :created
    else
      render json: { errors: land_type.errors.full_messages },
               status: :unprocessable_entity
    end
  end

  def update
    if @land_type.update(land_type_params)
      render json: @land_type, status: 200
    else
      render json: { errors: @land_type.errors.full_messages },
               status: :unprocessable_entity
    end
  end

  def show
    render json: @land_type, status: 200
  end

  def destroy
    if @land_type.destroy
      render json: {deleted: true}
    else
      render json: { errors: @land_type.errors.full_messages },
               status: :unprocessable_entity
    end
  end

  private

  def check_admin_user
    @admin_account = AdminUser.admins.find_by_id(@token.id)
    unless @admin_account.present?
      return render json: {errors: [{account: 'Not Found'},]},
             status: :bad_request
    end
  end

  def check_token_type
    return render json: { errors: { 'token' => ['is invalid'] } }, status: :bad_request unless ["admin_login", "admin_login_refresh"].include?(@token.token_type)
  end

  def land_type_params
    params.require(:data).require(:attributes).permit(:label, :label_hindi, :label_gujrati, :active)
  end

  def set_land_type
    @land_type = BxBlockProfileBio::LandType.find_by(id: params[:id])
    return render json: { errors: 'Not found' },
               status: :not_found unless @land_type.present?
  end
end