class Admin::BxBlockProfileBio::SoilTexturesController < ApplicationController
  include BuilderJsonWebToken::JsonWebTokenValidation
  before_action :validate_json_web_token, :check_token_type, :check_admin_user
  before_action :set_soil_texture, only: [:update, :show, :destroy]

  def index
    soil_textures = BxBlockProfileBio::SoilTexture.all
    render json: soil_textures, status: :ok
  end

  def create
    soil_texture = BxBlockProfileBio::SoilTexture.new(soil_texture_params)

    if soil_texture.save
      render json: soil_texture, status: :created
    else
      render json: { errors: soil_texture.errors.full_messages },
               status: :unprocessable_entity
    end
  end

  def update
    if @soil_texture.update(soil_texture_params)
      render json: @soil_texture, status: 200
    else
      render json: { errors: @soil_texture.errors.full_messages },
               status: :unprocessable_entity
    end
  end

  def show
    render json: @soil_texture, status: 200
  end

  def destroy
    if @soil_texture.destroy
      render json: {deleted: true}
    else
      render json: { errors: @soil_texture.errors.full_messages },
               status: :unprocessable_entity
    end
  end

  private

  def check_admin_user
    @admin_account = AdminUser.admins.find_by_id(@token.id)
    unless @admin_account.present?
      return render json: {errors: [{account: 'Not Found'},]},
             status: :bad_request
    end
  end

  def check_token_type
    return render json: { errors: { 'token' => ['is invalid'] } }, status: :bad_request unless ["admin_login", "admin_login_refresh"].include?(@token.token_type)
  end

  def soil_texture_params
    params.require(:data).require(:attributes).permit(:label, :label_hindi, :label_gujrati, :active)
  end

  def set_soil_texture
    @soil_texture = BxBlockProfileBio::SoilTexture.find_by(id: params[:id])
    return render json: { errors: 'Not found' },
               status: :not_found unless @soil_texture.present?
  end
end