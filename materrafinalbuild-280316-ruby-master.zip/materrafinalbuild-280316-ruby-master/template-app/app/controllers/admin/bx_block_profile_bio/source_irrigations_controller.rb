class Admin::BxBlockProfileBio::SourceIrrigationsController < ApplicationController
  include BuilderJsonWebToken::JsonWebTokenValidation
  before_action :validate_json_web_token, :check_token_type, :check_admin_user
  before_action :set_source_irrigation, only: [:update, :show, :destroy]

  def index
    source_irrigations = BxBlockProfileBio::SourceIrrigation.all
    render json: source_irrigations, status: :ok
  end

  def create
    source_irrigation = BxBlockProfileBio::SourceIrrigation.new(source_irrigation_params)

    if source_irrigation.save
      render json: source_irrigation, status: :created
    else
      render json: { errors: source_irrigation.errors.full_messages },
               status: :unprocessable_entity
    end
  end

  def update
    if @source_irrigation.update(source_irrigation_params)
      render json: @source_irrigation, status: 200
    else
      render json: { errors: @source_irrigation.errors.full_messages },
               status: :unprocessable_entity
    end
  end

  def show
    render json: @source_irrigation, status: 200
  end

  def destroy
    if @source_irrigation.destroy
      render json: {deleted: true}
    else
      render json: { errors: @source_irrigation.errors.full_messages },
               status: :unprocessable_entity
    end
  end

  private

  def check_admin_user
    @admin_account = AdminUser.admins.find_by_id(@token.id)
    unless @admin_account.present?
      return render json: {errors: [{account: 'Not Found'},]},
             status: :bad_request
    end
  end

  def check_token_type
    return render json: { errors: { 'token' => ['is invalid'] } }, status: :bad_request unless ["admin_login", "admin_login_refresh"].include?(@token.token_type)
  end

  def source_irrigation_params
    params.require(:data).require(:attributes).permit(:label, :label_hindi, :label_gujrati, :active)
  end

  def set_source_irrigation
    @source_irrigation = BxBlockProfileBio::SourceIrrigation.find_by(id: params[:id])
    return render json: { errors: 'Not found' },
               status: :not_found unless @source_irrigation.present?
  end
end