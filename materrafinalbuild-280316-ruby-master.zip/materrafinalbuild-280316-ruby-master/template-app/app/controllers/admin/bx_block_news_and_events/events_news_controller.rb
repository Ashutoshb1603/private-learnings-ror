class Admin::BxBlockNewsAndEvents::EventsNewsController < ApplicationController
	include BuilderJsonWebToken::JsonWebTokenValidation
	before_action :validate_json_web_token, :check_token_type, :check_admin_user


	def index
    events_news = @admin_account.admin_events.map{|event| event.events_news}
    render json: events_news, status: :ok
	end

	def create
		@admin_event = @admin_account.admin_events.create
		if @admin_event
			events_news = @admin_event.events_news.create(events_news_params)
			if events_news
				notify_accounts(events_news)
       		    data = ::BxBlockNewsAndEvents::EventsNewsSerializer.new(events_news).serializable_hash
                render json: data, status: :ok
			else
				return render json: {errors: events_news.errors.full_messages}
			end
		end
	end

	def show
    events_news = BxBlockNewsAndEvents::EventsNews.find_by(id: params[:id])
    if events_news.present?
    	data = ::BxBlockNewsAndEvents::EventsNewsSerializer.new(events_news).serializable_hash
      render json: data, status: :ok
    else
      return render json: {errors: "can't find events"}
    end
	end

	def update
    events_news = BxBlockNewsAndEvents::EventsNews.find_by(id: params[:id])
    if events_news.update(events_news_params)
    	data = ::BxBlockNewsAndEvents::EventsNewsSerializer.new(events_news).serializable_hash
      render json: data, status: :ok
    else
      return render json: {errors: "can't find events"}
    end
	end

	def destroy
    events_news = BxBlockNewsAndEvents::EventsNews.find_by(id: params[:id])
    if events_news.present?
    	if events_news.destroy
		  	render json: {deleted: true}
		  else
			  render json: { errors: events_news.errors.full_messages },
               status: :unprocessable_entity
	    end
    else
      return render json: {errors: "can't find events"}
    end
	end

	private

	def check_admin_user
		@admin_account = AdminUser.find_by_id(@token.id)
		unless @admin_account.present?
			return render json: {errors: [{account: 'Not Found'},]},
           	status: :bad_request
		end
	end

	def check_token_type
  	return render json: { errors: { 'token' => ['is invalid'] } }, status: :bad_request unless ["admin_login", "admin_login_refresh"].include?(@token.token_type)
	end

	def events_news_params
  		params.require(:data).permit(:name_hindi, :name_english, :name_gujarati, :news_event_type, :language, :description, :event_date, :event_time, :image)
    end

    def notify_accounts(events_news)
      accounts =::AccountBlock::Account.where(id: params[:data][:account_ids])
      accounts.each do |account|
        events_account = events_news.events_news_accounts.new(account_id: account.id)
        if events_account.save
         BxBlockPushNotifications::PushNotification.create(account_id: account.id, push_notificable_type: "BxBlockNewsAndEvents::EventsNews", push_notificable_id: events_news.id, remarks: "events_news.messag")
        else
          return render json: {errors: "events account is not created"} 
        end
      end
    end
end
