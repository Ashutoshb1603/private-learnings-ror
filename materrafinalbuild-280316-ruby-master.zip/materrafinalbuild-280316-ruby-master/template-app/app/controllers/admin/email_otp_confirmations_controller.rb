module Admin
	class EmailOtpConfirmationsController < ApplicationController
		include BuilderJsonWebToken::JsonWebTokenValidation
		before_action :validate_json_web_token, :check_token_type, except: [:google_sign_in]


		def create
      @email_otp = AccountBlock::EmailOtp.find_by_id(@token.id)
      return render json: {errors: [
        {account: 'Not Found'},
      ]}, status: :unprocessable_entity unless @email_otp.present?

      if @email_otp.valid_until < Time.current
        @email_otp.destroy

        return render json: {errors: [
          {pin: 'This Pin has expired, please request a new pin code.'},
        ]}, status: :unauthorized
      end

      if @email_otp.pin.to_s == params['pin'].to_s
        @email_otp.activated = true
        @email_otp.save
        account= AdminUser.admins.find_by(email: @email_otp.email)
        return render json: {errors: [
          {account: 'Not Found'},
        ]}, status: :unprocessable_entity unless account.present?
        token, refresh_token = generate_tokens(account.id)

        render json: {meta: {
          token: token,
          refresh_token: refresh_token,
          id: account.id
        }}
      else
        return render json: {errors: [
          {pin: 'Invalid Pin for Email'},
        ]}, status: :unprocessable_entity
      end
		end

		def resend_otp
			@email_otp = AccountBlock::EmailOtp.find_by_id(@token.id)
		  return render json: {errors: [{email: 'Not Found'},]}, status: :unprocessable_entity unless @email_otp.present?
		  
		  @email_otp.update(pin: genrate_otp)
			# Admin::SendOtpMailer.send_otp_to_email(@email_otp.email, @email_otp.pin).deliver_now
			
		  render json: {data: {email: @email_otp.email}, meta: {
          otp: @email_otp.pin,
          activated: @email_otp.activated
        }}, status: :ok
		end

		def google_sign_in
			case params[:data][:type]
			when 'google_account'
        email = params[:data][:attributes][:email].downcase
        account = AdminUser.admins.where('LOWER(email) = ?', email).first
        if account.present?
	        account.update(google_unique_auth_id: params[:data][:attributes][:google_unique_auth_id], google_type: true) if account.google_unique_auth_id == nil
					if params[:data][:attributes][:google_unique_auth_id].present? && account.google_unique_auth_id == params[:data][:attributes][:google_unique_auth_id]
	        	token, refresh_token = generate_tokens(account.id)
	        	render json: {meta: {
		          token: token,
		          refresh_token: refresh_token,
		          id: account.id
		        }}, status: :ok
	        else
	        	render json: {
		          errors: [{
		            account: 'login failed',
		          }],
		        }, status: :unprocessable_entity
	        end
	      else
	      	render json: {
	          errors: [{
	            account: 'Account not found',
	          }],
	        }, status: :unprocessable_entity
	      end
			else
        render json: {
          errors: [{
            account: 'Invalid Account Type',
          }],
        }, status: :unprocessable_entity
      end
		end

		private

		def genrate_otp
			1111#rand(1_000..9_999)
		end

		def check_token_type
			return render json: {errors: [{token: 'Not Found'},]}, status: :unprocessable_entity unless @token&.token_type == "admin_email_otp"
		end

		def generate_tokens(account_id)
	    [
	      BuilderJsonWebToken.encode(account_id, 2.month.from_now, token_type: 'admin_login'),
	      BuilderJsonWebToken.encode(account_id, 1.year.from_now, token_type: 'admin_login_refresh')
	    ]
    end
	end
end
