module Admin
	class AccountUsersController < ApplicationController
		include BuilderJsonWebToken::JsonWebTokenValidation
    before_action :validate_json_web_token, :check_token_type, :check_admin_user
    before_action :set_account_user, only: [:show, :update]

    def index
    	order_name = get_order_name
      if params[:list_of_farmers]
      	accounts = AccountBlock::Account.farmer_role.all.order(order_name).paginate(page: params[:page], per_page: params[:per_page] || 50)
      elsif params[:list_of_fe]
        accounts = AccountBlock::Account.field_executive_role.all.order(order_name).paginate(page: params[:page], per_page: params[:per_page] || 50)
      elsif params[:list_of_admins]
        @admin_accounts = AdminUser.admins.all.order(order_name).paginate(page: params[:page], per_page: params[:per_page] || 50)
      else
        accounts = AccountBlock::Account.all.order(order_name).paginate(page: params[:page], per_page: params[:per_page] || 50)
      end

        filter_accounts(accounts) if accounts.present?
        fe_count = AccountBlock::Account.field_executive_role.count
        farmers_count = AccountBlock::Account.farmer_role.count
        admins_count = AdminUser.admins.count
      if @admin_accounts.present?
        render json: {data: @admin_accounts, meta: { farmers_count: farmers_count,
                                                                fe_count: fe_count, admins_count: admins_count }}, status: 200
      else
        render json: AccountBlock::AccountWebSerializer.new(@accounts, meta: { farmers_count: farmers_count,
                                                                fe_count: fe_count, admins_count: admins_count }).serializable_hash, status: 200
      end
    end

    def create
      if params[:add_admin].present?
        @account = AdminUser.admins.create(create_admin_params)
      else
        @account = AccountBlock::Account.new(create_account_params)
      end
      if @account.save
        #assign fe/farmer feature need to confirm  
        # params[:assign_fe_ids].each do |field_executive_id|
        #   AccountBlock::AccountsVillage.create!(account_id: field_executive_id, village_id: @account.village_id)
        # end if params[:assign_fe_ids].present?
    
        # params[:assign_farmer_ids].each do |farmer_id|
        #   AccountBlock::AccountsVillage.create!(account_id: farmer_id, village_id: @account.village_id)
        # end if params[:assign_farmer_ids].present?

        if params[:add_admin].present?
          render json: {data: @account}, status: 200
        else
          render json: AccountBlock::AccountWebSerializer.new(@account).serializable_hash, status: 200
        end
      else
        render json: { errors: @account.errors.full_messages },
               status: :unprocessable_entity
      end
    end

    def update
      if @account.update(update_params)
        if params[:role_admin].present?
          render json: {data: @account}, status: 200
        else
          render json: AccountBlock::AccountWebSerializer.new(@account).serializable_hash, status: 200
        end
      else
        render json: { errors: @account.errors.full_messages },
               status: :unprocessable_entity
      end
    end

    def show
      if params[:role_admin].present?
        render json: {data: @account}, status: 200
      else
        render json: AccountBlock::AccountWebSerializer.new(@account).serializable_hash, status: 200
      end
    end

    def show_current_admin
      if @admin_account.present?
        render json: {data: @admin_account}, status: :ok
      else
        render json: {errors: [{message: 'Not found any admin user.'}]}, status: :unprocessable_entity
      end
    end

    def search_field_executives
      accounts = AccountBlock::Account.field_executive_role.all.where("lower(first_name) LIKE (?) OR lower(last_name) Like (?)", "%#{params[:search]&.downcase}%", "%#{params[:search]&.downcase}%")
      render json: AccountBlock::AccountWebSerializer.new(accounts).serializable_hash, status: 200
    end

    def search_farmers
      accounts = AccountBlock::Account.farmer_role.all.where("lower(first_name) LIKE (?) OR lower(last_name) Like (?)", "%#{params[:search]&.downcase}%", "%#{params[:search]&.downcase}%")
      filter_accounts(accounts)
      render json: AccountBlock::AccountWebSerializer.new(@accounts).serializable_hash, status: 200
    end

    def admin_dashboard
      fe_count = AccountBlock::Account.field_executive_role.count
      farmers_count = AccountBlock::Account.farmer_role.count
      cotton_area = BxBlockProfileBio::LandDetail.pluck(:farm_area_for_cotton).compact.sum
      farm_dairy_entries = BxBlockFarmDairy::Sowing.count + BxBlockFarmDairy::PreSowing.count + BxBlockFarmDairy::PreSowingCompost.count + BxBlockFarmDairy::GapFilling.count + BxBlockFarmDairy::WeedManagement.count + BxBlockFarmDairy::Nutrient.count + BxBlockFarmDairy::PestManagementFoliarSpray.count + BxBlockFarmDairy::PestManagementTrap.count + BxBlockFarmDairy::PestManagementBio.count + BxBlockFarmDairy::Irrigation.count + BxBlockFarmDairy::IrrigationDrip.count +  BxBlockFarmDairy::IrrigationSprinkler.count + BxBlockFarmDairy::RentedIrrigation.count + BxBlockFarmDairy::Harvest.count + BxBlockFarmDairy::Sale.count
      render json: { Dashboard_Counts: { 
          Total_number_of_farmers: farmers_count,
          Total_number_of_field_executives: fe_count,
          Total_area_of_cotton: "#{cotton_area} Acres",
          Farm_Dairy_entries: farm_dairy_entries }}, status: 200
    end

    def highest_education_list
      @highest_educations = ::BxBlockUserProfile::HighestEducation.where(active: true)
      render json: @highest_educations, status: :ok
    end

    def state_listing
      @states = ::BxBlockLocationDetails::State.where(active: true)
      render json: @states, status: :ok
    end

    def district_listing
      @districts = ::BxBlockLocationDetails::District.where(state_id: params[:state_id], active: true)
      render json: @districts, status: :ok
    end

    def taluka_listing
      @talukas = ::BxBlockLocationDetails::Taluka.where(district_id: params[:district_id], active: true)
      render json: @talukas, status: :ok
    end

    def village_listing
      @villages = ::BxBlockLocationDetails::Village.where(taluka_id: params[:taluka_id], active: true)
      render json: @villages, status: :ok
    end

    def ownership_of_land_listing
      @ownerships_of_land = ::BxBlockProfileBio::LandDetail.ownership_of_lands.map{|key, value| {name: key.humanize, value: value}}
      render json: @ownerships_of_land, status: :ok
    end

    def unit_of_measure
      @unit_of_measures =  ::BxBlockFarmDairy::UnitOfMeasure.all.where(active: true)
      render json: @unit_of_measures, status: :ok
    end

    def land_type_listing
      @land_types = ::BxBlockProfileBio::LandType.where(active: true)
      render json: @land_types, status: :ok
    end

    def source_of_irrigation_listing
      @soil_textures = ::BxBlockProfileBio::SourceIrrigation.where(active: true)
      render json: @soil_textures, status: :ok
    end

    def type_of_irrigation_listing
      @irrigation_types = ::BxBlockProfileBio::TypeIrrigation.where(active: true)
      render json: @irrigation_types, status: :ok
    end

    def loaction_listing
      @locations = ::BxBlockLocationDetails::Village.all.where(active: true)
      render json: @locations, status: :ok
    end

    def mobile_type_listing
      @mobile_types = ::BxBlockUserProfile::MobileType.where(active: true)
      render json: @mobile_types, status: :ok
    end


    private

    def create_account_params
      params.require(:data).require(:attributes).permit(
        :role_id, :first_name, :middle_name, :last_name, :user_name, :full_phone_number, :number_belongs_to_id, :email,
        :mobile_type_id, :phone_number, :aadhaar_number, :date_of_birth, :total_family_members, :gender, :highest_education_id,
        :village_id, :state_id, :district_id, :taluka_id, land_details_attributes: [:id, :farm_image, :farm_mapping_image, :name, :survey_number,
        :owner, :farm_area, :farm_area_for_cotton, :horizontal_distance, :motor_horse_power, :pump_depth, 
        :unit_farm_area, :unit_measurment_id, :unit_farm_area_for_cotton, :soil_texture_id, :land_type_id, :source_irrigation_id, :type_irrigation_id,
        :distance_in, :account_id, :_destroy, :latitude_longitude ], :village_ids => []
        )
    end

    def create_admin_params
      params[:data][:attributes][:password] = "123456" unless params[:data][:attributes][:password].present?
      params.require(:data).require(:attributes).permit(
        :first_name, :last_name, :phone_number, :dob, :user_name, :email, :password
        )
    end

    def get_order_name
    	if params[:sort_by_a_to_z].present?
      	order_by = 'first_name ASC'
      elsif params[:sort_by_z_to_a].present?
      	order_by = 'first_name DESC'
      else
      	order_by = 'created_at DESC'
      end
    end

    def filter_accounts(accounts)
      if params[:state_id].present?
      	accounts = accounts.where(state_id: params[:state_id])
      end
      if params[:district_id].present?
      	accounts = accounts.where(district_id: params[:district_id])
      end
      if params[:taluka_id].present?
      	accounts = accounts.where(taluka_id: params[:taluka_id])
      end
      if params[:village_id].present?
      	accounts = accounts.where(village_id: params[:village_id])
      end
      @accounts = accounts
    end

    def set_account_user
      if params[:role_admin].present?
        @account = AdminUser.admins.find_by_id(params[:id])
      else
        @account = AccountBlock::Account.find_by_id(params[:id])
      end
      return render json: {errors: [{account: 'Not Found'},]},
               status: :unprocessable_entity unless @account.present?
    end

    def update_params
      if params[:role_admin].present?
        params.require(:data).require(:attributes).permit(
        :first_name, :last_name, :phone_number, :dob, :user_name, :email
        )
      else
        # params.require(:data).require(:attributes).permit(:role_id, :first_name, :last_name, :middle_name, :gender, :email, :user_name,
        #                                                 :full_phone_number, :total_family_members, :date_of_birth, :highest_education_id, :age, :number_belongs_to_id, :mobile_type_id, :state_id, :district_id, :taluka_id, :village_id, :user_type, :aadhaar_number,avatar: :data)
        params.require(:data).require(:attributes).permit(
        :role_id, :first_name, :middle_name, :last_name, :user_name, :full_phone_number, :number_belongs_to_id, :email,
        :mobile_type_id, :phone_number, :aadhaar_number, :date_of_birth, :total_family_members, :gender, :highest_education_id,
        :village_id, :state_id, :district_id, :taluka_id, land_details_attributes: [:id, :farm_image, :farm_mapping_image, :name, :survey_number,
        :owner, :farm_area, :farm_area_for_cotton, :horizontal_distance, :motor_horse_power, :pump_depth, 
        :unit_farm_area, :unit_measurment_id, :unit_farm_area_for_cotton, :soil_texture_id, :land_type_id, :source_irrigation_id, :type_irrigation_id,
        :distance_in, :account_id, :_destroy, :latitude_longitude ], :village_ids => []
        )
      end
    end

    def check_admin_user
    	@admin_account = AdminUser.admins.find_by_id(@token.id)
    	unless @admin_account.present?
    		return render json: {errors: [{account: 'Not Found'},]},
               status: :unprocessable_entity
    	end
    end

    def check_token_type
      return render json: { errors: { 'token' => ['is invalid'] } }, status: :unprocessable_entity unless ["admin_login", "admin_login_refresh"].include?(@token.token_type)
    end
	end
end
