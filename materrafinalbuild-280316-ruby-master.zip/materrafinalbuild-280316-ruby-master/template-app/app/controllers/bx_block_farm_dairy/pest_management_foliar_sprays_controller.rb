module BxBlockFarmDairy
  class PestManagementFoliarSpraysController < ApplicationController
    before_action :current_farmer
    INVALID_DATA = "invalid data"

    def index
      @pests = BxBlockFarmDairy::PestManagementFoliarSpray.all
      render json: @pests, status: :ok
    end

    def create
      account = AccountBlock::Account.find_by(id: current_farmer.id)
      @pest = account.pest_managment_foliar_sprays.create!(pest_management_foliar_spray_params)
      if @pest.present?
        pest = BxBlockFarmDairy::PestManagementFoliarSpraySerializer.new(@pest);
        render json: pest, status: :ok
      else
        render json: {errors: "can't be create"}, status: :unprocessable_entity
      end
    end

    def update
      @pest = BxBlockFarmDairy::PestManagementFoliarSpray.find_by(id: params[:id])
      if @pest.present?
        if @pest.update(update_pest_management_foliar_spray_params)
          pest = BxBlockFarmDairy::PestManagementFoliarSpraySerializer.new(@pest);
          render json: pest, status: :ok
        else
          render json: {errors: "can't be update"}, status: :unprocessable_entity
        end
      else
        render json: {errors: INVALID_DATA}, status: :unprocessable_entity
      end
    end

    def show
      @pest = BxBlockFarmDairy::PestManagementFoliarSpray.find_by(id: params[:id])
      if @pest.present?
        pest = BxBlockFarmDairy::PestManagementFoliarSpraySerializer.new(@pest);
        render json: pest, status: :ok
      else
        render json: {errors: INVALID_DATA}, status: :unprocessable_entity
      end
    end

    def destroy
      if current_user.role_id == 1
        @pest = BxBlockFarmDairy::PestManagementFoliarSpray.find_by(id: params[:id])
        if @pest.destroy
           render json: {deleted: true}
        else
          render json: {errors: INVALID_DATA}, status: :unprocessable_entity
        end
      else
        render json:{meta: {message: "Only field executive can delete the record."}}
      end
    end

    def delete_pest_foliar_spray_request
      BxBlockPushNotifications::Providers::UserProfileFcm.send_push_notification(title: "alert notification", message: "Delete the farm dairy record", user_ids: [current_farmer.id], type: params[:type], deleted_id: params[:id])
      BxBlockPushNotifications::PushNotification.create(push_notificable_type: params[:type], push_notificable_id: params[:id], remarks: "Delete the farm dairy pest management foilar spary record", account_id: current_farmer.id, is_delete_request: true)
      
      if response.status == 200
        render json:{meta: {message: "Delete request will send to field executive"}}
      end
    end

    private

    def update_pest_management_foliar_spray_params
      params.require(:pest_management_foliar_spray).permit(:date_of_application, :quantity_of_pesticide, :machine_cost_of_spraying, :pesticide_cost, :labor_cost, :pest_managment_id, :unit_of_measure_id, :pesticide_id, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year)
    end

    def pest_management_foliar_spray_params
      pest_management_foliar_spray = params[:pest_management_foliar_spray]

      pest_management_foliar_spray.map do |pest_management_foliar_spray_params|
        pest_management_foliar_spray_params.permit(:date_of_application, :quantity_of_pesticide, :machine_cost_of_spraying, :pesticide_cost, :labor_cost, :pest_managment_id, :unit_of_measure_id, :pesticide_id, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year)
      end
    end
  end
end
