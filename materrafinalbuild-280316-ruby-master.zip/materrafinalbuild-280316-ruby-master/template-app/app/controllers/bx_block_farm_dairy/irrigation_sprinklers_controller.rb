module BxBlockFarmDairy
  class IrrigationSprinklersController < ApplicationController

    before_action :current_farmer

    def index
      @irrigation_sprinkler = BxBlockFarmDairy::IrrigationSprinkler.all
      render json: @irrigation_sprinkler, status: :ok
    end

    def create
      account = AccountBlock::Account.find_by(id: current_farmer.id)
      irrigation_sprinkler = account.irrigation_sprinklers.create!(irrigation_sprinkler_params)
     
      if irrigation_sprinkler.present?
        serializer = BxBlockFarmDairy::IrrigationSprinklerSerializer.new(irrigation_sprinkler)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{irrigation_sprinkler: irrigation_sprinkler.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def show
      irrigation_sprinkler = BxBlockFarmDairy::IrrigationSprinkler.find(params[:id])
      
      if irrigation_sprinkler.present?
        serializer = BxBlockFarmDairy::IrrigationSprinklerSerializer.new(irrigation_sprinkler)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{irrigation_sprinkler: irrigation_sprinkler.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def update
      irrigation_sprinkler = BxBlockFarmDairy::IrrigationSprinkler.find(params[:id])
      if irrigation_sprinkler.update(update_irrigation_sprinkler_params)
        serializer = BxBlockFarmDairy::IrrigationSprinklerSerializer.new(irrigation_sprinkler)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{irrigation_sprinkler: irrigation_sprinkler.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def destroy
      if current_user.role_id == 1
        irrigation_sprinkler = BxBlockFarmDairy::IrrigationSprinkler.find_by(id: params[:id])
        if irrigation_sprinkler&.destroy
          render json:{ meta: { message: "Irrigation Sprinkler record deleted"}}
        else
          render json:{meta: {message: "Record not found."}}
        end
      else
        render json:{meta: {message: "Only field executive can delete the record."}}
      end
    end

    def delete_irrigation_sprinkler_request
      BxBlockPushNotifications::Providers::UserProfileFcm.send_push_notification(title: "alert notification", message: "Delete the farm dairy record", user_ids: [current_farmer.id], type: params[:type], deleted_id: params[:id])
      BxBlockPushNotifications::PushNotification.create(push_notificable_type: params[:type], push_notificable_id: params[:id], remarks: "Delete the farm dairy irrigation sprinkler record", account_id: current_farmer.id, is_delete_request: true)
      
      if response.status == 200
        render json:{meta: {message: "Delete request will send to field executive"}}
      end
    end

    private

    def update_irrigation_sprinkler_params
      params.require(:irrigation_sprinkler).permit(:hours_of_irrigation, :labor_cost, :number_of_nozels, :type_irrigation_id, :source_irrigation_id, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year)
    end

    def irrigation_sprinkler_params
      irrigation_sprinkler = params[:irrigation_sprinkler]

      irrigation_sprinkler.map do |irrigation_sprinkler_params|
        irrigation_sprinkler_params.permit(:hours_of_irrigation, :labor_cost, :number_of_nozels, :type_irrigation_id, :source_irrigation_id, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year)
      end
    end
  end
end
