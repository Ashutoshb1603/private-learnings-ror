module BxBlockFarmDairy
  class IrrigationDripsController < ApplicationController

    before_action :current_farmer

    def index
      @irrigation_drip = BxBlockFarmDairy::IrrigationDrip.all
      render json: @irrigation_drip, status: :ok
    end

    def create
      account = AccountBlock::Account.find_by(id: current_farmer.id)
      irrigation_drip = account.irrigation_drips.create!(irrigation_drip_params)
     
      if irrigation_drip.present?
        serializer = BxBlockFarmDairy::IrrigationDripSerializer.new(irrigation_drip)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{irrigation_drip: irrigation_drip.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def show
      irrigation_drip = BxBlockFarmDairy::IrrigationDrip.find(params[:id])
      
      if irrigation_drip.present?
        serializer = BxBlockFarmDairy::IrrigationDripSerializer.new(irrigation_drip)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{irrigation_drip: irrigation_drip.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def update
      irrigation_drip = BxBlockFarmDairy::IrrigationDrip.find(params[:id])
      if irrigation_drip.update(update_irrigation_drip_params)
        serializer = BxBlockFarmDairy::IrrigationDripSerializer.new(irrigation_drip)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{irrigation_drip: irrigation_drip.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def destroy
      if current_user.role_id == 1
        irrigation_drip = BxBlockFarmDairy::IrrigationDrip.find_by(id: params[:id])
        if irrigation_drip&.destroy
          render json:{ meta: { message: "Irrigation Drip record deleted"}}
        else
          render json:{meta: {message: "Record not found."}}
        end
      else
        render json:{meta: {message: "Only field executive can delete the record."}}
      end
    end

    def delete_irrigation_drip_request
      BxBlockPushNotifications::Providers::UserProfileFcm.send_push_notification(title: "alert notification", message: "Delete the farm dairy record", user_ids: [current_farmer.id], type: params[:type], deleted_id: params[:id])
      BxBlockPushNotifications::PushNotification.create(push_notificable_type: params[:type], push_notificable_id: params[:id], remarks: "Delete the farm dairy irrigation_drip record", account_id: current_farmer.id, is_delete_request: true)
      
      if response.status == 200
        render json:{meta: {message: "Delete request will send to field executive"}}
      end
    end

    private

    def update_irrigation_drip_params
      params.require(:irrigation_drip).permit(:date_of_irrigation, :hours_of_irrigation, :spacing_of_dripper, :drip_irrigated_area, :row_to_row_spacing, :type_irrigation_id, :source_irrigation_id, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year)
    end

    def irrigation_drip_params
      irrigation_drip = params[:irrigation_drip]

      irrigation_drip.map do |irrigation_drip_params|
        irrigation_drip_params.permit(:date_of_irrigation, :hours_of_irrigation, :spacing_of_dripper, :drip_irrigated_area, :row_to_row_spacing, :type_irrigation_id, :source_irrigation_id, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year)
      end
    end
  end
end
