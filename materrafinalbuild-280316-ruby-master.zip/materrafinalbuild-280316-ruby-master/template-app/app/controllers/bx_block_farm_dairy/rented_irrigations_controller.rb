module BxBlockFarmDairy
  class RentedIrrigationsController < ApplicationController

    before_action :current_farmer

    def index
      @rented_irrigation = BxBlockFarmDairy::RentedIrrigation.all
      render json: @rented_irrigation, status: :ok
    end

    def create
      account = AccountBlock::Account.find_by(id: current_farmer.id)
      rented_irrigation = account.rented_irrigations.create!(rented_irrigation_params)
     
      if rented_irrigation.present?
        serializer = BxBlockFarmDairy::RentedIrrigationSerializer.new(rented_irrigation)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{rented_irrigation: rented_irrigation.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def show
      rented_irrigation = BxBlockFarmDairy::RentedIrrigation.find(params[:id])
      
      if rented_irrigation.present?
        serializer = BxBlockFarmDairy::RentedIrrigationSerializer.new(rented_irrigation)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{rented_irrigation: rented_irrigation.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def update
      rented_irrigation = BxBlockFarmDairy::RentedIrrigation.find(params[:id])
      if rented_irrigation.update(update_rented_irrigation_params)
        serializer = BxBlockFarmDairy::RentedIrrigationSerializer.new(rented_irrigation)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{rented_irrigation: rented_irrigation.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def destroy
      if current_user.role_id == 1
        rented_irrigation = BxBlockFarmDairy::RentedIrrigation.find_by(id: params[:id])
        if rented_irrigation&.destroy
          render json:{ meta: { message: "Irrigation Drip record deleted"}}
        else
          render json:{meta: {message: "Record not found."}}
        end
      else
        render json:{meta: {message: "Only field executive can delete the record."}}
      end
    end

    def delete_rented_irrigation_request
      BxBlockPushNotifications::Providers::UserProfileFcm.send_push_notification(title: "alert notification", message: "Delete the farm dairy record", user_ids: [current_farmer.id], type: params[:type], deleted_id: params[:id])
      BxBlockPushNotifications::PushNotification.create(push_notificable_type: params[:type], push_notificable_id: params[:id], remarks: "Delete the farm dairy rented irrigation record", account_id: current_farmer.id, is_delete_request: true)
      
      if response.status == 200
        render json:{meta: {message: "Delete request will send to field executive"}}
      end
    end

    private

    def update_rented_irrigation_params
      params.require(:rented_irrigation).permit(:date_of_irrigation, :hours_of_irrigation, :labor_cost, :irrigation_cost, :type_irrigation_id, :source_irrigation_id, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year)
    end


    def rented_irrigation_params
      rented_irrigation = params[:rented_irrigation]

      rented_irrigation.map do |rented_irrigation_params|
        rented_irrigation_params.permit(:date_of_irrigation, :hours_of_irrigation, :labor_cost, :irrigation_cost, :type_irrigation_id, :source_irrigation_id, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year)
      end
    end
  end
end
