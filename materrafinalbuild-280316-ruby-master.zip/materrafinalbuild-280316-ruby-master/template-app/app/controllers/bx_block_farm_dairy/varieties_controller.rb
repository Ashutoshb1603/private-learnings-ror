module BxBlockFarmDairy
  class VarietiesController < ApplicationController

    def index
      @variety = BxBlockFarmDairy::Variety.where(active: true)
      render json: @variety, status: :ok
    end

  end
end
