module BxBlockFarmDairy
  class SeedSourcesController < ApplicationController

    def index
      @seed_source = BxBlockFarmDairy::SeedSource.where(active: true)
      render json: @seed_source, status: :ok
    end

  end
end
