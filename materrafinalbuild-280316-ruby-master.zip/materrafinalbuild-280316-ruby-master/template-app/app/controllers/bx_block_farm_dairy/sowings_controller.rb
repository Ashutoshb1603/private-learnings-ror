module BxBlockFarmDairy
  class SowingsController < ApplicationController

    before_action :current_farmer

    def index
      @sowing = BxBlockFarmDairy::Sowing.all
      render json: @sowing, status: :ok
    end

    def create
      account = AccountBlock::Account.find_by(id: current_farmer.id)
      sowing = account.sowings.create!(sowing_params)
      if sowing.present?
        serializer = BxBlockFarmDairy::SowingSerializer.new(sowing)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{sowing: sowing.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def show
      sowing = BxBlockFarmDairy::Sowing.find(params[:id])
      
      if sowing.present?
        serializer = BxBlockFarmDairy::SowingSerializer.new(sowing)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{sowing: sowing.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def update
      sowing = BxBlockFarmDairy::Sowing.find(params[:id])
      if sowing.update(update_sowing_params)
        serializer = BxBlockFarmDairy::SowingSerializer.new(sowing)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{sowing: sowing.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def destroy
      if current_user.role_id == 1
        sowing = BxBlockFarmDairy::Sowing.find_by(id: params[:id])
        if sowing&.destroy
          render json:{ meta: { message: "Sowing record deleted"}}
        else
          render json:{meta: {message: "Record not found."}}
        end
      else
        render json:{meta: {message: "Only field executive can delete the record."}}
      end
    end

    def delete_sowing_request
      BxBlockPushNotifications::Providers::UserProfileFcm.send_push_notification(title: "alert notification", message: "Delete the farm dairy record", user_ids: [current_farmer.id], type: params[:type], deleted_id: params[:id])
      BxBlockPushNotifications::PushNotification.create(push_notificable_type: params[:type], push_notificable_id: params[:id], remarks: "Delete the farm dairy sowing record", account_id: current_farmer.id, is_delete_request: true)
      
      if response.status == 200
        render json:{meta: {message: "Delete request will send to field executive"}}
      end
    end

    private

    def update_sowing_params
      params.require(:sowing).permit(:date_of_sowing, :crop_name_id, :crop_area_id, :unit_of_measure_id, :crop_season_id, :crop_type_id, :crop_mapping, :variety_id, :seed_source_id, :number_of_packet, :quantity_in_kg, :seed_price, :gmo_seed, :seed_treatment, :bio_agent_id, :bio_agent_cost, :land_detail_id, :crop_start_year, :crop_end_year)
    end

    def sowing_params
      sowing = params[:sowing]

      sowing.map do |sowing_params|
        sowing_params.permit(:date_of_sowing, :crop_name_id, :crop_area_id, :unit_of_measure_id, :crop_season_id, :crop_type_id, :crop_mapping, :variety_id, :seed_source_id, :number_of_packet, :quantity_in_kg, :seed_price, :gmo_seed, :seed_treatment, :bio_agent_id, :bio_agent_cost, :land_detail_id, :crop_start_year, :crop_end_year)
      end
    end
  end
end
