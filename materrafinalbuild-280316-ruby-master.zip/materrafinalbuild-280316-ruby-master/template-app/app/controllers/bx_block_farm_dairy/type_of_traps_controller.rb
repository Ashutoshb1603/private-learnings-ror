module BxBlockFarmDairy
  class TypeOfTrapsController < ApplicationController

    def index
      @type_of_trap = BxBlockFarmDairy::TypeOfTrap.where(active: true)
      render json: @type_of_trap, status: :ok
    end

  end
end
