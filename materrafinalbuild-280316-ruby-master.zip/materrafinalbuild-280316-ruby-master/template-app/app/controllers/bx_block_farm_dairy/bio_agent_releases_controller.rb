module BxBlockFarmDairy
  class BioAgentReleasesController < ApplicationController

    def index
      @bio_agent_release = BxBlockFarmDairy::BioAgentRelease.where(active: true)
      render json: @bio_agent_release, status: :ok
    end

  end
end
