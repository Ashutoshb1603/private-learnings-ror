module BxBlockFarmDairy
  class QuantityOfNutrientsController < ApplicationController

    def index
      @quantity_of_nutrients = BxBlockFarmDairy::QuantityOfNutrient.where(active: true)
      render json: @quantity_of_nutrients, status: :ok
    end

  end
end
