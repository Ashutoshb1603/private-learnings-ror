module BxBlockFarmDairy
  class PestManagementBiosController < ApplicationController
    before_action :current_farmer

    INVALID_DATA = "invalid data"

    def index
      @pest_bios = BxBlockFarmDairy::PestManagementBio.all
      render json: @pest_bios, status: :ok
    end

    def create
      account = AccountBlock::Account.find_by(id: current_farmer.id)
      @pest_bios = account.pest_managment_bios.create!(pest_management_bio_params)
      if @pest_bios.present?
        pest_bios = BxBlockFarmDairy::PestManagementBioSerializer.new(@pest_bios);
        render json: pest_bios, status: :ok
      else
        render json: {errors: "can't be create"}, status: :unprocessable_entity
      end
    end

    def update
      @pest_bios = BxBlockFarmDairy::PestManagementBio.find_by(id: params[:id])
      if @pest_bios.present?
        if @pest_bios.update(update_pest_management_bio_params)
          pest_bios = BxBlockFarmDairy::PestManagementBioSerializer.new(@pest_bios);
          render json: pest_bios, status: :ok
        else
          render json: {errors: "can't be update"}, status: :unprocessable_entity
        end
      else
        render json: {errors: INVALID_DATA}, status: :unprocessable_entity
      end
    end

    def show
      @pest_bios = BxBlockFarmDairy::PestManagementBio.find_by(id: params[:id])
      if @pest_bios.present?
        pest_bios = BxBlockFarmDairy::PestManagementBioSerializer.new(@pest_bios);
        render json: pest_bios, status: :ok
      else
        render json: {errors: INVALID_DATA}, status: :unprocessable_entity
      end
    end

    def destroy
      if current_user.role_id == 1
        @pest_bios = BxBlockFarmDairy::PestManagementBio.find_by(id: params[:id])
        if @pest_bios.destroy
           render json: {deleted: true}
        else
          render json: {errors: INVALID_DATA}, status: :unprocessable_entity
        end
      else
        render json:{meta: {message: "Only field executive can delete the record."}}
      end
    end

    def delete_pest_bio_request
      BxBlockPushNotifications::Providers::UserProfileFcm.send_push_notification(title: "alert notification", message: "Delete the farm dairy record", user_ids: [current_farmer.id], type: params[:type], deleted_id: params[:id])
      BxBlockPushNotifications::PushNotification.create(push_notificable_type: params[:type], push_notificable_id: params[:id], remarks: "Delete the farm dairy pest management bios record", account_id: current_farmer.id, is_delete_request: true)
      
      if response.status == 200
        render json:{meta: {message: "Delete request will send to field executive"}}
      end
    end

    private

    def update_pest_management_bio_params
      params.require(:pest_management_bio).permit(:date_of_release, :quantity, :cost_of_input, :bio_agent_release_id, :labor_cost, :pest_managment_id, :unit_of_measure_id, :land_detail_id,
        :crop_season_id, :crop_start_year, :crop_end_year)
    end
    def pest_management_bio_params
      pest_management_bio = params[:pest_management_bio]

      pest_management_bio.map do |pest_management_bio_params|
        pest_management_bio_params.permit(:date_of_release, :quantity, :cost_of_input, :bio_agent_release_id, :labor_cost, :pest_managment_id, :unit_of_measure_id, :land_detail_id,
          :crop_season_id, :crop_start_year, :crop_end_year)
      end
    end
  end
end
