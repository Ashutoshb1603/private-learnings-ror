module BxBlockFarmDairy
  class WeedingTypesController < ApplicationController

    def index
      @weeding_type = BxBlockFarmDairy::WeedingType.where(active: true)
      render json: @weeding_type, status: :ok
    end

  end
end
