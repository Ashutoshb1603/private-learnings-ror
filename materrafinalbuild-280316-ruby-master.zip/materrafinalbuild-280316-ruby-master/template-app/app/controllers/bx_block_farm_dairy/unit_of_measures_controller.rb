module BxBlockFarmDairy
  class UnitOfMeasuresController < ApplicationController

    def index
      @unit_of_measure = BxBlockFarmDairy::UnitOfMeasure.where(active: true)
      render json: @unit_of_measure, status: :ok
    end

  end
end
