module BxBlockFarmDairy
  class PestManagmentsController < ApplicationController

    def index
      @pest_managment = BxBlockFarmDairy::PestManagment.where(active: true)
      render json: @pest_managment, status: :ok
    end

  end
end
