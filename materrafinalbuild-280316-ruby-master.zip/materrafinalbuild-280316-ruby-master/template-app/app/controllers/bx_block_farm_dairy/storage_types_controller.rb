module BxBlockFarmDairy
  class StorageTypesController < ApplicationController

    def index
      @storage_type = BxBlockFarmDairy::StorageType.where(active: true)
      render json: @storage_type, status: :ok
    end

  end
end
