module BxBlockFarmDairy
  class WeedicidesController < ApplicationController

    def index
      @weedicide = BxBlockFarmDairy::Weedicide.where(active: true)
      render json: @weedicide, status: :ok
    end

  end
end
