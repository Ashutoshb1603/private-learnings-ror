module BxBlockFarmDairy
  class CropTypesController < ApplicationController

    def index
      @crop_type = BxBlockFarmDairy::CropType.where(active: true)
      render json: @crop_type, status: :ok
    end

  end
end
