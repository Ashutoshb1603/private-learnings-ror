module BxBlockFarmDairy
  class PesticidesController < ApplicationController

    def index
      @pesticide = BxBlockFarmDairy::Pesticide.where(active: true)
      render json: @pesticide, status: :ok
    end

  end
end
