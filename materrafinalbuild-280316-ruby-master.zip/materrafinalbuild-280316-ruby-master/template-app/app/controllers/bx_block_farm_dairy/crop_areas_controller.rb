module BxBlockFarmDairy
  class CropAreasController < ApplicationController

    def index
      @crop_area = BxBlockFarmDairy::CropArea.where(active: true)
      render json: @crop_area, status: :ok
    end

  end
end
