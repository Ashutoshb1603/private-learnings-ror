module BxBlockFarmDairy
  class CropSeasonsController < ApplicationController

    def index
      @crop_season = BxBlockFarmDairy::CropSeason.where(active: true)
      render json: @crop_season, status: :ok
    end

  end
end
