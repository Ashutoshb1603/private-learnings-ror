module BxBlockFarmDairy
  class PreSowingActivitiesController < ApplicationController

    def index
      @pre_sowing_activities = BxBlockFarmDairy::PreSowingActivity.where(active: true)
      render json: @pre_sowing_activities, status: :ok
    end

  end
end
