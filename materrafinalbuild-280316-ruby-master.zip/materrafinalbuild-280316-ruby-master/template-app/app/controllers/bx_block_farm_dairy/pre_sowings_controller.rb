module BxBlockFarmDairy
  class PreSowingsController < ApplicationController

    before_action :current_farmer

    def index
      @pre_sowing = BxBlockFarmDairy::PreSowing.all
      render json: @pre_sowing, status: :ok
    end

    def create
      account = AccountBlock::Account.find_by(id: current_farmer.id)
      pre_sowing = account.pre_sowings.create!(pre_sowing_params)
     
      if pre_sowing.present?
        serializer = BxBlockFarmDairy::PreSowingSerializer.new(pre_sowing)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{pre_sowing: pre_sowing.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def show
      pre_sowing = BxBlockFarmDairy::PreSowing.find(params[:id])
      
      if pre_sowing.present?
        serializer = BxBlockFarmDairy::PreSowingSerializer.new(pre_sowing)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{pre_sowing: pre_sowing.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def update
      pre_sowing = BxBlockFarmDairy::PreSowing.find(params[:id])
      if pre_sowing.update(update_pre_sowing_params)
        serializer = BxBlockFarmDairy::PreSowingSerializer.new(pre_sowing)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{pre_sowing: pre_sowing.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def destroy
      if current_user.role_id == 1
        pre_sowing = BxBlockFarmDairy::PreSowing.find_by(id: params[:id])
        if pre_sowing&.destroy
          render json:{ meta: { message: "Pre sowing record deleted"}}
        else
          render json:{meta: {message: "Record not found."}}
        end
      else
        render json:{meta: {message: "Only field executive can delete the record."}}
      end
    end

    def delete_pre_sowing_request
      BxBlockPushNotifications::Providers::UserProfileFcm.send_push_notification(title: "alert notification", message: "Delete the farm dairy record", user_ids: [current_farmer.id], type: params[:type], deleted_id: params[:id])

      # BxBlockPushNotifications::SendPushNotification.new(title: "alert notification", message: "Delete the farm dairy record", user_ids: [current_farmer.id], current_user: current_user, type: params[:type], id: params[:id]).call
      BxBlockPushNotifications::PushNotification.create(push_notificable_type: params[:type], push_notificable_id: params[:id], remarks: "Delete the farm dairy pre sowing record", account_id: current_farmer.id, is_delete_request: true)
      
      if response.status == 200
        render json:{meta: {message: "Delete request will send to field executive"}}
      end
    end

    private

    def update_pre_sowing_params
      params.require(:pre_sowing).permit(:pre_sowing_activity_id, :date, :cost, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year)
    end

    def pre_sowing_params
      pre_sowing = params[:pre_sowing]

      pre_sowing.map do |pre_sowing_params|
        pre_sowing_params.permit(:pre_sowing_activity_id, :date, :cost, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year)
      end
    end

  end
end
