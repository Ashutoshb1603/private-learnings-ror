module BxBlockFarmDairy
  class SalesController < ApplicationController
    before_action :current_farmer
    INVALID_DATA = "invalid data"

    def index
      @sales = BxBlockFarmDairy::Sale.all
      render json: @sales, status: :ok
    end

    def create
      account = AccountBlock::Account.find_by(id: current_farmer.id)
      @sale = account.sales.create!(sale_params)
      if @sale.present?
        sale = BxBlockFarmDairy::SaleSerializer.new(@sale);
        render json: sale, status: :ok
      else
        render json: {errors: "can't be create"}, status: :unprocessable_entity
      end
    end

    def update
      @sale = BxBlockFarmDairy::Sale.find_by(id: params[:id])
      if @sale.present?
        if @sale.update(update_sale_params)
          sale = BxBlockFarmDairy::SaleSerializer.new(@sale);
          render json: sale, status: :ok
        else
          render json: {errors: "can't be update"}, status: :unprocessable_entity
        end
      else
        render json: {errors: INVALID_DATA}, status: :unprocessable_entity
      end
    end

    def show
      @sale = BxBlockFarmDairy::Sale.find_by(id: params[:id])
      if @sale.present?
        sale = BxBlockFarmDairy::SaleSerializer.new(@sale);
        render json: sale, status: :ok
      else
        render json: {errors: INVALID_DATA}, status: :unprocessable_entity
      end
    end

    def destroy
      if current_user.role_id == 1
        @sale = BxBlockFarmDairy::Sale.find_by(id: params[:id])
        if @sale.destroy
           render json: {deleted: true}
        else
          render json: {errors: INVALID_DATA}, status: :unprocessable_entity
        end
      else
        render json:{meta: {message: "Only field executive can delete the record."}}
      end
    end

    def delete_sale_request
      BxBlockPushNotifications::Providers::UserProfileFcm.send_push_notification(title: "alert notification", message: "Delete the farm dairy record", user_ids: [current_farmer.id], type: params[:type], deleted_id: params[:id])
      BxBlockPushNotifications::PushNotification.create(push_notificable_type: params[:type], push_notificable_id: params[:id], remarks: "Delete the farm dairy sales record", account_id: current_farmer.id, is_delete_request: true)
      
      if response.status == 200
        render json:{meta: {message: "Delete request will send to field executive"}}
      end
    end

    private

    def update_sale_params
      params.require(:sale).permit(:date_of_sale, :quantity_of_cotton_sold, :cotton_price, :total_amount, :distance_from_farmer_location_to_buyer, :buyer_name, :transportation_cost, :labor_cost_of_load_and_unload, :vehical_type_id, :crop_season_id, :crop_start_year, :crop_end_year)
    end

    def sale_params
      sale = params[:sale]

      sale.map do |sale_params|
        sale_params.permit(:date_of_sale, :quantity_of_cotton_sold, :cotton_price, :total_amount, :distance_from_farmer_location_to_buyer, :buyer_name, :transportation_cost, :labor_cost_of_load_and_unload, :vehical_type_id, :crop_season_id, :crop_start_year, :crop_end_year)
      end
    end
  end
end
