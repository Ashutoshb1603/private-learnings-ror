module BxBlockFarmDairy
  class FarmDairiesController < ApplicationController
    before_action :current_farmer

    def index
      data = []
      filtered_keys =  AccountBlock::Account::FARM_DAIRY_MODEL.map(&:keys).flatten.map{|key| key if key.to_s.downcase.include?(params[:query].to_s)}.compact
      AccountBlock::Account::FARM_DAIRY_MODEL.each do |farm|
        farm.each do |key, values|
          next unless filtered_keys.include?(key)
          values.each do |final_value|
            records = final_value.constantize.where(account_id: current_farmer.id)
            if(records.empty?)
              records = final_value.constantize.new(account_id: nil)
            end
            serializer = final_value + "Serializer"
            data << serializer.constantize.new(records)
          end
        end
      end
      render json: data
    end

    def search_activities
      data = []
      filtered_keys =  AccountBlock::Account::FARM_DAIRY_MODEL.map(&:keys).flatten.map{|key| key if key.to_s.downcase.include?(params[:name].to_s)}.compact
      AccountBlock::Account::FARM_DAIRY_MODEL.each do |farm|
        farm.each do |key, values|
          next unless filtered_keys.include?(key)
          values.each do |final_value|
            records = final_value.constantize.where(account_id: current_farmer.id, crop_start_year: params[:crop_start_year], crop_end_year: params[:crop_end_year], crop_season_id: params[:crop_season_id])
            if(records.empty?)
              records = final_value.constantize.where(account_id: nil)
            end
            serializer = final_value + "Serializer"
            data << serializer.constantize.new(records)
          end
        end
      end
      render json: data
    end

    def dashboard_activity_options
      nutrient = []
      quantity_of_nutrient_ids = BxBlockFarmDairy::Nutrient.where(account_id: current_farmer.id).pluck(:quantity_of_nutrient_id)
      quantity_of_nutrient_ids.each do |id|
        quantity = BxBlockFarmDairy::QuantityOfNutrient.find_by(id: id)
        nutrient << quantity.name.to_i
      end
      weed_management = BxBlockFarmDairy::WeedManagement.where(account_id: current_farmer.id).pluck(:quantity_of_weedicide).sum
      harvest = BxBlockFarmDairy::Harvest.where(account_id: current_farmer.id).pluck(:quantity_picked).sum
      crop_sale = BxBlockFarmDairy::Sale.where(account_id: current_farmer.id).pluck(:total_amount).sum
      pest_spray = BxBlockFarmDairy::PestManagementFoliarSpray.where(account_id: current_farmer.id).count
      irrgation =  BxBlockFarmDairy::IrrigationDrip.where(account_id: current_farmer.id).pluck(:drip_irrigated_area).sum
      render json: { Dashboard_Activity_Counts: { 
          Nutrient_Application: "#{nutrient.sum} kg/acres",
          Weed_Management: "#{weed_management} times",
          Quantity_Picked: "#{harvest} kg",
          Crop_sale: "#{crop_sale} sales till now",
          Pest_Management: "#{pest_spray} times spray",
          Irrgation: irrgation
        }}, status: 200
    end
  end
end


