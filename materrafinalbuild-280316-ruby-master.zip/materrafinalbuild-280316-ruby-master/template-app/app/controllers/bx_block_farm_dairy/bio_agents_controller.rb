module BxBlockFarmDairy
  class BioAgentsController < ApplicationController

    def index
      @bio_agent = BxBlockFarmDairy::BioAgent.where(active: true)
      render json: @bio_agent, status: :ok
    end

  end
end
