module BxBlockFarmDairy
  class NutrientManagmentsController < ApplicationController

    def index
      @nutrient_managment = BxBlockFarmDairy::NutrientManagment.where(active: true)
      render json: @nutrient_managment, status: :ok
    end

  end
end
