module BxBlockFarmDairy
  class PreSowingCompostsController < ApplicationController

    before_action :current_farmer

    def index
      @pre_sowing_compost = BxBlockFarmDairy::PreSowingCompost.all
      render json: @pre_sowing_compost, status: :ok
    end

    def create
      account = AccountBlock::Account.find_by(id: current_farmer.id)
      pre_sowing_compost = account.pre_sowing_composts.create!(pre_sowing_compost_params)
     
      if pre_sowing_compost.present?
        serializer = BxBlockFarmDairy::PreSowingCompostSerializer.new(pre_sowing_compost)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{pre_sowing_compost: pre_sowing_compost.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def show
      pre_sowing_compost = BxBlockFarmDairy::PreSowingCompost.find(params[:id])
      
      if pre_sowing_compost.present?
        serializer = BxBlockFarmDairy::PreSowingCompostSerializer.new(pre_sowing_compost)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{pre_sowing_compost: pre_sowing_compost.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def update
      pre_sowing_compost = BxBlockFarmDairy::PreSowingCompost.find(params[:id])
      if pre_sowing_compost.update(update_pre_sowing_compost_params)
        serializer = BxBlockFarmDairy::PreSowingCompostSerializer.new(pre_sowing_compost)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{pre_sowing_compost: pre_sowing_compost.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def destroy
      pre_sowing_compost = BxBlockFarmDairy::PreSowingCompost.find_by(id: params[:id])
      if pre_sowing_compost&.destroy
        render json:{ meta: { message: "Pre sowing compost record deleted"}}
      else
        render json:{meta: {message: "Record not found."}}
      end
    end

    def delete_pre_sowing_compost_request
      BxBlockPushNotifications::Providers::UserProfileFcm.send_push_notification(title: "alert notification", message: "Delete the farm dairy record", user_ids: [current_farmer.id], type: params[:type], deleted_id: params[:id])
      BxBlockPushNotifications::PushNotification.create(push_notificable_type: params[:type], push_notificable_id: params[:id], remarks: "Delete the farm dairy pre sowing record", account_id: current_farmer.id, is_delete_request: true)
      
      if response.status == 200
        render json:{meta: {message: "Delete request will send to field executive"}}
      end
    end

    private

    def update_pre_sowing_compost_params
      params.require(:pre_sowing_compost).permit(:pre_sowing_activity_id, :date, :compost_cost, :labor_cost, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year)
    end

    def pre_sowing_compost_params
      pre_sowing_compost = params[:pre_sowing_compost]

      pre_sowing_compost.map do |pre_sowing_compost_params|
        pre_sowing_compost_params.permit(:pre_sowing_activity_id, :date, :compost_cost, :labor_cost, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year)
      end
    end

  end
end
