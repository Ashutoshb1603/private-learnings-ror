module BxBlockFarmDairy
  class HarvestsController < ApplicationController

    before_action :current_farmer

    def index
      @harvest = BxBlockFarmDairy::Harvest.all
      render json: @harvest, status: :ok
    end

    def create
      account = AccountBlock::Account.find_by(id: current_farmer.id)
      harvest = account.harvests.create!(harvest_params)
    
      if harvest.present?
        serializer = BxBlockFarmDairy::HarvestSerializer.new(harvest)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{harvest: harvest.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def show
      harvest = BxBlockFarmDairy::Harvest.find(params[:id])
      
      if harvest.present?
        serializer = BxBlockFarmDairy::HarvestSerializer.new(harvest)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{harvest: harvest.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def update
      if current_user.role_id == 1
        harvest = BxBlockFarmDairy::Harvest.find(params[:id])
        if harvest.update(update_harvest_params)
          serializer = BxBlockFarmDairy::HarvestSerializer.new(harvest)
          render json: serializer.serializable_hash,
            status: :ok
        else
          render json: {errors: [{harvest: harvest.errors.full_messages}]},
            status: :unprocessable_entity
        end
      else
        render json:{meta: {message: "Only field executive can delete the record."}}
      end
    end

    def destroy
      harvest = BxBlockFarmDairy::Harvest.find_by(id: params[:id])
      if harvest&.destroy
        render json:{ meta: { message: "Harvest record deleted"}}
      else
        render json:{meta: {message: "Record not found."}}
      end
    end

    def delete_harvest_request
      BxBlockPushNotifications::Providers::UserProfileFcm.send_push_notification(title: "alert notification", message: "Delete the farm dairy record", user_ids: [current_farmer.id], type: params[:type], deleted_id: params[:id])
      BxBlockPushNotifications::PushNotification.create(push_notificable_type: params[:type], push_notificable_id: params[:id], remarks: "Delete the farm dairy harvest record", account_id: current_farmer.id, is_delete_request: true)
      
      if response.status == 200
        render json:{meta: {message: "Delete request will send to field executive"}}
      end
    end

    private

    def update_harvest_params
      params.require(:harvest).permit(:date_of_picking, :quantity_picked, :total_picking_cost, :storage_type_id, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year)
    end

    def harvest_params
      harvest = params[:harvest]

      harvest.map do |harvest_params|
        harvest_params.permit(:date_of_picking, :quantity_picked, :total_picking_cost, :storage_type_id, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year)
      end
    end
  end
end
