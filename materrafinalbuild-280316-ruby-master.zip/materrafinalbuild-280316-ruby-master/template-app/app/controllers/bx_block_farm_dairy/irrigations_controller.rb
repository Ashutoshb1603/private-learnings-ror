module BxBlockFarmDairy
  class IrrigationsController < ApplicationController

    before_action :current_farmer

    def index
      @irrigation = BxBlockFarmDairy::Irrigation.all
      render json: @irrigation, status: :ok
    end

    def create
      account = AccountBlock::Account.find_by(id: current_farmer.id)
      irrigation = account.irrigations.create!(irrigation_params)
     
      if irrigation.present?
        serializer = BxBlockFarmDairy::IrrigationSerializer.new(irrigation)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{irrigation: irrigation.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def show
      irrigation = BxBlockFarmDairy::Irrigation.find(params[:id])
      
      if irrigation.present?
        serializer = BxBlockFarmDairy::IrrigationSerializer.new(irrigation)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{irrigation: irrigation.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def update
      irrigation = BxBlockFarmDairy::Irrigation.find(params[:id])
      if irrigation.update(update_irrigation_params)
        serializer = BxBlockFarmDairy::IrrigationSerializer.new(irrigation)
        render json: serializer.serializable_hash,
          status: :ok
      else
        render json: {errors: [{irrigation: irrigation.errors.full_messages}]},
          status: :unprocessable_entity
      end
    end

    def destroy
      if current_user.role_id == 1
        irrigation = BxBlockFarmDairy::Irrigation.find_by(id: params[:id])
        if irrigation&.destroy
          render json:{ meta: { message: "Irrigation record deleted"}}
        else
          render json:{meta: {message: "Record not found."}}
        end
      else
        render json:{meta: {message: "Only field executive can delete the record."}}
      end
    end

    def delete_irrigation_request
      BxBlockPushNotifications::Providers::UserProfileFcm.send_push_notification(title: "alert notification", message: "Delete the farm dairy record", user_ids: [current_farmer.id], type: params[:type], deleted_id: params[:id])
      BxBlockPushNotifications::PushNotification.create(push_notificable_type: params[:type], push_notificable_id: params[:id], remarks: "Delete the farm dairy irrigation record", account_id: current_farmer.id, is_delete_request: true)
      
      if response.status == 200
        render json:{meta: {message: "Delete request will send to field executive"}}
      end
    end

    private

    def update_irrigation_params
      params.require(:irrigation).permit(:date_of_irrigation, :hours_of_irrigation, :labor_cost, :source_irrigation_id, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year)
    end

    def irrigation_params
      irrigation = params[:irrigation]

      irrigation.map do |irrigation_params|
        irrigation_params.permit(:date_of_irrigation, :hours_of_irrigation, :labor_cost, :source_irrigation_id, :land_detail_id, :crop_season_id, :crop_start_year, :crop_end_year)
      end
    end
  end
end
