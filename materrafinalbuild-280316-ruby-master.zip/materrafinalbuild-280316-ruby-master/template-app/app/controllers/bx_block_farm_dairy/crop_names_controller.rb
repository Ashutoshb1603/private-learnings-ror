module BxBlockFarmDairy
  class CropNamesController < ApplicationController

    def index
      @crop_name = BxBlockFarmDairy::CropName.where(active: true)
      render json: @crop_name, status: :ok
    end

  end
end
