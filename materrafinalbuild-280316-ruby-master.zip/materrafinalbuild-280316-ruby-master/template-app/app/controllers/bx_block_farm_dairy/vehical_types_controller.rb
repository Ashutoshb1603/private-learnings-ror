module BxBlockFarmDairy
  class VehicalTypesController < ApplicationController

    def index
      @vehical_type = BxBlockFarmDairy::VehicalType.where(active: true)
      render json: @vehical_type, status: :ok
    end

  end
end
