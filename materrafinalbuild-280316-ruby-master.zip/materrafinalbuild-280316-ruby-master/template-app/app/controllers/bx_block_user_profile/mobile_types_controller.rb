module BxBlockUserProfile
  class MobileTypesController < ApplicationController

    def index
      @mobile_types = BxBlockUserProfile::MobileType.where(active: true)
      render json: @mobile_types, status: :ok
    end

  end
end

