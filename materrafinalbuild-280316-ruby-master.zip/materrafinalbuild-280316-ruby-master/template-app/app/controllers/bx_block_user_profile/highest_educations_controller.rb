module BxBlockUserProfile
  class HighestEducationsController < ApplicationController

    def index
      @highest_educations = BxBlockUserProfile::HighestEducation.where(active: true)
      render json: @highest_educations, status: :ok
    end

  end
end

