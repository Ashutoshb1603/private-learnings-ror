module BxBlockUserProfile
  class NumberBelongsTosController < ApplicationController

    def index
      @number_belongs_to = BxBlockUserProfile::NumberBelongsTo.where(active: true)
      render json: @number_belongs_to, status: :ok
    end

  end
end

