class ApplicationController < ActionController::Base
	protect_from_forgery unless: -> { request.format.json? }
	before_action :set_locale

	def access_denied(exception)
		redirect_to admin_root_path, alert: exception.message
	end

	def set_locale
		language = request.headers[:language]&.downcase || params[:language]&.downcase
		case language
		when 'hindi'
			I18n.locale = :hn
		when 'gujarati'
			I18n.locale = :gj
		else
			I18n.locale = :en
		end
	end
end
