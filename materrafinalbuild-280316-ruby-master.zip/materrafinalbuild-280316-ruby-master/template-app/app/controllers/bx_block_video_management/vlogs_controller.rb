module BxBlockVideoManagement
  class VlogsController < BxBlockVideoManagement::ApplicationController
    before_action :set_vlog, only:[:show, :destroy, :update]
    before_action :super_admin, only: [:create, :update, :destroy]

    def index
      @vlogs = Vlog.all.order('created_at DESC').paginate(page: params[:page], per_page: 50)
      render json: VlogSerializer.new(@vlogs).serializable_hash, status: 200
    end

    def show
      render json: VlogSerializer.new(@vlog).serializable_hash, status: 200
    end

    def create
      validator = VlogValidation.new(params)
      return render json: {errors: [
          {vlog: validator.errors},
      ]}, status: :unprocessable_entity unless validator.valid?

      @vlog = Vlog.new(permit_params(params))
      @vlog.account_id = current_user.id
      if @vlog.save
        render json: VlogSerializer.new(@vlog).serializable_hash, status: 200
      else
        render json: {
            errors: [{
                         account: 'Invalid data format',
                     }],
        }, status: :unprocessable_entity
      end
    end

    def update
      validator = VlogValidation.new(params)
      return render json: {errors: [
          {vlog: validator.errors},
      ]}, status: :unprocessable_entity unless validator.valid?

      if @vlog.update(permit_params(params))
        render json: VlogSerializer.new(@vlog).serializable_hash, status: 200
      else
        render json: {
            errors: [{
                         account: 'Invalid data format',
                     }],
        }, status: :unprocessable_entity
      end
    end

    def destroy
      if @vlog.update(is_deleted: true)
        render json: { message: "success" }, status: 200
      else
        render json: {
            errors: [{
                         account: 'Invalid data format',
                     }],
        }, status: :unprocessable_entity
      end
    end

    private

    def set_vlog
      @vlog = Vlog.find_by(id: params[:id])
      render json: { message: "Invalid vlog id" }, status: 422 and return unless @vlog.present?
    end

    def permit_params(params)
      params.permit(:name, :description, :is_deleted, :avatar, :video)
    end
  end
end
