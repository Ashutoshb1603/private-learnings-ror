module BxBlockVideoManagement
  class ApplicationController < BuilderBase::ApplicationController
    include BuilderJsonWebToken::JsonWebTokenValidation

    before_action :validate_json_web_token

    rescue_from ActiveRecord::RecordNotFound, :with => :not_found

    def current_user
      AccountBlock::Account.find(@token.id)
    end

    def super_admin
      #if current_user.role == "guest"
      if is_guest?
        return render :json => {'errors' => ['You do not have permission to access']}
      end
    end

    private

    def not_found
      render :json => {'errors' => ['Record not found']}, :status => :not_found
    end

    def is_guest?
      role = BxBlockRolesPermissions::Role.find_by(id: self.current_user.role_id)
      return false unless role
      role.name == 'guest'
    end
  end
end
