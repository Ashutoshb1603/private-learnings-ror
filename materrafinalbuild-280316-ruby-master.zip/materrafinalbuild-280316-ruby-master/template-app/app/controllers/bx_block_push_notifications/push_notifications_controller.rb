# frozen_string_literal: true

module BxBlockPushNotifications
  class PushNotificationsController < ApplicationController
    def index
      push_notifications = BxBlockPushNotifications::PushNotification.unread_notifications.where('account_id = ?', current_user.id).order(id: :desc)
      if push_notifications.present?
        serializer = BxBlockPushNotifications::PushNotificationSerializer.new(
          push_notifications
        )
        render json: serializer.serializable_hash, status: :ok
      else
        render json: {
          errors: 'There is no push notification.'
        }, status: :not_found
      end
    end

    def create
      push_notification = BxBlockPushNotifications::PushNotification.new(
        push_notifications_params.merge({ account_id: current_user.id })
      )
      if push_notification.save
        serializer = BxBlockPushNotifications::PushNotificationSerializer.new(push_notification)
        render json: serializer.serializable_hash, status: :ok
      else
        render json: {
          errors: [{
            push_notification: push_notification.errors.full_messages
          }]
        }, status: :unprocessable_entity
      end
    rescue Exception => e
      render json: { errors: [{ push_notification: e.message }] },
             status: :unprocessable_entity
    end

    def update
      push_notification = PushNotification.find(params[:id])
      if push_notification.update(is_read: true)
        render json: BxBlockPushNotifications::PushNotificationSerializer.new(push_notification, meta: {
                                                                                message: 'Push Notification marked as read.'
                                                                              }).serializable_hash, status: :ok
      else
        render json: { errors: format_activerecord_errors(push_notification.errors) },
               status: :unprocessable_entity
      end
    end

    def show
      push_notification = current_user.push_notifications.find(params[:id])

      if push_notification.blank?
        render json: { message: 'Push Notification Not Found' },
               status: :not_found
      else
        render json: BxBlockPushNotifications::PushNotificationSerializer.new(push_notification)
      end
    end

    def read_notification
      push_notification = current_user.push_notifications.find(params[:id])
      if push_notification.present?
        push_notification.update(is_read: params[:is_read])
        render json: BxBlockPushNotifications::PushNotificationSerializer.new(push_notification)
      else
        render json: { message: 'Push Notification Not Found' },
               status: :not_found
      end
    end

    private

    def push_notifications_params
      params.require(:data)[:attributes].permit(
        :push_notificable_id,
        :push_notificable_type,
        :remarks, :is_read
      )
    end
  end
end
