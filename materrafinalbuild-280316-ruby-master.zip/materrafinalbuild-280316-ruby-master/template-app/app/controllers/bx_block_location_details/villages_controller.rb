module BxBlockLocationDetails
  class VillagesController < ApplicationController

    def index
      @villages = BxBlockLocationDetails::Village.where(taluka_id: params[:taluka_id], active: true)
      render json: @villages, status: :ok
    end

    def search
      @villages_ids = current_user.accounts_villages.pluck(:village_id)
      @villages = BxBlockLocationDetails::Village.where(id: @villages_ids)
      @villages = @villages.where('name LIKE ?', "%#{params[:name]}%")
      if @villages.present?
        village_data = ::BxBlockLocationDetails::VillageSerializer.new(@villages).serializable_hash
        render json: village_data, status: :ok
      else
        render json: { errors: 'Record Not Found' },
               status: :unprocessable_entity
      end  
    end

  end
end

