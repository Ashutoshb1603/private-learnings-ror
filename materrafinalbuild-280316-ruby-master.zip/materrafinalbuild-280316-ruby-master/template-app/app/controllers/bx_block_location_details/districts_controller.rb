module BxBlockLocationDetails
  class DistrictsController < ApplicationController

    def index
      @districts = BxBlockLocationDetails::District.where(state_id: params[:state_id], active: true)
      render json: @districts, status: :ok
    end

  end
end

