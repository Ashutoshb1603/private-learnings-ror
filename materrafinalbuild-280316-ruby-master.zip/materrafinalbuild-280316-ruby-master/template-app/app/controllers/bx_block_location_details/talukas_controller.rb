module BxBlockLocationDetails
  class TalukasController < ApplicationController

    def index
      @talukas = BxBlockLocationDetails::Taluka.where(district_id: params[:district_id], active: true)
      render json: @talukas, status: :ok
    end

  end
end

