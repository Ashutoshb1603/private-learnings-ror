module BxBlockLocationDetails
  class StatesController < ApplicationController

    def index
      @states = BxBlockLocationDetails::State.where(active: true)
      render json: @states, status: :ok
    end

  end
end

