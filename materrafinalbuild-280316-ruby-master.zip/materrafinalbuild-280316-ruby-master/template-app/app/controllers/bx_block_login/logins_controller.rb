# frozen_string_literal: true

module BxBlockLogin
  class LoginsController < ApplicationController
  include BuilderJsonWebToken::JsonWebTokenValidation
   before_action :validate_json_web_token, only: %i[login_as_farmer]
    before_action :check_field_executive, only: %i[login_as_farmer]
   
    def login_through_otp
      account_params = jsonapi_deserialize(params)
      validator = AccountBlock::PhoneValidation.new(account_params['full_phone_number'])
      unless validator.valid?
        return render json: { errors: [
          { account: 'phone number invalid' }
        ] }, status: :unprocessable_entity
      end

      @account = AccountBlock::Account.where('full_phone_number = ?', account_params['full_phone_number']).first

      unless @account
        return render json: { errors: [
          { account: 'Account Not Found' }
        ] }, status: :unprocessable_entity
      end

      sms_otp = AccountBlock::SmsOtp.new(full_phone_number: @account.full_phone_number)
      if sms_otp.save
        render json: AccountBlock::AccountSerializer.new(@account, serialization_options.merge(meta: { otp: sms_otp.pin, token: encode(sms_otp.id) })).serializable_hash,
               status: :created
      else
        render json: { errors: 'Otp not created' },
               status: :unprocessable_entity
      end
    end

    def login_as_farmer
     account = AccountBlock::Account.where(role_id: 2).where(village_id: current_user.villages.ids).find_by(id: params[:farmer_id])
     if account.present?
        token, refresh_token = generate_tokens(current_user.id, params[:farmer_id])
        render json: {meta: {
          token: token,
          refresh_token: refresh_token,
          id: current_user.id,
          role_id: current_user.role_id
        }}
     else
       render json: { errors: 'farmer not associated' }
     end
    end

    private

    def serialization_options
      { params: { host: request.protocol + request.host_with_port } }
    end

    def encode(id)
      BuilderJsonWebToken.encode id
    end

    def check_field_executive
      render json: { errors: 'user not a field executive' } unless current_user.role_id == 1
    end

    def generate_tokens(account_id, farmer_id = nil)
      [
        BuilderJsonWebToken.encode(account_id, 2.month.from_now, token_type: 'login', farmer_id: farmer_id),
        BuilderJsonWebToken.encode(account_id, 1.year.from_now, token_type: 'refresh', farmer_id: farmer_id)
      ]
    end
  end
end
