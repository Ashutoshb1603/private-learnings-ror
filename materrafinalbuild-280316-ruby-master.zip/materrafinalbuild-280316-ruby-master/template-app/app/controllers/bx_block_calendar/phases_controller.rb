module BxBlockCalendar
  class PhasesController < ApplicationController

    before_action :current_farmer

    def index
      phases = ::BxBlockCalendar::Phase.all.order(start_day: :asc)
      data = ::BxBlockCalendar::PhaseSerializer.new(phases, serialization_options).serializable_hash
      render json: data, status: :ok
    end

    def show
      phase = ::BxBlockCalendar::Phase.find(params[:id])
      data = ::BxBlockCalendar::PhaseSerializer.new(phase, serialization_options).serializable_hash
      render json: data, status: :ok
    end

    def get_phase_activity_progress
      phase_activity_progress = ::BxBlockCalendar::PhaseActivityProgress.find(params[:phase_activity_progress_id])

      data = ::BxBlockCalendar::PhaseActivityProgressSerializer.new(phase_activity_progress, serialization_options).serializable_hash
      render json: data, status: :ok
    end

    def get_sub_activity_progress
      sub_activity_progress = ::BxBlockCalendar::SubActivityProgress.find_by(id: params[:sub_activity_progress])
      data = ::BxBlockCalendar::SubActivityProgressSerializer.new(sub_activity_progress).serializable_hash
      render json: data, status: :ok
    end

    def update_sub_activity_progress  
      if current_user.present? || current_farmer.present?
        sub_activity_progress =  ::BxBlockCalendar::SubActivityProgress.find_by(id: params[:sub_activity_progress_id], farmer_id: current_farmer.id)
        sub_activity_progress = ::BxBlockCalendar::SubActivityProgress.find_by(id: params[:sub_activity_progress_id], farmer_id: nil) if sub_activity_progress.nil?
        sub_progresses = ::BxBlockCalendar::SubActivityProgress.where(phase_sub_activity_id: sub_activity_progress.phase_sub_activity_id, phase_activity_progress_id: sub_activity_progress.phase_activity_progress_id)
        if sub_activity_progress.farmer_id.nil?
          sub_progresses = sub_progresses.where(farmer_id: nil)
          ids = []
          sub_progresses.each do |sub_progress|
            sub_activity_progress = ::BxBlockCalendar::SubActivityProgress.create(before_after_day: sub_activity_progress.before_after_day, attachment: sub_activity_progress.attachment, description: sub_activity_progress.description, is_completed: params[:is_completed], phase_activity_progress_id: sub_activity_progress.phase_activity_progress_id, phase_sub_activity_id: sub_activity_progress.phase_sub_activity_id, parent_id: sub_progress.id, farmer_id: current_farmer.id)
              ids << sub_activity_progress&.id
          end
          sub_activity_progress = ::BxBlockCalendar::SubActivityProgress.where(parent_id: params[:sub_activity_progress_id], farmer_id: current_farmer.id, id: ids).last
        else
          sub_progresses.where.not(farmer_id: nil).update_all(is_completed: params[:is_completed])
        end
        data = ::BxBlockCalendar::SubActivityProgressSerializer.new(sub_activity_progress.reload).serializable_hash
        render json: data, status: :ok
      end
    end
  end
end