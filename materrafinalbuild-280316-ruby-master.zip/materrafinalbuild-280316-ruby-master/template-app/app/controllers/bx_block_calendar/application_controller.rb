module BxBlockCalendar
  class ApplicationController < BuilderBase::ApplicationController
    include BuilderJsonWebToken::JsonWebTokenValidation

    before_action :validate_json_web_token

    rescue_from ActiveRecord::RecordNotFound, :with => :not_found

    private

    def not_found
      render :json => {'errors' => ['Record not found']}, :status => :not_found
    end

    def current_user
      return unless @token
      @current_user ||= AccountBlock::Account.find(@token.id)
    end

    def current_farmer
      if current_user.role_id == 2
        @current_farmer ||= current_user
      else
        @current_farmer ||= AccountBlock::Account.find_by(id: @token&.farmer_id) 
      end
      if @current_farmer
         @current_farmer
      else
        render json: { 'errors' => ['Invalid farmer data access'] } and return
      end
    end

    def serialization_options
      { params: { host: request.protocol + request.host_with_port, current_user: current_farmer } }
    end
  end
end
