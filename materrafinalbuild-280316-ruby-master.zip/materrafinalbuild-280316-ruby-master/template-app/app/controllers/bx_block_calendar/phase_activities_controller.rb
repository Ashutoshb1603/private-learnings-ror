module BxBlockCalendar
  class PhaseActivitiesController < ApplicationController

    def index
      @phase_activities = BxBlockCalendar::PhaseActivity.all
      render json: @phase_activities, status: :ok
    end

    def show
      phase_activity = ::BxBlockCalendar::PhaseActivity.find(params[:id])
      data = ::BxBlockCalendar::PhaseActivitySerializer.new(phase_activity).serializable_hash
      render json: data, status: :ok
    end

    def get_sub_activity
        phase_sub_activity = ::BxBlockCalendar::PhaseSubActivity.find_by(id: params[:id])
        render json: {data: {
        	      id: phase_sub_activity.id,
                  name: phase_sub_activity.name,
                  type: "phase sub activity",
              }}, status: :ok
    end
  end
end
