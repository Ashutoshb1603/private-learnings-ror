# frozen_string_literal: true

module BxBlockMatterapedia
  class LibrariesController < ApplicationController
    def index
      libraries = BxBlockMaterraPedia::Library.all
      render json: LibrariesSerializer.new(libraries, serialization_options).serializable_hash, status: 200
    end

    def show
      libraries = BxBlockMaterraPedia::Library.find(params[:id])
      render json: LibrariesSerializer.new(libraries, serialization_options).serializable_hash, status: 200
    end

    def create
      libraries = BxBlockMaterraPedia::Library.new(libraries_params)
      if libraries.save
        render json: LibrariesSerializer.new(libraries, serialization_options).serializable_hash, status: 201
      else
        render json: { errors: [{ libraries: libraries.errors.full_messages }] }, status: :unprocessable_entity
      end
    end

    def update
      libraries = BxBlockMaterraPedia::Library.find(params[:id])
      if libraries.update(libraries_params)
        render json: LibrariesSerializer.new(libraries, serialization_options).serializable_hash, status: :ok
      else
        render json: { errors: [{ libraries: libraries.errors.full_messages }] }, status: :unprocessable_entity
      end
    end

    def destroy
      libraries = BxBlockMaterraPedia::Library.find(params[:id])
      render json: { message: 'Deleted.' }, status: :ok if libraries.destroy
    end

    def search
      libraries = BxBlockMaterraPedia::Library.where('topic LIKE ?', "%#{params[:topic]}%")
      if libraries.present?
        search_data = LibrariesSerializer.new(libraries, serialization_options).serializable_hash
        render json: search_data, status: :ok
      else
        render json: { errors: 'Record Not Present' },
               status: :unprocessable_entity
      end
    end

    private

    def libraries_params
      params.require(:data)[:attributes].permit(:topic, :topic_hindi, :topic_gujrati, :description,
                                                :description_hindi, :description_gujrati, :video, :video_hindi, :video_gujrati)
    end

    def serialization_options
      { params: { host: request.protocol + request.host_with_port } }
    end
  end
end
