# frozen_string_literal: true

module BxBlockMatterapedia
  class ApplicationController < BuilderBase::ApplicationController
  end
end
