# frozen_string_literal: true

module BxBlockMatterapedia
  class FaqsController < ApplicationController
    def index
      faqs = BxBlockMaterraPedia::Faq.all
      render json: BxBlockMatterapedia::FaqsSerializer.new(faqs, serialization_options).serializable_hash, status: 200
    end

    def show
      faq = BxBlockMaterraPedia::Faq.find(params[:id])
      render json: BxBlockMatterapedia::FaqsSerializer.new(faq, serialization_options).serializable_hash, status: 200
    end

    def create
      faq = BxBlockMaterraPedia::Faq.new(faqs_params)
      if faq.save
        render json: BxBlockMatterapedia::FaqsSerializer.new(faq, serialization_options).serializable_hash,
               status: 201
      else
        render json: { errors: [{ faq: faq.errors.full_messages }] }, status: :unprocessable_entity
      end
    end

    def update
      faq = BxBlockMaterraPedia::Faq.find(params[:id])
      if faq.update(faqs_params)
        render json: BxBlockMatterapedia::FaqsSerializer.new(faq, serialization_options).serializable_hash,
               status: :ok
      else
        render json: { errors: [{ faq: faq.errors.full_messages }] }, status: :unprocessable_entity
      end
    end

    def destroy
      faq = BxBlockMaterraPedia::Faq.find(params[:id])
      render json: { message: 'Deleted.' }, status: :ok if faq.destroy
    end

    def search
      faq = BxBlockMaterraPedia::Faq.where('topic LIKE ?', "%#{params[:topic]}%")
      if faq.present?
        search_data = BxBlockMatterapedia::FaqsSerializer.new(faq, serialization_options).serializable_hash
        render json: search_data, status: :ok
      else
        render json: { errors: 'Record Not Present' },
               status: :unprocessable_entity
      end
    end

    private

    def faqs_params
      params.require(:data)[:attributes].permit(:topic, :topic_hindi, :topic_gujrati, :question, :question_hindi, :question_gujrati, :description,
                                                :description_hindi, :description_gujrati, :category_id, :video, :video_hindi, :video_gujrati)
    end

    def serialization_options
      { params: { host: request.protocol + request.host_with_port } }
    end
  end
end
