# frozen_string_literal: true

module BxBlockAbility
  class Ability
    include CanCan::Ability
    def initialize(user)
      # Define abilities for the user here. For example:
      #
      case user.role
      when 'super_admin'
        can :manage, :all
      when 'admin'
        can :manage, AccountBlock::Account
        cannot :destroy, AccountBlock::Account

        can :manage, BxBlockUserProfile::NumberBelongsTo
        can :manage, BxBlockUserProfile::MobileType
        can :manage, BxBlockUserProfile::HighestEducation
        can :manage, BxBlockLocationDetails::State
        can :manage, BxBlockLocationDetails::District
        can :manage, BxBlockLocationDetails::Taluka
        can :manage, BxBlockLocationDetails::Village
        can :manage, BxBlockWorkshop::Upcomingworkshop

        can :manage, BxBlockProfileBio::SourceIrrigation
        can :manage, BxBlockProfileBio::TypeIrrigation
        can :manage, BxBlockProfileBio::SoilTexture
        can :manage, BxBlockProfileBio::LandType
        can :manage, BxBlockCategories::Category
        can :manage, BxBlockCalendar::PhaseGroup
        can :manage, BxBlockCalendar::Phase
        can :manage, BxBlockCalendar::PhaseActivity
        can :manage, BxBlockCalendar::PhaseActivityProgress
        can :manage, BxBlockCalendar::PhaseSubActivity
        can :manage, BxBlockCalendar::SubActivityProgress
        can :manage, BxBlockCalendar::InputDetail

        can :manage, BxBlockFarmDairy::BioAgentRelease
        can :manage, BxBlockFarmDairy::BioAgent
        can :manage, BxBlockFarmDairy::CropArea
        can :manage, BxBlockFarmDairy::CropName
        can :manage, BxBlockFarmDairy::CropSeason
        can :manage, BxBlockFarmDairy::CropType
        can :manage, BxBlockFarmDairy::NutrientManagment
        can :manage, BxBlockFarmDairy::PestManagment
        can :manage, BxBlockFarmDairy::Pesticide
        can :manage, BxBlockFarmDairy::PreSowingActivity
        can :manage, BxBlockFarmDairy::QuantityOfNutrient
        can :manage, BxBlockFarmDairy::SeedSource
        can :manage, BxBlockFarmDairy::StorageType
        can :manage, BxBlockFarmDairy::TypeOfTrap
        can :manage, BxBlockFarmDairy::UnitOfMeasure
        can :manage, BxBlockFarmDairy::Variety
        can :manage, BxBlockFarmDairy::VehicalType
        can :manage, BxBlockFarmDairy::Weedicide
        can :manage, BxBlockFarmDairy::WeedingType

        can :manage, AdminUser
        cannot :destroy, AdminUser

        can [:read], BxBlockSettings::TermAndCondition
        can [:read], BxBlockSettings::PrivacyPolicy
        can [:read], BxBlockSettings::AboutMaterra

        can :read, BxBlockChat::Chat
        can :manage, ActiveAdmin::Page, name: 'Dashboard', namespace_name: 'admin'
        can :read, BxBlockChat::ChatMessage
        can :manage, BxBlockImport::Import
      end

      # The first argument to `can` is the action you are giving the user
      # permission to do.
      # If you pass :manage it will apply to every action. Other common actions
      # here are :read, :create, :update and :destroy.
      #
      # The second argument is the resource the user can perform the action on.
      # If you pass :all it will apply to every resource. Otherwise pass a Ruby
      # class of the resource.
      #
      # The third argument is an optional hash of conditions to further filter the
      # objects.
      # For example, here the user can only update published articles.
      #
      #   can :update, Article, published: true
      #
      # See the wiki for details:
      # https://github.com/CanCanCommunity/cancancan/blob/develop/docs/define_check_abilities.md
    end
  end
end
