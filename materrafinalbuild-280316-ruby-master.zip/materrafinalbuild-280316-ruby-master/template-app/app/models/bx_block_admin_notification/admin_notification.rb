module BxBlockAdminNotification
  class AdminNotification < BxBlockAdminNotification::ApplicationRecord
    self.table_name = :admin_notifications

    belongs_to :notification_type, class_name: "BxBlockAdminNotification::NotificationType"
		has_many :language_notifications, class_name: "BxBlockLanguageNotification::LanguageNotification", dependent: :destroy
		accepts_nested_attributes_for :language_notifications, allow_destroy: true

    
    before_save :push_notification

    validate :language_vaildation

    private

	def push_notification
		@data = []
		account_data = AccountBlock::Account.where('first_name LIKE ? OR last_name LIKE ?', "%#{self.send_to}%", "%#{self.send_to}%")
		chats = BxBlockChat::Chat.where('name LIKE ?', "%#{self.send_to}%")
		chats.map{|chat|
        	account_ids = chat.accounts_chats.pluck(:account_id)
        	@chat_account_data = AccountBlock::Account.where(id: account_ids)
      	}
      	@data << account_data.to_a
      	@data << @chat_account_data.to_a
      	account_ids = @data.flatten.uniq.pluck(:id)
      
		BxBlockPushNotifications::Providers::UserProfileFcm.send_push_notification(title: 'notification', message: 'Please complete your profile details', user_ids: account_ids, type: 'admin_user_notification');
	end

	def language_vaildation
		language = self.language_notifications.map(&:language)
		language.detect{ |e| language.count(e) > 1 }.present? ? errors[:base] << "Duplicate language entry" : ''
		data = self.language_notifications.map{|data| data.title != nil && data.description != nil && data.image.present?}
		data.map{|option|
			if option == false
				errors[:base] << "Fill other language data"
				break
			end
		} 
	end
  end
end