module BxBlockAdminNotification
  class NotificationType < BxBlockAdminNotification::ApplicationRecord
    self.table_name = :notification_types
		

	has_one :admin_notification, class_name: "BxBlockAdminNotification::AdminNotification"
  end
end