module BxBlockCalendar
	class PhaseActivity < BxBlockCalendar::ApplicationRecord
		self.table_name = :phase_activities
		has_many :phase_sub_activities, class_name: 'BxBlockCalendar::PhaseSubActivity', dependent: :destroy
		has_many :phase_activity_progresses, class_name: 'BxBlockCalendar::PhaseActivityProgress', dependent: :destroy
		validates :name, :name_hindi, :name_gujarati, presence: true
		# has_many :phase_activities, class_name: 'BxBlockCalendar::PhaseActivity'
		accepts_nested_attributes_for :phase_sub_activities, allow_destroy: true

		alias_attribute :name_english, :name
		validates :name, :name_hindi, :name_gujarati, presence: true
    end
end
