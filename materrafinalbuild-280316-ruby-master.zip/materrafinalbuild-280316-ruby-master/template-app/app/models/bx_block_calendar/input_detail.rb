module BxBlockCalendar
	class InputDetail < BxBlockCalendar::ApplicationRecord
      self.table_name = :input_details
      belongs_to :sub_activity_progress, class_name: 'BxBlockCalendar::SubActivityProgress'
  end
end
