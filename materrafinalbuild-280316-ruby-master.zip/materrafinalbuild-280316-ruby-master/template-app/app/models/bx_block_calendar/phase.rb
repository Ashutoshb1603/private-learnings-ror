module BxBlockCalendar
  class Phase < BxBlockCalendar::ApplicationRecord
    self.table_name = :phases
    belongs_to :phase_group, class_name: 'BxBlockCalendar::PhaseGroup', optional: true
    has_many :phase_activity_progresses, class_name: 'BxBlockCalendar::PhaseActivityProgress', dependent: :destroy
    accepts_nested_attributes_for :phase_activity_progresses, allow_destroy: true
    enum language: { English: 0, Hindi: 1, Gujarati: 2 }

    validates :name, uniqueness: true
    validates :start_day, :end_day, :name, presence: true

    validate :validate_days

    validate :activity_progress_present, on: :create

    default_scope { order('start_day ASC') }

    def validate_days
    	if self.start_day.to_i > self.end_day.to_i 
    		errors[:day] << "Start day is smaller than end day"
    	end
    end

    # def destroy
    #   if self.name == "Sowing"
    #     self.phase_group.errors.add(:base, "Sowing can't be destroy")
    #     throw :abort
    #   end
    #   super
    # end

    private

    def activity_progress_present
      if self.phase_group.present?
        self.phase_group.errors.add(:base, "Phase activity progress not present") unless self.phase_activity_progresses.present?
        if self.phase_activity_progresses.present?
          self.phase_group.errors.add(:base, "Sub activity progress not present") unless  self.phase_activity_progresses.first&.sub_activity_progresses
        end
      end
    end
  end
end
