module BxBlockCalendar
	class PhaseActivityProgress < BxBlockCalendar::ApplicationRecord
		self.table_name = :phase_activity_progresses
		belongs_to :phase, class_name: 'BxBlockCalendar::Phase'
        belongs_to :phase_activity, class_name: 'BxBlockCalendar::PhaseActivity'
        has_many :sub_activity_progresses, class_name: 'BxBlockCalendar::SubActivityProgress', dependent: :destroy
		accepts_nested_attributes_for :sub_activity_progresses, allow_destroy: true

		validates :start_day, :end_day, presence: true

	  validate :validate_days

	  def validate_days
	  	if self.start_day.to_i > self.end_day.to_i 
	  		errors[:day] << "Start day is smaller than end day"
	  	end
	  end
	end
end
