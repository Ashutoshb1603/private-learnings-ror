class AdminUser < ApplicationRecord
    # Include default devise modules. Others available are:
    # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
    devise :database_authenticatable,
           :recoverable, :rememberable, :validatable, :trackable
    enum role: { 'super_admin' => 0, 'admin' => 1 }

    has_many :phase_groups, as: :owner
    has_many :accounts_chats, class_name: 'BxBlockChat::AccountsChatsBlock'
    has_many :chats, class_name: 'BxBlockChat::Chat', through: :accounts_chats
    has_many :devices, class_name: 'AccountBlock::Device', dependent: :destroy
    has_many :push_notifications, class_name: 'BxBlockPushNotifications::PushNotification', dependent: :destroy
    has_many :admin_events, class_name: "BxBlockNewsAndEvents::AdminEvent"
    scope :admins, -> { where(role: 'admin') }

    def display_name
      "#{first_name} #{last_name}"
    end
end
