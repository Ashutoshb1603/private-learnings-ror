module AccountBlock
  class ApplicationRecord < BuilderBase::ApplicationRecord
    self.abstract_class = true
    include ActiveStorageSupport::SupportForBase64

  end
end
