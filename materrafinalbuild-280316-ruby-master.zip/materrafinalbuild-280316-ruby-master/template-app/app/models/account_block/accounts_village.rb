module AccountBlock
	class AccountsVillage < AccountBlock::ApplicationRecord
	  self.table_name = :accounts_villages
	  belongs_to :account, class_name: "AccountBlock::Account"
	  belongs_to :village, class_name: 'BxBlockLocationDetails::Village'

	  validates :village_id, uniqueness: true, if: :fe_role?
	  
    def fe_role?
      self.account.role_id == 1
    end
	end
end