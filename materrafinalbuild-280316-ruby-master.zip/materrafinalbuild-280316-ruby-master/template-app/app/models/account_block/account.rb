# frozen_string_literal: true

module AccountBlock
  class Account < AccountBlock::ApplicationRecord
    self.table_name = :accounts

    include Wisper::Publisher
    has_one_base64_attached :avatar
    RENTED_IRRIGATION = "BxBlockFarmDairy::RentedIrrigation"
    FARM_DAIRY_MODEL = [{
        "Nutrient Management": ["BxBlockFarmDairy::Nutrient"]
      },{
        "Pest Management": ["BxBlockFarmDairy::PestManagementFoliarSpray", "BxBlockFarmDairy::PestManagementBio", "BxBlockFarmDairy::PestManagementTrap"]
      }, {
        "Pre Sowing": ["BxBlockFarmDairy::PreSowing", "BxBlockFarmDairy::PreSowingCompost"]
      }, {
        "Sowing": ["BxBlockFarmDairy::Sowing"]
      }, {
        "Gap filling": ["BxBlockFarmDairy::GapFilling"]
      }, {
        "Sale": ["BxBlockFarmDairy::Sale"]
      }, {
        "Weeding Management": ["BxBlockFarmDairy::WeedManagement"]
      }, {
        "Irrigation": ["BxBlockFarmDairy::Irrigation", "BxBlockFarmDairy::IrrigationDrip",
          RENTED_IRRIGATION, "BxBlockFarmDairy::IrrigationSprinkler"]
      }, {
        "Harvest": ["BxBlockFarmDairy::Harvest"]
      }]

      ADMIN_FARM_DAIRY_MODEL = [{
        "Nutrient Management": ["BxBlockFarmDairy::Nutrient"]
      },{
        "Pest Management Foliar Spray": ["BxBlockFarmDairy::PestManagementFoliarSpray"]
      },{
        "Pest Management Trap": ["BxBlockFarmDairy::PestManagementTrap"]
      }, {
        "Pest Management Bio": ["BxBlockFarmDairy::PestManagementBio"]
      }, {
        "Pre Sowing": ["BxBlockFarmDairy::PreSowing"]
      }, {
        "Pre Sowing Compost": ["BxBlockFarmDairy::PreSowingCompost"]
      }, {
        "Sowing": ["BxBlockFarmDairy::Sowing"]
      }, {
        "Gap filling": ["BxBlockFarmDairy::GapFilling"]
      }, {
        "Sale": ["BxBlockFarmDairy::Sale"]
      }, {
        "Weed Management": ["BxBlockFarmDairy::WeedManagement"]
      }, {
        "Irrigation": ["BxBlockFarmDairy::Irrigation"]
      }, {
        "Irrigation Drip": ["BxBlockFarmDairy::IrrigationDrip"]
      },{
         "Irrigation Sprinkler": ["BxBlockFarmDairy::IrrigationSprinkler"]
      }, {
        "Harvest": ["BxBlockFarmDairy::Harvest"]
      }]

    # associations
    has_one :blacklist_user, class_name: 'AccountBlock::BlackListUser', dependent: :destroy
    has_many :devices, class_name: 'AccountBlock::Device', dependent: :destroy
    has_many :land_details, class_name: 'BxBlockProfileBio::LandDetail', dependent: :destroy
    has_many :push_notifications, class_name: 'BxBlockPushNotifications::PushNotification', dependent: :destroy
    has_many :notifications, class_name: 'BxBlockNotifications::Notification', dependent: :destroy,
                             foreign_key: :account_id
    # has_many :phase_groups, class_name: 'BxBlockCalendar::PhaseGroup', dependent: :destroy
    has_many :accounts_villages, class_name: 'AccountBlock::AccountsVillage', dependent: :destroy
    # has_many :field_villages, class_name: 'BxBlockLocationDetails::Village', through: :accounts_villages, source: :village
    has_many :weed_managements, class_name: 'BxBlockFarmDairy::WeedManagement', dependent: :destroy
    has_many :villages, class_name: 'BxBlockLocationDetails::Village', through: :accounts_villages
    has_many :nutrients, class_name: 'BxBlockFarmDairy::Nutrient', dependent: :destroy
    has_many :sales, class_name: 'BxBlockFarmDairy::Sale', dependent: :destroy
    has_many :pest_managment_foliar_sprays, class_name: 'BxBlockFarmDairy::PestManagementFoliarSpray', dependent: :destroy
    has_many :pest_managment_traps, class_name: 'BxBlockFarmDairy::PestManagementTrap', dependent: :destroy
    has_many :pest_managment_bios, class_name: 'BxBlockFarmDairy::PestManagementBio', dependent: :destroy
    accepts_nested_attributes_for :accounts_villages, :allow_destroy => true
    accepts_nested_attributes_for :villages, :allow_destroy => true

    belongs_to :number_belongs_to, class_name: 'BxBlockUserProfile::NumberBelongsTo', optional: true
    belongs_to :highest_education, class_name: 'BxBlockUserProfile::HighestEducation', optional: true
    belongs_to :mobile_type, class_name: 'BxBlockUserProfile::MobileType', optional: true
    # belongs_to :role, class_name: "BxBlockRolesPermissions::Role"

    belongs_to :state, class_name: 'BxBlockLocationDetails::State', optional: true
    belongs_to :district, class_name: 'BxBlockLocationDetails::District', optional: true
    belongs_to :taluka, class_name: 'BxBlockLocationDetails::Taluka', optional: true
    belongs_to :village, class_name: 'BxBlockLocationDetails::Village', optional: true

    belongs_to :sub_activity_progress, class_name: 'BxBlockCalendar::SubActivityProgress', optional: true

    accepts_nested_attributes_for :land_details, allow_destroy: true

    has_one :profile, class_name: 'BxBlockProfile::Profile', dependent: :destroy
    
    #farm_dairy
    has_many :pre_sowings, class_name: 'BxBlockFarmDairy::PreSowing', dependent: :destroy
    has_many :pre_sowing_composts, class_name: 'BxBlockFarmDairy::PreSowingCompost', dependent: :destroy
    has_many :irrigations, class_name: 'BxBlockFarmDairy::Irrigation', dependent: :destroy
    has_many :irrigation_sprinklers, class_name: 'BxBlockFarmDairy::IrrigationSprinkler', dependent: :destroy

    has_many :irrigation_drips, class_name: 'BxBlockFarmDairy::IrrigationDrip', dependent: :destroy
    has_many :rented_irrigations, class_name: RENTED_IRRIGATION, dependent: :destroy
    has_many :gap_fillings, class_name: "BxBlockFarmDairy::GapFilling", dependent: :destroy

    has_many :sowings, class_name: 'BxBlockFarmDairy::Sowing', dependent: :destroy
    has_many :harvests, class_name: 'BxBlockFarmDairy::Harvest', dependent: :destroy

    # validations
    validates :first_name,
              format: { with: /^[A-Za-z ’']*$/, message: 'only alphabeticals allowed', multiline: true }, length: { maximum: 20 }, presence: true
    validates :middle_name,
              format: { with: /^[A-Za-z ’'-]*$/, message: 'only alphabeticals allowed', multiline: true }, length: { maximum: 20 }
    validates :last_name,
              format: { with: /^[A-Za-z ’'-]*$/, message: 'only alphabeticals allowed', multiline: true }, length: { maximum: 20 }, presence: true
    validates_presence_of :date_of_birth, message: 'is nil or invalid format' 

    validates :role_id, presence: true
    validates :state_id, :district_id, :village_id, :taluka_id, presence: true, unless: :fe_role?
    validates :aadhaar_number, numericality: true,
                               length: { minimum: 12, maximum: 12 }, unless: :fe_role?
    validates :total_family_members, numericality: { greater_than_or_equal_to: 0 }
    validates :full_phone_number, uniqueness: true
    validate :valid_phone_number
    # user not update there profile more than 2 time
    # comment for testing purpose 
    # validate :update_count
  
    # callbacks
    before_validation :parse_full_phone_number
    before_create :generate_api_key
    after_save :set_black_listed_user
    before_save :random_password_generate

    # scope
    scope :active, -> { where(activated: true) }
    scope :existing_accounts, -> { where(status: %w[regular suspended]) }
    scope :field_executive_role, -> { where(role_id: 1) }
    scope :farmer_role, -> { where(role_id: 2) }

    # enum
    enum status: %i[regular suspended deleted]
    enum role: { field_executive: 1, farmer: 2 }
    enum gender: %i[male female others]

    # methods
    def display_name
      "#{first_name} #{last_name}"
    end

    def update_count
      if self.role_id == 2
        errors.add(:farmer_update_count, ': Cant be update more than twice') if self.farmer_update_count > 2 
      end
    end

    private

    def parse_full_phone_number
      phone = Phonelib.parse(full_phone_number)
      # self.full_phone_number = phone.sanitized
      self.country_code      = phone.country_code
      self.phone_number      = phone.raw_national
    end

    def valid_phone_number
      errors.add(:full_phone_number, 'Please prefix +91 and give 10 digits for Phone Number"') unless Phonelib.valid?(full_phone_number)
    end

    def generate_api_key
      loop do
        @token = SecureRandom.base64.tr('+/=', 'Qrt')
        break @token unless Account.exists?(unique_auth_id: @token)
      end
      self.unique_auth_id = @token
    end

    def set_black_listed_user
      if is_blacklisted_previously_changed?
        if is_blacklisted
          AccountBlock::BlackListUser.create(account_id: id)
        else
          blacklist_user.destroy
        end
      end
    end

    def random_password_generate
      self.password_digest = SecureRandom.hex(4)
    end

    def fe_role?
      self.role_id == 1
    end
  end
end
