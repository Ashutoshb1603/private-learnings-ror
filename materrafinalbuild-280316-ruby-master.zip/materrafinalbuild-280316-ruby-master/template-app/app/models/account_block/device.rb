module AccountBlock
  class Device < ApplicationRecord
    self.table_name = :devices
    belongs_to :account, class_name: 'AccountBlock::Account', optional: true
    belongs_to :admin_user, class_name: 'AdminUser', optional: true

    validates :token, uniqueness: { scope: [:account_id, :admin_user_id] }, allow_nil: true

  end
end
