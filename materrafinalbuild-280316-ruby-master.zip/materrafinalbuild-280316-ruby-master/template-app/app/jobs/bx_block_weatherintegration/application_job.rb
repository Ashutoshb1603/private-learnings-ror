module BxBlockWeatherintegration
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
