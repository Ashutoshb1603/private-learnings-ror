module BxBlockAttachment
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
