module BxBlockVideoManagement
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
