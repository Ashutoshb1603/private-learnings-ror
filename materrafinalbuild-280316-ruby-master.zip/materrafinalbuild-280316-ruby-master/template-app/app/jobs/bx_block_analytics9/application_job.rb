module BxBlockAnalytics9
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
