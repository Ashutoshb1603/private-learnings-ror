module BxBlockCfdbsetup
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
