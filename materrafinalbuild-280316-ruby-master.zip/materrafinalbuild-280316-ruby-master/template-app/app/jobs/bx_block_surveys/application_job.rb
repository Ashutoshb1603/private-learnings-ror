module BxBlockSurveys
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
