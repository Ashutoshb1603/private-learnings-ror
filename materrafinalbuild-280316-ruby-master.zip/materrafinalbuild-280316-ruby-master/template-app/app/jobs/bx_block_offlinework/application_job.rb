module BxBlockOfflinework
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
