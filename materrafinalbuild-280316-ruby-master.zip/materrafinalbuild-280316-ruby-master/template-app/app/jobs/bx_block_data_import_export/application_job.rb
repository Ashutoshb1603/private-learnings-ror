module BxBlockDataImportExport
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
