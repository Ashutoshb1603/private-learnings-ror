module BxBlockMapsettings
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
