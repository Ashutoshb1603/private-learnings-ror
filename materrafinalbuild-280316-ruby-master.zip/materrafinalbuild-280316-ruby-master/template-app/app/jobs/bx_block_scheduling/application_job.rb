module BxBlockScheduling
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
