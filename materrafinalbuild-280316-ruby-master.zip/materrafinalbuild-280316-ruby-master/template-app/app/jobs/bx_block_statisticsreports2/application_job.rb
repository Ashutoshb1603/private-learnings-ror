module BxBlockStatisticsreports2
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
