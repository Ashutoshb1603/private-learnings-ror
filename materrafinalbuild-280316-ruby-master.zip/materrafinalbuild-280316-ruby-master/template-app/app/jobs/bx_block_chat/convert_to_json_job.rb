module BxBlockChat
  class ConvertToJsonJob < ApplicationJob
    queue_as :default
    MESSAGES = 100

    def perform
      BxBlockChat::Chat.find_each do |chat|
        last_msg = BxBlockChat::ChatMessage.where(chat_id: chat).select(:id).last(MESSAGES)
        messages = ::BxBlockChat::ChatMessage.where(chat_id: chat.id).where.not(id: last_msg)

        if messages.present?
          name = "#{Time.now.to_date}chat_id-#{chat.id}"
          file_name = "tmp/#{name}.json"
          File.write(file_name, to_json(chat, messages))
          file = File.new(file_name)
          chat.json_message_histories.create!(json_file: file, name: name)
          File.delete(file_name)
          messages.delete_all
        end
      end
    end

    def to_json(chat, messages)
      message_hash = ::BxBlockChat::ChatSerializer.new(chat, {params: { messages: messages }}).serializable_hash
    end
  end
end
