module BxBlockPosts
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
