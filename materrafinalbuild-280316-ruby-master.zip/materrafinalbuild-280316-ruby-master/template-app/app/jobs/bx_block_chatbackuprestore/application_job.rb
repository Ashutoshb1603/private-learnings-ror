module BxBlockChatbackuprestore
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
