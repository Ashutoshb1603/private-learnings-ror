module BxBlockRequestManagement
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
