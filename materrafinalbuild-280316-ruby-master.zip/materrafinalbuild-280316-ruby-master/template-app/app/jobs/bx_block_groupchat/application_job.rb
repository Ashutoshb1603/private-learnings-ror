module BxBlockGroupchat
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
