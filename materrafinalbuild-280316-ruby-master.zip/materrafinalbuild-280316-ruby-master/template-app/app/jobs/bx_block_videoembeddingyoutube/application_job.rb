module BxBlockVideoembeddingyoutube
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
