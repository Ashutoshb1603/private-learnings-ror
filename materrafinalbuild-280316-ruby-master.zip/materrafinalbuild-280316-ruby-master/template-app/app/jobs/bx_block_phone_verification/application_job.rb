module BxBlockPhoneVerification
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
