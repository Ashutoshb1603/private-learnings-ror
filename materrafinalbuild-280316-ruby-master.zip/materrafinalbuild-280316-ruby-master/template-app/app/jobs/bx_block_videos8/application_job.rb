module BxBlockVideos8
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
