module AccountBlock
  class PushNotificationJob < ApplicationJob

    queue_as :default

    def perform
      farmer_profile_update() rescue nil
      fe_profile_update() rescue nil
      farmer_profile_image() rescue nil
      fe_profile_image() rescue nil
      farmer_farm_image_attach() rescue nil
      fe_farm_image_attach() rescue nil
      fe_upload_farm_boundary_notification() rescue nil
      farmer_upload_farm_mapping_image() rescue nil
    end
      
    # # Farmer: Complete profile details
    def farmer_profile_update
      accounts = AccountBlock::Account.where(role_id: 2).where(aadhaar_number: nil).or(AccountBlock::Account.where(middle_name: nil).or(AccountBlock::Account.where(taluka_id: nil)))
      user_ids = accounts.pluck(:id)
      BxBlockPushNotifications::Providers::UserProfileFcm.send_push_notification(title: "alert notification", message: "Please complete your profile details", user_ids: user_ids, type: "farmer_complete_profile_details")
    end

    # # Field Executive:  Farmer need to complete there profile
    def fe_profile_update
      accounts = AccountBlock::Account.where(role_id: 2).where(aadhaar_number: nil).or(AccountBlock::Account.where(middle_name: nil).or(AccountBlock::Account.where(taluka_id: nil)))
      accounts.map do |account|
        user_taluka = account&.taluka
        if user_taluka.present?
            field_executive = AccountBlock::Account.where(role_id: 1, taluka_id: user_taluka.id)
            field_executive_ids = field_executive.pluck(:id)
            BxBlockPushNotifications::Providers::UserProfileFcm.send_push_notification(title: "notification", message: "[#{user.first_name}, #{user.village.name}] needs to complete there profile", user_ids: field_executive_ids, type: "fe_complete_profile_details")
        end
      end
    end

    # # Farmer:  Please upload your picture
    def farmer_profile_image
      accounts = AccountBlock::Account.where(role_id: 2).left_joins(:avatar_attachment).group(:id).having("COUNT(active_storage_attachments) = 0")
      accounts.map do |account|
        if ((Date.today - account.updated_at.to_date).to_i) % 7 == 0
          BxBlockPushNotifications::Providers::UserProfileFcm.send_push_notification(title: "notification", message: "Please upload your picture", user_ids: [account.id], type: "farmer_upload_profile_picture")
        end
      end
    end

    # # Field Executive: Farmer need to upload there profile photo
    def fe_profile_image
      accounts = AccountBlock::Account.where(role_id: 2).left_joins(:avatar_attachment).group(:id).having("COUNT(active_storage_attachments) = 0")
      accounts.map do |account|
        user_taluka = account&.taluka
        if ((Date.today - account.updated_at.to_date).to_i) % 7 != 0
          if user_taluka.present?
            field_executive = AccountBlock::Account.where(role_id: 1, taluka_id: user_taluka.id)
            field_executive_ids = field_executive.pluck(:id)
            BxBlockPushNotifications::Providers::UserProfileFcm.send_push_notification(title: "notification", message: "[#{account.first_name}, #{account.village.name}] needs to upload there profile picture", user_ids: field_executive_ids, type: "fe_upload_profile_picture")
          end
        end
      end
    end


    # # Farmer: upload farm image photo 
    def farmer_farm_image_attach
      land_details = BxBlockProfileBio::LandDetail.left_joins(:farm_image_attachment).group(:id).having("COUNT(active_storage_attachments) = 0")
      user_ids = land_details.pluck(:account_id)
      BxBlockPushNotifications::Providers::UserProfileFcm.send_push_notification(title: "notification", message: "Please upload your farm photo", user_ids: user_ids, type: "farmer_upload_farm_photo")
    end

    # Field Executive: Farmer need to upload farm photo 
    def fe_farm_image_attach
      land_details = BxBlockProfileBio::LandDetail.left_joins(:farm_image_attachment).group(:id).having("COUNT(active_storage_attachments) = 0")
      user_ids = land_details.pluck(:account_id)
      user_ids.map do |user_id|
        user = AccountBlock::Account.find_by(id: user_id)
        user_taluka = user&.taluka
        if user_taluka.present?
          field_executive = AccountBlock::Account.where(role_id: 1, taluka_id: user_taluka.id)
          field_executive_ids = field_executive.pluck(:id)
          BxBlockPushNotifications::Providers::UserProfileFcm.send_push_notification(title: "notification", message: "[#{user.first_name}, #{user.village.name}] needs to upload a photo of there farm", user_ids: field_executive_ids, type: "fe_upload_farm_photo")
        end
      end
    end

    # Farmer: draw farm mapping boundary 
    def self.farmer_upload_farm_mapping_image
      land_details = BxBlockProfileBio::LandDetail.left_joins(:farm_mapping_image_attachment).group(:id).having("COUNT(active_storage_attachments) = 0")
      user_ids = land_details.pluck(:account_id)
      user_ids.map do |user_id|
        user = AccountBlock::Account.find_by(id: user_id)
        if  ((Date.today - user.updated_at.to_date).to_i) >= 15
          BxBlockPushNotifications::Providers::UserProfileFcm.send_push_notification(title: "notification", message: "Please draw your farm boundary", user_ids: user.id, type: "farmer_draw_farm_mapping_boundary")
        end
      end
    end

    # Field executive: farmer need to upload there farm boundary
    def fe_upload_farm_boundary_notification
      land_details = BxBlockProfileBio::LandDetail.left_joins(:farm_mapping_image_attachment).group(:id).having("COUNT(active_storage_attachments) = 0")
      user_ids = land_details.pluck(:account_id)
      user_ids.map do |user_id|
        user = AccountBlock::Account.find_by(id: user_id)
        user_taluka = user&.taluka
        if user_taluka.present?
          if ((Date.today - user.updated_at.to_date).to_i) >= 15
            field_executive = AccountBlock::Account.where(role_id: 1, taluka_id: user_taluka.id)
            field_executive_ids = field_executive.pluck(:id)
            BxBlockPushNotifications::Providers::UserProfileFcm.send_push_notification(title: "notification", message: "[#{user.first_name}, #{user.village.name}] needs to upload draw there farm boundaries", user_ids: field_executive_ids, type: "fe_draw_farm_mapping_boundary")
          end
        end
      end
    end
  end
end
