module BxBlockNotifsettings
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
