module BxBlockLivechat2
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
