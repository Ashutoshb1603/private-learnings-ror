module BxBlockLanguagesupport
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
