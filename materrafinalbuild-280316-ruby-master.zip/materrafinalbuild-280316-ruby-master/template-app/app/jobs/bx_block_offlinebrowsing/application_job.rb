module BxBlockOfflinebrowsing
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
