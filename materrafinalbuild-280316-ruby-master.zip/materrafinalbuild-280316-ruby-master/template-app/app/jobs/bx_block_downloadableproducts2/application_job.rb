module BxBlockDownloadableproducts2
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
