module BxBlockBudgetingforecasting
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
