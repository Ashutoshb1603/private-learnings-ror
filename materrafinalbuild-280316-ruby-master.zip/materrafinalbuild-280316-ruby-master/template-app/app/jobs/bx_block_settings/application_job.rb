module BxBlockSettings
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
