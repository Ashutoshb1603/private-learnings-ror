module BxBlockAssessmenttest
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
