module AdminNotifications
  class Load
    @@loaded_from_gem = false
    def self.is_loaded_from_gem
      @@loaded_from_gem
    end

    #function is intentionally empty and will be implemented later
    def self.loaded
      #function is intentionally empty and will be implemented later
    end

    # Check if this file is loaded from gem directory or not
    # The gem directory looks like
    # /template-app/.gems/gems/bx_block_custom_user_subs-0.0.7/app/admin/subscription.rb
    # if it has block's name in it then it's a gem
    @@loaded_from_gem = Load.method('loaded').source_location.first.include?('bx_block_')
  end
end

unless AdminNotifications::Load.is_loaded_from_gem
  ActiveAdmin.register BxBlockAdminNotification::AdminNotification, as: 'Notification' do
    menu false
    # menu parent: 'Notification'
    permit_params :notification_type_id, :send_to, language_notifications_attributes: [:id, :language, :title, :image, :description, :_destroy]

    index do
      selectable_column
      id_column
      column :notification_type
      column :send_to
      actions
    end

    filter :name

    show do
      attributes_table do
        row :notification_type
        row :send_to
      end
      active_admin_comments
    end

    form do |f|
      f.inputs do
        f.semantic_errors(*f.object.errors.keys)
        f.input :notification_type_id, as: :select, collection: BxBlockAdminNotification::NotificationType.all.map{|f| [f.name.humanize, f.id]}
        f.input :send_to, as: :select, collection: [AccountBlock::Account.all,BxBlockChat::Chat.all].flatten.map{|a| (a["first_name"] || a["name"])}, input_html: { class: "multi-select2", multiple: false }
      end
      f.inputs "Language Notifications" do
        f.object.language_notifications.build(language: 0) unless f.object.language_notifications.map(&:language).include?('English') 
        f.object.language_notifications.build(language: 1) unless f.object.language_notifications.map(&:language).include?('Hindi')
        f.object.language_notifications.build(language: 2) unless f.object.language_notifications.map(&:language).include?('Gujrati')

        f.fields_for :language_notifications, heading: false, allow_destroy: false, new_record: false do |cd|
          cd.semantic_errors *cd.object.errors.keys
          cd.input :language, :input_html => { :value => cd.object&.language, readonly: true}
          cd.input :title
          cd.input :image, as: :file, input_html: { multiple: false } 
          cd.input :description
        end
      end
      f.actions
    end
  end
end
