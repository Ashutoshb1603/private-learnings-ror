# frozen_string_literal: true

ActiveAdmin.register BxBlockProfileBio::TypeIrrigation, as: 'Type Of Irrigation' do
  menu parent: 'Land Dropdown'
  permit_params :label, :label_hindi, :label_gujrati, :active

  index do
    selectable_column
    id_column
    column :label
    column :label_hindi
    column :label_gujrati
    column :active
    actions
  end

  filter :label, as: :select, collection: BxBlockProfileBio::TypeIrrigation.all.pluck(:label)

  form do |f|
    f.inputs do
      f.semantic_errors(*f.object.errors.keys)
      f.input :label
      f.input :label_hindi
      f.input :label_gujrati
      f.input :active
    end
    f.actions
  end
end
