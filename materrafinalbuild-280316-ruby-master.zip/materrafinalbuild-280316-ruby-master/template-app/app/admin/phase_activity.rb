ActiveAdmin.register BxBlockCalendar::PhaseActivity, as: 'PhaseActivity' do
  # menu false
  menu parent: 'Crop Calender', label: 'Phase Activity'
  permit_params :name, :name_hindi, :name_gujarati, phase_sub_activities_attributes: [:name, :name_hindi, :name_gujarati]

  filter :name, filters: [:starts_with, :ends_with, :equals_to, :contains]

  collection_action :sub_activity do
    key = "name_#{params[:language].downcase}"
    sub_activities = BxBlockCalendar::PhaseSubActivity.where(phase_activity_id: params[:activity_id])
    data = view_context.options_from_collection_for_select(sub_activities, :id, key)
    render json: data
  end

  form do |f|
    f.inputs do
      f.input :name
      f.input :name_hindi
      f.input :name_gujarati
    end
 
      f.inputs "Sub Activities" do
        f.has_many :phase_sub_activities, heading: false, allow_destroy: true do |cd|
          cd.semantic_errors *cd.object.errors.keys
          cd.input :name
          cd.input :name_hindi
          cd.input :name_gujarati
        end
      end
    f.actions
  end

  show do |account|
    attributes_table do
      row :name
      row :name_hindi
      row :name_gujarati
      panel 'Phase Sub Activities' do 
        table_for  account.phase_sub_activities do |t|
          column :name do |object|
            object.name
          end
          column :name_hindi do |object|
            object.name_hindi
          end
          column :name_gujarati do |object|
            object.name_gujarati
          end
        end
      end
    end
  end
end