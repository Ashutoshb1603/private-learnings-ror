# frozen_string_literal: true

ActiveAdmin.register BxBlockWorkshop::News, as: 'News' do
  menu false
  # menu parent: 'News & Events'
  permit_params :title, :title_hindi, :title_gujrati, :description, :description_hindi, :description_gujrati,
                :written_by, :written_by_hindi, :written_by_gujrati, :image

  index do
    selectable_column
    id_column
    column :title
    column :title_hindi
    column :title_gujrati
    column :description
    column :description_hindi
    column :description_gujrati
    column :written_by
    column :written_by_hindi
    column :written_by_gujrati
    column :image do |object|
      object.image.present? ? image_tag(object.image, style: 'width: 40px') : nil
    end
    actions
  end
  show do
    attributes_table do
      row :title
      row :title_hindi
      row :title_gujrati
      row :description
      row :description_hindi
      row :description_gujrati
      row :written_by
      row :written_by_hindi
      row :written_by_gujrati
      row :image do |object|
        object.image.present? ? image_tag(object.image, style: 'width: 40px') : nil
      end
    end
    active_admin_comments
  end

  form do |f|
    f.inputs do
      f.semantic_errors(*f.object.errors.keys)
      f.input :title
      f.input :title_hindi
      f.input :title_gujrati
      f.input :description
      f.input :description_hindi
      f.input :description_gujrati
      f.input :written_by
      f.input :written_by_hindi
      f.input :written_by_gujrati
      f.input :image, as: :file
    end
    f.actions
  end
end
