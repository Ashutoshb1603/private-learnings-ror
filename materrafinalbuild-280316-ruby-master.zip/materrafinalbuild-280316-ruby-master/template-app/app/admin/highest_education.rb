module HighestEducations
  class Load
    @@loaded_from_gem = false
    def self.is_loaded_from_gem
      @@loaded_from_gem
    end

    #function is intentionally empty and will be implemented later
    def self.loaded
      #function is intentionally empty and will be implemented later
    end

    # Check if this file is loaded from gem directory or not
    # The gem directory looks like
    # /template-app/.gems/gems/bx_block_custom_user_subs-0.0.7/app/admin/subscription.rb
    # if it has block's name in it then it's a gem
    @@loaded_from_gem = Load.method('loaded').source_location.first.include?('bx_block_')
  end
end

unless HighestEducations::Load.is_loaded_from_gem
  ActiveAdmin.register BxBlockUserProfile::HighestEducation, as: 'Highest Education' do
    menu parent: 'User Profile Dropdown', label: 'Highest Education'
    permit_params :name, :name_hindi, :name_gujrati, :active

    index do
      selectable_column
      id_column
      column :name
      column :name_hindi
      column :name_gujrati
      column :active
      actions
    end

    filter :name, filters: [:starts_with, :ends_with, :equals_to, :contains]
    filter :name_hindi, filters: [:starts_with, :ends_with, :equals_to, :contains]
    filter :name_gujrati, filters: [:starts_with, :ends_with, :equals_to, :contains]
    filter :active, filters: [:starts_with, :ends_with, :equals_to, :contains]

    show do
      attributes_table do
        row :name
        row :name_hindi
        row :name_gujrati
        row :active
      end
      active_admin_comments
    end

    form do |f|
      f.inputs do
        f.semantic_errors(*f.object.errors.keys)
        f.input :name
        f.input :name_hindi
        f.input :name_gujrati
        f.input :active
      end
      f.actions
    end
  end
end
