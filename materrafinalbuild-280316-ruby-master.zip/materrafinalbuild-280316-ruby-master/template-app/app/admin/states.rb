module States
  class Load
    @@loaded_from_gem = false
    def self.is_loaded_from_gem
      @@loaded_from_gem
    end

    #function is intentionally empty and will be implemented later
    def self.loaded
      #function is intentionally empty and will be implemented later
    end

    # Check if this file is loaded from gem directory or not
    # The gem directory looks like
    # /template-app/.gems/gems/bx_block_custom_user_subs-0.0.7/app/admin/subscription.rb
    # if it has block's name in it then it's a gem
    @@loaded_from_gem = Load.method('loaded').source_location.first.include?('bx_block_')
  end
end

unless States::Load.is_loaded_from_gem
  ActiveAdmin.register BxBlockLocationDetails::State, as: 'State' do
    menu parent: 'User Profile Dropdown', label: 'State'
    permit_params :name, :name_hindi, :name_gujrati

    index do
      selectable_column
      id_column
      column :name
      column :name_hindi
      column :name_gujrati
      actions
    end

    filter :name, filters: [:starts_with, :ends_with, :equals_to, :contains]

    show do
      attributes_table do
        row :name
        row :name_hindi
        row :name_gujrati
      end
      active_admin_comments
    end

    form do |f|
      f.inputs do
        f.semantic_errors(*f.object.errors.keys)
        f.input :name
        f.input :name_hindi
        f.input :name_gujrati
      end
      f.actions
    end
  end
end
