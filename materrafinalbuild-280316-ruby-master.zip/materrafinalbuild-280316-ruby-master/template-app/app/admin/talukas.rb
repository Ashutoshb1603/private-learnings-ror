module Talukas
  class Load
    @@loaded_from_gem = false
    def self.is_loaded_from_gem
      @@loaded_from_gem
    end
    
    #function is intentionally empty and will be implemented later
    def self.loaded
      #function is intentionally empty and will be implemented later
    end

    # Check if this file is loaded from gem directory or not
    # The gem directory looks like
    # /template-app/.gems/gems/bx_block_custom_user_subs-0.0.7/app/admin/subscription.rb
    # if it has block's name in it then it's a gem
    @@loaded_from_gem = Load.method('loaded').source_location.first.include?('bx_block_')
  end
end

unless Talukas::Load.is_loaded_from_gem
  ActiveAdmin.register BxBlockLocationDetails::Taluka, as: 'Taluka' do
    controller do
      def index
        if params[:json]
          talukas = BxBlockLocationDetails::Taluka.where(district_id: params[:district_id])

          data = view_context.options_from_collection_for_select(talukas, :id, :name)
          data = "<option value=\"\"></option>\n#{data}"
          render json: data
        else
          super()
        end
      end
    end
    menu parent: 'User Profile Dropdown', label: 'Taluka'
    permit_params :name, :name_hindi, :name_gujrati, :district_id

    index do
      selectable_column
      id_column
      column :name
      column :name_hindi
      column :name_gujrati
      column :district_id
      actions
    end

    filter :name, filters: [:ends_with, :equals_to, :starts_with, :contains]
    filter :name_hindi, filters: [:starts_with, :contains, :ends_with, :equals_to]
    filter :name_gujrati, filters: [ :equals_to, :contains, :starts_with, :ends_with]

    show do
      attributes_table do
        row :name
        row :name_hindi
        row :name_gujrati
        row :district_id
      end
      active_admin_comments
    end

    form do |f|
      f.inputs do
        f.semantic_errors(*f.object.errors.keys)
        f.input :state_value, as: :select, collection: BxBlockLocationDetails::State.all, input_html: { class: 'state_value' }, include_blank: true
        f.input :district_id, as: :select, collection: BxBlockLocationDetails::Taluka.where(district_id: f.object&.district_id).map{|tal| [tal.name, tal.id]}, selected: f.object&.district_id, include_blank: true
        f.input :name
        f.input :name_hindi
        f.input :name_gujrati
      end
      f.actions
    end
  end
end
