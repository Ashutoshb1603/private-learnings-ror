# frozen_string_literal: true

module BxBlockSettings
  class TermAndCondition
    @@loaded_from_gem = false
    def self.is_loaded_from_gem
      @@loaded_from_gem
    end

    #function is intentionally empty and will be implemented later
    def self.loaded
      #function is intentionally empty and will be implemented later
    end

    # Check if this file is loaded from gem directory or not
    # The gem directory looks like
    # /template-app/.gems/gems/bx_block_custom_user_subs-0.0.7/app/admin/subscription.rb
    # if it has block's name in it then it's a gem
    # @@loaded_from_gem = Load.method('loaded').source_location.first.include?('bx_block_')
  end
end

unless BxBlockSettings::TermAndCondition.is_loaded_from_gem
  ActiveAdmin.register BxBlockSettings::TermAndCondition, as: 'Terms And Condition' do
    menu label: 'Terms And Conditions'
    menu parent: "Settings"

    permit_params :description, :description_hindi, :description_gujrati
    actions :all, :except => [:destroy]
    index :title => "Terms And Conditions" do
      selectable_column
      id_column
      column :description do |object|
        raw object.description
      end
      column :description_hindi do |object|
        raw object.description_hindi
      end
      column :description_gujrati do |object|
        raw object.description_gujrati
      end
      column :created_at
      column :updated_at
      actions 
    end

    config.remove_action_item :new
    config.remove_action_item :edit
    config.remove_action_item :destroy


    # action_item :new, only: :index do
    #   link_to 'New Terms And Conditions', new_admin_term_and_condition_path
    # end 

    # action_item :edit, only: :show do
    #   link_to 'Edit Terms And Conditions', edit_admin_term_and_condition_path
    # end 

    show :title => "Terms And Conditions" do
      attributes_table :title => "Terms And Conditions" do
        row :description do |object|
          raw object.description
        end
        row :description_hindi do |object|
          raw object.description_hindi
        end
        row :description_gujrati do |object|
          raw object.description_gujrati
        end
        row :created_at
        row :updated_at
      end
      active_admin_comments
    end

    filter :description, filters: [:starts_with, :ends_with, :equals_to, :contains]
    filter :description_hindi, filters: [:starts_with, :ends_with, :equals_to, :contains]
    filter :description_gujrati, filters: [:starts_with, :ends_with, :equals_to, :contains]
    filter :created_at
    filter :updated_at

    form :title => "Terms And Conditions" do |f|
      f.inputs do
        f.input :description, as: :quill_editor
        f.input :description_hindi, as: :quill_editor
        f.input :description_gujrati, as: :quill_editor
      end
      f.actions do
        f.action :submit, as: :button, label: 'Submit Terms And Conditions'
        f.action :cancel, :wrapper_html => { :class => 'cancel '}, label: 'Cancel'
      end
    end
  end
end
