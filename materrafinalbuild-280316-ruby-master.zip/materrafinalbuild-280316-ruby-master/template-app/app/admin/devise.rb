module Devices
  class Load
    @@loaded_from_gem = false
    def self.is_loaded_from_gem
      @@loaded_from_gem
    end

    #function is intentionally empty and will be implemented later
    def self.loaded
      #function is intentionally empty and will be implemented later
    end

    # Check if this file is loaded from gem directory or not
    # The gem directory looks like
    # /template-app/.gems/gems/bx_block_custom_user_subs-0.0.7/app/admin/subscription.rb
    # if it has block's name in it then it's a gem
    @@loaded_from_gem = Load.method('loaded').source_location.first.include?('bx_block_')
  end
end

unless Devices::Load.is_loaded_from_gem
  ActiveAdmin.register AccountBlock::Device, as: 'Device Token' do
    menu false
    permit_params :token, :platform, :account_id

    index do
      selectable_column
      id_column
      column :token
      column :platform
      column :account_id
      column :created_at
      column :updated_at
      actions
    end

    filter :account_id

    show do
      attributes_table do
        row :token
        row :platform
        row :account_id
        row :created_at
        row :updated_at
      end
      active_admin_comments
    end

    form do |f|
      f.inputs do
        f.semantic_errors(*f.object.errors.keys)
        f.input :token
        f.input :platform
        f.input :account_id
      end
      f.actions
    end
  end
end
