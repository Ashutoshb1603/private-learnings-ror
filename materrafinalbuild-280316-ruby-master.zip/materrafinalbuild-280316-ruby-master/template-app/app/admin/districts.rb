# frozen_string_literal: true

module Districts
  class Load
    @@loaded_from_gem = false
    def self.is_loaded_from_gem
      @@loaded_from_gem
    end

    #function is intentionally empty and will be implemented later
    def self.loaded
      #function is intentionally empty and will be implemented later
    end

    # Check if this file is loaded from gem directory or not
    # The gem directory looks like
    # /template-app/.gems/gems/bx_block_custom_user_subs-0.0.7/app/admin/subscription.rb
    # if it has block's name in it then it's a gem
    @@loaded_from_gem = Load.method('loaded').source_location.first.include?('bx_block_')
  end
end

unless Districts::Load.is_loaded_from_gem
  ActiveAdmin.register BxBlockLocationDetails::District, as: 'District' do
    controller do
      def index
        if params[:json]
          districts = BxBlockLocationDetails::District.where(state_id: params[:state_id])
          data = view_context.options_from_collection_for_select(districts, :id, :name)
          data = "<option value=\"\"></option>\n#{data}"
          render json: data
        else
          super()
        end
      end

      protected

      def current_ability
        # Match to your current admin user
        @current_ability ||= Ability.new(current_admin_user)
      end
    end

    menu parent: 'User Profile Dropdown', label: 'District'
    permit_params :name, :name_hindi, :name_gujrati, :state_id

    index do
      selectable_column
      id_column
      column :name
      column :name_hindi
      column :name_gujrati
      column :state_id
      actions
    end

    filter :name, filters: [:starts_with, :ends_with, :equals_to, :contains]

    show do
      attributes_table do
        row :name
        row :name_hindi
        row :name_gujrati
        row :state_id
      end
      active_admin_comments
    end

    form do |f|
      f.inputs do
        f.semantic_errors(*f.object.errors.keys)
        f.input :state_id, as: :select, collection: BxBlockLocationDetails::State.all
        f.input :name
        f.input :name_hindi
        f.input :name_gujrati
      end
      f.actions
    end
  end
end
