module Harvests
  class Load
    @@loaded_from_gem = false
    def self.is_loaded_from_gem
      @@loaded_from_gem
    end
    
    #function is intentionally empty and will be implemented later
    def self.loaded
      #function is intentionally empty and will be implemented later
    end

    # Check if this file is loaded from gem directory or not
    # The gem directory looks like
    # /template-app/.gems/gems/bx_block_custom_user_subs-0.0.7/app/admin/subscription.rb
    # if it has block's name in it then it's a gem
    @@loaded_from_gem = Load.method('loaded').source_location.first.include?('bx_block_')
  end
end

unless Harvests::Load.is_loaded_from_gem
  ActiveAdmin.register BxBlockFarmDairy::Harvest, as: 'Harvest' do
    menu false unless ENV['STAGE'] == "dev"
    menu parent: 'Farm Dairy Activities', label: 'Harvest'
    permit_params :date_of_picking, :quantity_picked, :total_picking_cost, :storage_type_id, :land_detail_id, :account_id, :crop_season_id, :crop_start_year, :crop_end_year

    form do |f|
      f.inputs do
        f.semantic_errors(*f.object.errors.keys)
        f.input :crop_season_id, as: :select, collection: BxBlockFarmDairy::CropSeason.all, include_blank: false
        f.input :crop_start_year, as: :select, collection: (Date.today.year - 1)..(Date.today.year + 20), include_blank: false
        f.input :crop_end_year, as: :select, collection: (Date.today.year - 1)..(Date.today.year + 20), include_blank: false
        f.input :date_of_picking
        f.input :quantity_picked
        f.input :total_picking_cost
        f.input :storage_type_id, as: :select, collection: BxBlockFarmDairy::StorageType.all, include_blank: false
        f.input :land_detail_id
        f.input :account_id
      end
      f.actions
    end
  end
end

