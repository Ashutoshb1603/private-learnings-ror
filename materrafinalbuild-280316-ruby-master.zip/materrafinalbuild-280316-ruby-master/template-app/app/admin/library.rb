# frozen_string_literal: true

ActiveAdmin.register BxBlockMaterraPedia::Library, as: 'Library' do
  menu false
  # menu parent: "MaterraPedia"
  permit_params :topic, :topic_hindi, :topic_gujrati, :description, :description_hindi, :description_gujrati, :video

  index do
    selectable_column
    id_column
    column :topic
    column :video do |object|
      video_tag url_for(object.video), style: 'width:100%;height:auto', controls: true if object.video.attached?
    end
    column :description

    column :topic_hindi
    column :video do |object|
      video_tag url_for(object.video), style: 'width:100%;height:auto', controls: true if object.video.attached?
    end
    column :description_hindi

    column :topic_gujrati
    column :video do |object|
      video_tag url_for(object.video), style: 'width:100%;height:auto', controls: true if object.video.attached?
    end
    column :description_gujrati
    actions
  end

  form do |f|
    f.inputs do
      f.input :topic
      f.input :video, as: :file
      f.input :description
      f.input :topic_hindi
      f.input :video, as: :file
      f.input :description_hindi
      f.input :topic_gujrati
      f.input :video, as: :file
      f.input :description_gujrati
    end
    f.actions
  end
end
