# frozen_string_literal: true

ActiveAdmin.register BxBlockMaterraPedia::Faq, as: 'FAQ' do
  # remove menu false and uncomment the menu parent
  menu false
  # menu parent: 'MaterraPedia'
  permit_params :topic, :topic_hindi, :topic_gujrati, :question, :question_hindi, :question_gujrati, :description,
                :description_hindi, :description_gujrati, :category_id, :video, :video_hindi, :video_gujrati

  index do
    selectable_column
    id_column
    column :topic
    column :question
    column :video do |object|
      video_tag url_for(object.video), style: 'width:100%;height:auto', controls: true if object.video.attached?
    end
    column :description

    column :topic_hindi
    column :question_hindi
    column :video_hindi do |object|
      if object.video_hindi.attached?
        video_tag url_for(object.video_hindi), style: 'width:100%;height:auto',
                                               controls: true
      end
    end

    column :description_hindi

    column :topic_gujrati
    column :question_gujrati
    column :video_gujrati do |object|
      if object.video_gujrati.attached?
        video_tag url_for(object.video_gujrati), style: 'width:100%;height:auto',
                                                 controls: true
      end
    end
    column :description_gujrati
    column :category_id
    actions
  end

  form do |f|
    f.inputs do
      f.input :topic
      f.input :question
      f.input :video, as: :file
      f.input :description
      f.input :topic_hindi
      f.input :question_hindi
      f.input :video_hindi, as: :file
      f.input :description_hindi
      f.input :topic_gujrati
      f.input :question_gujrati
      f.input :video_gujrati, as: :file
      f.input :description_gujrati
      f.input :category_id
    end
    f.actions
  end
end
