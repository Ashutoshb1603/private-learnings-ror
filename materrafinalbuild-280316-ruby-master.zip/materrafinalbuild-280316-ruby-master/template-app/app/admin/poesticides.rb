module Pesticides
  class Load
    @@loaded_from_gem = false
    def self.is_loaded_from_gem
      @@loaded_from_gem
    end

    #function is intentionally empty and will be implemented later
    def self.loaded
      #function is intentionally empty and will be implemented later
    end

    # Check if this file is loaded from gem directory or not
    # The gem directory looks like
    # /template-app/.gems/gems/bx_block_custom_user_subs-0.0.7/app/admin/subscription.rb
    # if it has block's name in it then it's a gem
    @@loaded_from_gem = Load.method('loaded').source_location.first.include?('bx_block_')
  end
end

unless Pesticides::Load.is_loaded_from_gem  
  ActiveAdmin.register BxBlockFarmDairy::Pesticide, as: 'Pesticide' do
    menu false unless ENV['STAGE'] == "dev"
  	menu parent: 'Farm Dairy', label: 'Pesticide'
    permit_params :name, :name_hindi, :name_gujrati

    csv do
      column :name
      column :name_hindi
      column :name_gujrati
    end

    action_item :export_csv, only: :index do
      link_to('Export CSV', '/admin/pesticides.csv')
    end

    action_item :import_csv, only: :index do
      link_to('Import CSV', '/admin/imports/new?farm_dairy=pesticides')
    end

    action_item :download_report, only: :index do
      link_to('Download CSV report', '/admin/pesticides/download_report')
    end

    collection_action :download_report, :method => :get do
      csv_headers = ["Name", "Name Hindi", "Name Gujrati"]
      rawcsv = CSV.generate do |csv|
        csv << csv_headers     
      end
      send_data(rawcsv, :type => 'text/csv charset=utf-8; header=present', :filename => "pesticide.csv") and return
    end
  end
end

