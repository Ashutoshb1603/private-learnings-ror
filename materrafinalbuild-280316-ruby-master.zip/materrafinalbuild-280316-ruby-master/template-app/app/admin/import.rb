module Import
  class Load
    @@loaded_from_gem = false
    def self.is_loaded_from_gem
      @@loaded_from_gem
    end

    #function is intentionally empty and will be implemented later
    def self.loaded
      #function is intentionally empty and will be implemented later
    end

    # Check if this file is loaded from gem directory or not
    # The gem directory looks like
    # /template-app/.gems/gems/bx_block_custom_user_subs-0.0.7/app/admin/subscription.rb
    # if it has block's name in it then it's a gem
    @@loaded_from_gem = Load.method('loaded').source_location.first.include?('bx_block_')
  end
end

unless Import::Load.is_loaded_from_gem
  ActiveAdmin.register BxBlockImport::Import, as: 'Import'do
    Import::ADMIN_IMPORTS_NEW_PATH = "/admin/imports/new".freeze
    menu parent: "User Profile Dropdown", label: 'Location Import/Export', :url => Import::ADMIN_IMPORTS_NEW_PATH
    # actions :all, :except => [:show]
    permit_params :file, :status, :file_type

    controller do
      # def create
      #   redirect_to "/admin/#{params[:bx_block_import_import][:file_type]}" 
      # end
      def index
        redirect_to Import::ADMIN_IMPORTS_NEW_PATH
      end
      def show
        redirect_to Import::ADMIN_IMPORTS_NEW_PATH
      end
    end

    form :title => "Import/Export" do |f|
      f.inputs "File Import" do
        f.semantic_errors(*f.object.errors.keys)
        f.input :file_type, :input_html => { :value => ( params[:file] || params[:farm_dairy] || 'states') }, as: :hidden
        f.input :file, label: "File", :as => :file, input_html: {accept: '.csv'} 
      end
      f.actions do
        f.action :submit, as: :button, label: 'Add Import'
        f.action :cancel, :wrapper_html => { :class => 'cancel '}, label: 'Cancel'
      end
    end

    csv do
      column :state
      column :district
      column :taluka
      column :village
    end

    action_item :export_location_csv, only: :new do
      link_to('Export Location CSV', '/admin/imports/export_location_csv')
    end

    collection_action :export_location_csv, :method => :get do
      village_data = []
      villages  = BxBlockLocationDetails::Village.includes(taluka: :district)
      villages.each do |village|
        village_info = [village.taluka.district.state.name, village.taluka.district.state.name_hindi, village.taluka.district.state.name_gujrati, village.taluka.district.name, village.taluka.district.name_hindi, village.taluka.district.name_gujrati, village.taluka.name, village.taluka.name_hindi, village.taluka.name_gujrati, village.name, village.name_hindi, village.name_gujrati]
        village_data << village_info
      end

      csv_headers = ["State", "State Hindi", "State Gujrati", "District", "District Hindi", "District Gujrati", "Taluka", "Taluka Hindi", "Taluka Gujrati", "Village", "Village Hindi", "Village Gujrati"]
      rawcsv = CSV.generate do |csv|
        csv << csv_headers
        village_data.each do |data|
          csv << data
        end     
      end
      send_data(rawcsv, :type => 'text/csv charset=utf-8; header=present', :filename => "location.csv") and return
    end


    action_item :download_location_report, only: :new do
      link_to('Download Location Sample CSV', '/admin/imports/download_location_report?file=location+csv_report')
    end

    collection_action :download_location_report, :method => :get do
      csv_headers = ["State", "State Hindi", "State Gujrati", "District", "District Hindi", "District Gujrati", "Taluka", "Taluka Hindi", "Taluka Gujrati", "Village", "Village Hindi", "Village Gujrati"]
      rawcsv = CSV.generate do |csv|
        csv << csv_headers     
      end
      send_data(rawcsv, :type => 'text/csv charset=utf-8; header=present', :filename => "location_sample.csv") and return
    end
  end
end
