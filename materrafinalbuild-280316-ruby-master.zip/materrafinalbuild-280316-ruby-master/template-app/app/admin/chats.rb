module Chats
  class Load
    @@loaded_from_gem = false
    def self.is_loaded_from_gem
      @@loaded_from_gem
    end

    #function is intentionally empty and will be implemented later
    def self.loaded
      #function is intentionally empty and will be implemented later
    end

    # Check if this file is loaded from gem directory or not
    # The gem directory looks like
    # /template-app/.gems/gems/bx_block_custom_user_subs-0.0.7/app/admin/subscription.rb
    # if it has block's name in it then it's a gem
    @@loaded_from_gem = Load.method('loaded').source_location.first.include?('bx_block_')
  end
end

unless Chats::Load.is_loaded_from_gem
  ActiveAdmin.register BxBlockChat::Chat, as: 'User Group'do
    permit_params :logo, :name, :field_executive_id, :chat_type, farmer_ids: []

    controller do
      def index
        if params[:json]
          fe_village_id = AccountBlock::Account.where(id: params[:field_executive_id]).first.accounts_villages.pluck(:village_id)
          users = AccountBlock::Account.where(village_id: fe_village_id)

          data = view_context.options_from_collection_for_select(users, :id, :first_name)
          data = "<option value=\"\"></option>\n#{data}"
          render json: data
        else
          super()
        end
      end
    end

    index :title => "User Groups" do
      selectable_column
      id_column
      column :name
      column :accounts do |object|
        object.accounts
      end
      actions
    end

    filter :name, filters: [:starts_with, :ends_with, :equals_to, :contains]

    show :title => "User Groups" do
      attributes_table do
        row :name
        row :account_ids
        row :accounts do |object|
          object.accounts
        end
        row :logo do |object|
          object.logo.present? ? (image_tag(object.logo.url, style: "width: 40px")) : nil
        end
      end
      active_admin_comments
    end

    form :title => "User Groups" do |f|
      f.inputs do
        f.semantic_errors *f.object.errors.keys
        f.input :logo, as: :file, input_html: { multiple: false } 
        f.input :name
        f.input :chat_type, :input_html => { :value => BxBlockChat::Chat.types["multiple_user"] }, as: :hidden
        f.input :field_executive_id, label: "Field Executive", as: :select, collection: AccountBlock::Account.all.where(role_id: 1).map{|user| [user.first_name, user.id]}, input_html: { class: "multi-select2" }, allow_blank: false
        f.input :farmer_ids , label: "Farmers", as: :select, collection: AccountBlock::Account.all.where(role_id: 2).map{|user| [user.first_name, user.id]}, input_html: { class: "multi-select2", multiple: true }, allow_blank: false
      end
      f.actions do
        f.action :submit, as: :button, label: 'Create Group'
        f.action :cancel, :wrapper_html => { :class => 'cancel '}, label: 'Cancel'
      end
    end
  end
end
