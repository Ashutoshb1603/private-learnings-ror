# frozen_string_literal: true

ActiveAdmin.register BxBlockWorkshop::Upcomingworkshop, as: 'Upcoming Workshop' do
  menu false
  permit_params :name, :name_hindi, :name_gujrati, :date, :date_hindi, :date_gujrati, :location, :location_hindi,
                :location_gujrati, :image

  index do
    selectable_column
    id_column
    column :name
    column :name_hindi
    column :name_gujrati
    column :date
    column :date_hindi
    column :date_gujrati
    column :location
    column :location_hindi
    column :location_gujrati
    column :image do |object|
      object.image.present? ? image_tag(object.image, style: 'width: 40px') : nil
    end
    actions
  end

  show do
    attributes_table do
      row :name
      row :name_hindi
      row :name_gujrati
      row :date
      row :date_hindi
      row :date_gujrati
      row :location
      row :location_hindi
      row :location_gujrati
      row :image do |object|
        object.image.present? ? image_tag(object.image, style: 'width: 40px') : nil
      end
    end
    active_admin_comments
  end

  form do |f|
    f.inputs do
      f.semantic_errors(*f.object.errors.keys)
      f.input :name
      f.input :name_hindi
      f.input :name_gujrati
      f.input :date
      f.input :date_hindi
      f.input :date_gujrati
      f.input :location
      f.input :location_hindi
      f.input :location_gujrati
      f.input :image, as: :file
    end
    f.actions
  end
end
