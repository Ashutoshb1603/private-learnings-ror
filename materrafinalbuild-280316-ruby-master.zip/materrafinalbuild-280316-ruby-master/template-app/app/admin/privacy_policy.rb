# frozen_string_literal: true

module BxBlockSettings
  class PrivacyPolicy
    @@loaded_from_gem = false
    def self.is_loaded_from_gem
      @@loaded_from_gem
    end

    #function is intentionally empty and will be implemented later
    def self.loaded
      #function is intentionally empty and will be implemented later
    end

    # Check if this file is loaded from gem directory or not
    # The gem directory looks like
    # /template-app/.gems/gems/bx_block_custom_user_subs-0.0.7/app/admin/subscription.rb
    # if it has block's name in it then it's a gem
    # @@loaded_from_gem = Load.method('loaded').source_location.first.include?('bx_block_')
  end
end

unless BxBlockSettings::PrivacyPolicy.is_loaded_from_gem
  ActiveAdmin.register BxBlockSettings::PrivacyPolicy, as: 'Privacy Policy' do
    menu parent: "Settings"
    permit_params :description, :description_hindi, :description_gujrati
    actions :all, :except => [:create, :new, :destroy]
    index do
      selectable_column
      id_column
      column :description do |object|
        raw object.description
      end
      column :description_hindi do |object|
        raw object.description_hindi
      end
      column :description_gujrati do |object|
        raw object.description_gujrati
      end
      column :created_at
      column :updated_at
      actions
    end

    filter :description, filters: [:starts_with, :ends_with, :equals_to, :contains]
    filter :description_hindi, filters: [:contains, :equals_to, :starts_with, :ends_with]
    filter :description_gujrati, filters: [ :equals_to, :contains, :starts_with, :ends_with]
    filter :created_at
    filter :updated_at

    show  do
      attributes_table do
        row :description do |object|
          raw object.description
        end
        row :description_hindi do |object|
          raw object.description_hindi
        end
        row :description_gujrati do |object|
          raw object.description_gujrati
        end
        row :created_at
        row :updated_at
      end
      active_admin_comments
    end

    form do |f|
      f.inputs do
        f.input :description, as: :quill_editor
        f.input :description_hindi, as: :quill_editor
        f.input :description_gujrati, as: :quill_editor
      end
      f.actions
    end
  end
end
