module Accounts
  class Load
    @@loaded_from_gem = false
    def self.is_loaded_from_gem
      @@loaded_from_gem
    end

    #function is intentionally empty and will be implemented later
    def self.loaded
      #function is intentionally empty and will be implemented later
    end

    # Check if this file is loaded from gem directory or not
    # The gem directory looks like
    # /template-app/.gems/gems/bx_block_custom_user_subs-0.0.7/app/admin/subscription.rb
    # if it has block's name in it then it's a gem
    @@loaded_from_gem = Load.method('loaded').source_location.first.include?('bx_block_')
  end
end

unless Accounts::Load.is_loaded_from_gem

ActiveAdmin.register AccountBlock::Account, as: 'Users' do
    permit_params  :role_id, :first_name, :middle_name, :last_name, :full_phone_number, :number_belongs_to_id, :mobile_type_id, :phone_number, :aadhaar_number, :date_of_birth,              :total_family_members, :gender, :highest_education_id,
                   :village_id, :state_id, :district_id, :taluka_id, land_details_attributes: [:id, :farm_image, :farm_mapping_image, :name, :survey_number,
                   :owner, :farm_area, :farm_area_for_cotton, :horizontal_distance, :motor_horse_power, :pump_depth, 
                   :unit_farm_area, :unit_farm_area_for_cotton, :soil_texture_id, :land_type_id, :source_irrigation_id, :type_irrigation_id,
                   :distance_in, :account_id, :_destroy, :latitude_longitude ],  :village_ids => []

    index download_links: proc { authorized?(:export_csv, AccountBlock::Account) ? [:csv] : false } do
      selectable_column
      id_column
      column :role_id do |object|
        AccountBlock::Account.roles.key(object.role_id)
      end
      column "Name", sortable: "accounts.first_name" do |object|
        "#{object&.first_name} #{object&.last_name}"
      end
      column "Location" do |data|
        "#{data&.village&.name&.capitalize} #{data&.taluka&.name&.capitalize}"
      end
      column "Assigned Field Executive" do |object|
        object.role_id == 1 ? 'Field Executive' : object.village_id.present? ?  AccountBlock::Account.where(role_id: 1).joins(:accounts_villages).where('accounts_villages.village_id = ?', object.village_id).pluck(:first_name, :last_name) : nil
      end
      column :full_phone_number
      column :gender
      column :aadhaar_number
      actions
    end

    scope :all, default: true
    scope("field_executive") {|scope| scope.where(role_id: 1)}
    scope("farmer") { |scope| scope.where(role_id: 2) }

    filter :role_id, as: :select, collection: AccountBlock::Account.roles
    filter :first_name, filters: [:starts_with, :ends_with, :equals_to, :contains]
    filter :last_name, filters: [:contains, :equals_to, :starts_with, :ends_with]
    filter :state, as: :select, collection: BxBlockLocationDetails::State.all.order(:name)
    filter :district, as: :select, collection: BxBlockLocationDetails::District.all.order(:name)
    filter :taluka, as: :select, collection: BxBlockLocationDetails::Taluka.all.order(:name)
    filter :village, as: :select, collection: BxBlockLocationDetails::Village.all.order(:name)
    filter :full_phone_number, filters: [ :equals_to, :contains, :starts_with, :ends_with]
    filter :gender, as: :select, collection: AccountBlock::Account.genders
    filter :aadhaar_number

    show  do |account|
      attributes_table do
        row :role_id do |object|
          AccountBlock::Account.roles.key(object.role_id)
        end
        row :first_name
        row :middle_name
        row :last_name
        row :number_belongs_to_id do |object|
          object.number_belongs_to&.name
        end
        row :mobile_type_id do |object|
          object.mobile_type&.name
        end
        row :full_phone_number
        row :aadhaar_number
        row :date_of_birth
        row :total_family_members
        row :gender
        row :highest_education_id do |object|
          object.highest_education&.name
        end
        row :created_at
        row :updated_at
        if account.role_id == 2
          row :state_id do |object|
            object.state&.name
          end
          row :district_id do |object|
            object.district&.name
          end
          row :taluka_id do |object|
            object.taluka&.name
          end
          row :village_id do |object|
            object.village&.name
          end
        else
          row :accounts_villages do |object|
            object.accounts_villages.map{|obj| obj.village.name}
          end
        end
        
        if account.role_id == 2
          panel 'Land Details' do 
            table_for account.land_details do |t|
              column :farm_image do |object|
                object.farm_image.present? ? (image_tag(url_for(object.farm_image), style: "width: 40px")) : nil
              end
              column :farm_mapping_image do |object|
                object.farm_mapping_image.present? ? (image_tag(url_for(object.farm_mapping_image), style: "width: 40px")) : nil
              end
              column :latitude_longitude
              column :name   
              column :survey_number 
              column :owner do |object|
                BxBlockProfileBio::LandDetail.ownership_of_lands.key(object.owner)
              end
              column :farm_area
              column :farm_area_for_cotton
              column :horizontal_distance
              column :motor_horse_power
              column :pump_depth
              column :unit_farm_area
              column :unit_farm_area_for_cotton
              column :soil_texture_id do |object|
                object&.soil_texture&.label
              end
              column :land_type_id do |object|
                object&.land_type&.label
              end
              column :source_irrigation_id do |object|
                object&.source_irrigation&.label
              end
              column :type_irrigation_id do |object|
                object&.type_irrigation&.label
              end
              column :distance_in
            end
          end
        end
      end
      active_admin_comments
    end


    form do |f|
      f.inputs "User Profile"do
        f.semantic_errors *f.object.errors.keys
        f.input :role_id, as: :select, collection: AccountBlock::Account.roles.map { |key, val| [key.humanize, val] }, include_blank: false, input_html: {class: "selected_role", disabled: f.object.id? ? true : false}
        f.input :first_name
        f.input :middle_name
        f.input :last_name
        f.input :number_belongs_to_id, as: :select, collection: BxBlockUserProfile::NumberBelongsTo.all,include_blank: false
        f.input :mobile_type_id, as: :select, collection: BxBlockUserProfile::MobileType.all, include_blank: false
        f.input :full_phone_number
        f.input :aadhaar_number
        f.input :date_of_birth, start_year: Time.now.year - 60, end_year: Time.now.year
        f.input :total_family_members
        f.input :gender, include_blank: false, include_hidden: false
        f.input :highest_education_id, as: :select, collection: BxBlockUserProfile::HighestEducation.all, include_blank: false
        f.input :state_id, as: :select, collection: BxBlockLocationDetails::State.all, name: :state_value,  input_html: {class: "account_location"}
        f.input :district_id, as: :select, collection: BxBlockLocationDetails::District.where(state_id: f.object&.state&.id),  input_html: {class: "account_location"}
        f.input :taluka_id, as: :select, collection: BxBlockLocationDetails::Taluka.where(district_id: f.object&.district&.id),  input_html: {class: "account_location"}
        f.input :village_id, as: :select, collection: BxBlockLocationDetails::Village.where(taluka_id: f.object&.taluka&.id),  input_html: {class: "account_location"}

        f.input :villages, as: :select, collection:  BxBlockLocationDetails::Village.all.map { |village| [village.name, village.id] }, input_html: { class: "multi-select2 fe_villages", multiple: true }, allow_blank: false
      end

      f.inputs "Land Details" do
        f.has_many :land_details, class: "has-one", heading: false, allow_destroy: true do |cd|
          cd.semantic_errors *cd.object.errors.keys
          cd.input :farm_image, as: :file, input_html: { multiple: false } 
          cd.input :farm_mapping_image, as: :file, input_html: { multiple: false }
          cd.input :latitude_longitude, as: :string, :input_html => { :value => cd.object&.latitude_longitude } 
          cd.input :name
          cd.input :survey_number
          cd.input :owner, as: :select, collection: BxBlockProfileBio::LandDetail.ownership_of_lands.map{|key, value| [key.humanize, value]}, include_blank: false
          cd.input :farm_area
          cd.input :farm_area_for_cotton
          cd.input :horizontal_distance
          cd.input :motor_horse_power
          cd.input :pump_depth
          cd.input :unit_farm_area
          cd.input :unit_farm_area_for_cotton
          cd.input :soil_texture_id, as: :select, required: true, collection: BxBlockProfileBio::SoilTexture.all.map{|f| [f.label.humanize, f.id]}, include_blank: false
          cd.input :land_type_id, as: :select, required: true, collection: BxBlockProfileBio::LandType.all.map{|f| [f.label.humanize, f.id]}, include_blank: false 
          cd.input :source_irrigation_id, as: :select, required: true, collection: BxBlockProfileBio::SourceIrrigation.all.map{|f|  [f.label.humanize, f.id]}, include_blank: false
          cd.input :type_irrigation_id, as: :select, required: true, collection: BxBlockProfileBio::TypeIrrigation.all.map{|f| [f.label.humanize, f.id]}, include_blank: false
          cd.input :distance_in
        end
      end
      f.actions
    end

    csv do
      column :role_id
      column :first_name
      column :middle_name
      column :last_name
      column :number_belongs_to_id
      column :mobile_type_id
      column :full_phone_number
      column :aadhaar_number
      column :date_of_birth
      column :total_family_members
      column :gender
      column :highest_education_id
      column :state_id
      column :district_id
      column :taluka_id
      column :village_id
      column(:name) do |object|
        object.land_details.map{|detail| detail.survey_number} 
      end
      column(:survey_number) do |object|
        object.land_details.map{|detail| detail.survey_number} 
      end
      column(:owner) do |object|
        object.land_details.map{|detail| detail.owner} 
      end
      column(:farm_area) do |object|
        object.land_details.map{|detail| detail.farm_area} 
      end
      column(:farm_area_for_cotton) do |object|
        object.land_details.map{|detail| detail.farm_area_for_cotton} 
      end
      column(:horizontal_distance) do |object|
        object.land_details.map{|detail| detail.horizontal_distance} 
      end
      column(:motor_horse_power) do |object|
        object.land_details.map{|detail| detail.motor_horse_power} 
      end
      column(:pump_depth) do |object|
        object.land_details.map{|detail| detail.pump_depth} 
      end
      column(:unit_farm_area) do |object|
        object.land_details.map{|detail| detail.unit_farm_area} 
      end
      column(:unit_farm_area_for_cotton) do |object|
        object.land_details.map{|detail| detail.unit_farm_area_for_cotton} 
      end
      column(:soil_texture_id) do |object|
        object.land_details.map{|detail| detail.soil_texture_id} 
      end
      column(:land_type_id) do |object|
        object.land_details.map{|detail| detail.land_type_id} 
      end
      column(:source_irrigation_id) do |object|
        object.land_details.map{|detail| detail.source_irrigation_id} 
      end
      column(:type_irrigation_id) do |object|
        object.land_details.map{|detail| detail.type_irrigation_id} 
      end
      column(:distance_in) do |object|
        object.land_details.map{|detail| detail.distance_in} 
      end
    end

    action_item :export_csv, only: :index, if: proc { authorized?(:manage, controller.instance_variable_get(:@specific_page)) } do
      link_to('Export CSV', '/admin/users.csv')
    end

    action_item :import_csv, only: :index, if: proc { authorized?(:manage, controller.instance_variable_get(:@specific_page)) } do
      link_to('Import CSV', '/admin/imports/new?file=users')
    end

    action_item :download_report, only: :index, if: proc { authorized?(:manage, controller.instance_variable_get(:@specific_page)) } do
      link_to('Download CSV format', '/admin/users/download_report')
    end

    collection_action :download_report, :method => :get do
      csv_headers = ["Role", "First name", "Middle name", "Last name", "Number belongs to", "Mobile Type","Full phone number", "Aadhaar number", "Date of birth", "Total family members", "Gender", "Highest Education","State", "District","Taluka", "Village",
       "Location name", "Survey number", "Owner", "Farm area", "Farm area for cotton", "Horizontal distance",
        "Motor horse power", "Pump depth", "Unit farm area", "Unit farm area for cotton", "Soil texture", "Land type", "Source Irrigation", "Type Irrigation", "Distance in"
      ]
      rawcsv = CSV.generate do |csv|
        csv << csv_headers     
      end
      send_data(rawcsv, :type => 'text/csv charset=utf-8; header=present', :filename => "user_profile_sample.csv") and return
    end
  end
end
