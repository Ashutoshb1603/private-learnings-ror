module PestManagementFoilarSprays
  class Load
    @@loaded_from_gem = false
    def self.is_loaded_from_gem
      @@loaded_from_gem
    end
    
    #function is intentionally empty and will be implemented later
    def self.loaded
      #function is intentionally empty and will be implemented later
    end

    # Check if this file is loaded from gem directory or not
    # The gem directory looks like
    # /template-app/.gems/gems/bx_block_custom_user_subs-0.0.7/app/admin/subscription.rb
    # if it has block's name in it then it's a gem
    @@loaded_from_gem = Load.method('loaded').source_location.first.include?('bx_block_')
  end
end

unless PestManagementFoilarSprays::Load.is_loaded_from_gem
  ActiveAdmin.register BxBlockFarmDairy::PestManagementFoliarSpray, as: 'PestManagementFoliarSpray' do
    menu false unless ENV['STAGE'] == "dev"
    menu parent: 'Farm Dairy Activities', label: 'PestManagementFoilarSpray'
    permit_params :date_of_application, :quantity_of_pesticide, :machine_cost_of_spraying, :pesticide_cost, 
                  :labor_cost, :pest_managment_id, :unit_of_measure_id, :pesticide_id, :land_detail_id, :account_id, :crop_season_id, :crop_start_year, :crop_end_year

    form do |f|
      f.inputs do
        f.semantic_errors(*f.object.errors.keys)
        f.input :crop_season_id, as: :select, collection: BxBlockFarmDairy::CropSeason.all, include_blank: false
        f.input :crop_start_year, as: :select, collection: (Date.today.year - 1)..(Date.today.year + 20), include_blank: false
        f.input :crop_end_year, as: :select, collection: (Date.today.year - 1)..(Date.today.year + 20), include_blank: false
        f.input :date_of_application
        f.input :quantity_of_pesticide
        f.input :machine_cost_of_spraying
        f.input :pesticide_cost, as: :select, collection: BxBlockFarmDairy::TypeOfTrap.all, include_blank: false
        f.input :labor_cost
        f.input :pest_managment_id, as: :select, collection: BxBlockFarmDairy::PestManagment.all, include_blank: false
        f.input :unit_of_measure_id, as: :select, collection: BxBlockFarmDairy::UnitOfMeasure.all, include_blank: false
        f.input :pesticide_id, as: :select, collection: BxBlockFarmDairy::Pesticide.all, include_blank: false

        f.input :account_id
        f.input :land_detail_id
      end
      f.actions
    end
  end
end

