module ChatMessages
  class Load
    @@loaded_from_gem = false
    def self.is_loaded_from_gem
      @@loaded_from_gem
    end

    #function is intentionally empty and will be implemented later
    def self.loaded
      #function is intentionally empty and will be implemented later
    end

    # Check if this file is loaded from gem directory or not
    # The gem directory looks like
    # /template-app/.gems/gems/bx_block_custom_user_subs-0.0.7/app/admin/subscription.rb
    # if it has block's name in it then it's a gem
    @@loaded_from_gem = Load.method('loaded').source_location.first.include?('bx_block_')
  end
end

unless ChatMessages::Load.is_loaded_from_gem
  ActiveAdmin.register BxBlockChat::ChatMessage, as: 'Chat Messages' do
    menu false unless ENV['STAGE'] == "dev"
    permit_params :id, :account_id, :chat_id, :message, :message_type
    actions :all, :except => [:create, :new, :edit, :update]

    filter :field_executive
    filter :chat
    filter :message, filters: [:starts_with, :ends_with, :equals_to, :contains]

    index do
      selectable_column
      id_column
      column :field_executive do |object|
        object.account&.display_name
      end
      column :chat
      column :message
      column :message_type
      actions
    end
  end
end
