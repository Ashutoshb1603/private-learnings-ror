ActiveAdmin.register BxBlockCalendar::PhaseGroup, as: 'Phase' do
  # menu false
  config.sort_order = 'phases.start_day_asc'

  menu parent: 'Crop Calender', label: 'Phase'
  permit_params :owner_type, :owner_id, phases_attributes: [:id, :_destroy, :name, :start_day, :end_day, :language, phase_activity_progresses_attributes: [:id, :_destroy, :phase_activity_id, :start_day, :end_day, sub_activity_progresses_attributes: [:id, :_destroy, :phase_sub_activity_id, :before_after_day, :attachment, :description, :is_completed, input_details_attributes: [:id, :_destroy, :key, :value]]]]
  
  controller do
    def scoped_collection
      end_of_association_chain.default_scoped
    end
  end

  form do |pg|
    BxBlockCalendar::Phase.languages.keys.map do |language|
      pg.object.phases.build(language: language) unless pg.object.phases.map(&:language).include?(language)
    end

    pg.semantic_errors *pg.object.errors.keys
    pg.inputs '' do
       pg.input :owner_type, as: :hidden, :input_html => { :value => 'AdminUser' }
       pg.input :owner_id, as: :hidden, :input_html => { :value => current_admin_user.id }
      pg.fields_for :phases, header: false, allow_destroy: false, new_record: false do |f|
        next if f.object.language.nil?
        f.semantic_errors *f.object.errors.keys
        f.input :language, input_html: { readonly: true, class: "language-dd language-#{f.object.language}" }
        f.input :name
        f.input :start_day, input_html: {class: "start_day #{f.object.language}", readonly: f.object.language == 'English' ? false : true }
        f.input :end_day, input_html: {class: "end_day #{f.object.language}", readonly: f.object.language == 'English' ? false : true }
  
        f.object.phase_activity_progresses.build if (f.object.phase_activity_progresses.count == 0 && pg.object.errors.empty?)

        f.has_many :phase_activity_progresses, heading: 'Phase Activity', new_record: 'Add Activity', remove_record: 'Remove Activity', allow_destroy: true do |pa|
          pa.semantic_errors *pa.object.errors.keys
          pa.input :phase_activity_id, as: :select, collection: BxBlockCalendar::PhaseActivity.all.map { |activity| [activity.send("name_#{f.object.language.downcase}"), activity.id] }, input_html: { class: "language-activity #{f.object.language} #{pa.index}", 'data-index': pa.index, 'data-language': f.object.language }
          pa.input :start_day 
          pa.input :end_day

          pa.object.sub_activity_progresses.build if (pa.object.sub_activity_progresses.count == 0 && pg.object.errors.empty?)
          pa.has_many :sub_activity_progresses, heading: 'Phase Sub-Activity', new_record: 'Add SubActivity', remove_record: 'Remove SubActivity', allow_destroy: false do |td|
            next if td.object.farmer_id.present?
            td.semantic_errors *td.object.errors.keys

             td.input :phase_sub_activity_id, as: :select, collection: BxBlockCalendar::PhaseSubActivity.where(phase_activity_id: pa.object&.phase_activity_id), include_blank: false, input_html: { class: "language-subactivity #{f.object.language} #{pa.index}" }
            td.input :before_after_day 

            td.input :attachment, as: :file
            td.input :description

            # td.object.input_details.build unless td.object.input_details.count > 0
            td.has_many :input_details, heading: 'Inputs Details', new_record: 'Add', remove_record: 'Remove', allow_destroy: true do |fd|
              td.semantic_errors *td.object.errors.keys
              fd.input :key
              fd.input :value
            end
            td.input '_destroy', as: :boolean, label: 'Delete'
          end
        end
      end
    end
    pg.actions
  end

  filter :phases

  show do
    attributes_table do
      row :id
      row :created_at
      row :updated_at
      panel 'Phase' do 
        table_for phase.phases do |t|
          column :id do |object|
            object.id
          end
          column :name do |object|
            object.name
          end
          column :start_day do |object|
            object.start_day
          end
          column :end_day do |object|
            object.end_day
          end
          column :language do |object|
            object.language
          end
        end
      end
    end
  end
  
  index do
    selectable_column
    id_column
    column "Phase Name English", sortable: :name do |object|
      object.phases.find_by(language: "English")&.name
    end
    column "Phase Name Hindi", sortable: :name do |object|
      object.phases.find_by(language: "Hindi")&.name
    end
    column "Phase Name Gujarati", sortable: :name do |object|
      object.phases.find_by(language: "Gujarati")&.name
    end
    column "Start day", :sortable => 'phases.start_day' do |object|
      object.phases.find_by(language: "English")&.start_day
    end
    column "End day", :sortable => 'phases.end_day' do |object|
      object.phases.find_by(language: "English")&.end_day
    end
    column :created_at
    column :updated_at
    actions
  end
end