ActiveAdmin.register BxBlockCategories::Category, as: 'Category' do
  permit_params :name, :name_hindi, :name_gujrati, :image

  form do |f|
    f.inputs do
      f.input :name
      f.input :name_hindi
      f.input :name_gujrati
      f.input :image, as: :file
    end
    f.actions
  end

  index title: 'category' do
    selectable_column
    id_column
    column :name
    column :name_hindi
    column :name_gujrati
    column :image do |object|
      object.image.present? ? image_tag(object.image, style: 'width: 40px') : nil
    end
    actions
  end

  show do
    attributes_table do
      row :name
      row :name_hindi
      row :name_gujrati
      row :image do |object|
        object.image.present? ? image_tag(object.image, style: 'width: 40px') : nil
      end
    end
  end
end
