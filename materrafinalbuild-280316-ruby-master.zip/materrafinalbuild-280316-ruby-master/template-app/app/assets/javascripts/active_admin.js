//= require active_admin/base
//= require activeadmin/quill_editor/quill
//= require activeadmin/quill_editor_input
//= require select2
//= require select2-full

$(document).ready(function() {
  $('.multi-select2').select2();
  $('.language-dd').css('pointer-events','none');
});

$(document).on('input', '#bx_block_location_details_taluka_state_value, #bx_block_location_details_village_state_value, #account_state_id', function(){
  id = $(this).val()
  $('#bx_block_location_details_village_one_id').html('');
  return $.ajax({
    url: '/admin/districts?json=true&state_id='+id,
    type: 'get',
    dataType: 'html',
    success: function( data) {
      $('#bx_block_location_details_taluka_district_id, #bx_block_location_details_village_district_id, #account_district_id').html(data);
    }
  });
});

$(document).on('input', '.language-activity', function(){
  let id = $(this).val()
  let index = this.getAttribute('data-index')
  let language = this.getAttribute('data-language')

  $(`.language-subactivity.${language}.${index}`).html('');
  return $.ajax({
    url: `/admin/phase_activities/sub_activity?json=true&activity_id=${id}&language=${language}`,
    type: 'get',
    dataType: 'html',
    success: function( data) {
      $(`.language-subactivity.${language}.${index}`).html(data);
    }
  });
});

$(document).on('input', '#bx_block_location_details_village_district_id, #account_district_id', function(){
  id = $(this).val()
  $('#bx_block_matches_match_team_two_id').html('');
  return $.ajax({
    url: '/admin/talukas?json=true&district_id='+id,
    type: 'get',
    dataType: 'html',
    success: function( data) {
      $('#bx_block_location_details_village_taluka_id, #account_taluka_id').html(data);
    }
  });
});

$(document).on('input', '#bx_block_location_details_taluka_id, #account_taluka_id', function(){
  id = $(this).val()
  $('#bx_block_matches_match_team_two_id').html('');
  return $.ajax({
    url: '/admin/villages?json=true&taluka_id='+id,
    type: 'get',
    dataType: 'html',
    success: function( data) {
      $('#bx_block_location_details_village_name, #account_village_id').html(data);
    }
  });
});

$(document).on('input', '#chat_field_executive_id', function(){
  let chat_id = $(this).val()
  $('#bx_block_chat_field_executive_two_id').html('');
  return $.ajax({
    url: '/admin/user_groups?json=true&field_executive_id='+chat_id,
    type: 'get',
    dataType: 'html',
    success: function( data) { $('#chat_farmer_ids').html(data);}
  });
});

$(document).on('input', '#account_role_id_input', function(){
  if(document.getElementsByClassName('selected_role')[0].value == '1'){
    $('.has_many_add').hide()
    $('#account_villages_input').show()
    $('#account_state_id_input').hide()
    $('#account_district_id_input').hide()
    $('#account_taluka_id_input').hide()
    $('#account_village_id_input').hide()
  }
  else{
    $('.has_many_add').show()
    $('#account_villages_input').hide()
    $('#account_state_id_input').show()
    $('#account_district_id_input').show()
    $('#account_taluka_id_input').show()
    $('#account_village_id_input').show()
  }
});

$(document).ready(function() {
  if(window.location.href.includes('users/new')) $('.has_many_add').hide();
  $('#account_state_id_input').hide()
  $('#account_district_id_input').hide()
  $('#account_taluka_id_input').hide()
  $('#account_village_id_input').hide()
  
  if(document.getElementsByClassName('selected_role')[0].value == '1'){
    $('#account_villages_input').show()
    $('.has_many_add').hide();
  }
  if(document.getElementsByClassName('selected_role')[0].value == '2'){
    $('#account_villages_input').hide()
    $('#account_state_id_input').show()
    $('#account_district_id_input').show()
    $('#account_taluka_id_input').show()
    $('#account_village_id_input').show()
  }
});

$(document).on('input', '.start_day.English', function(){
  $(".start_day.Hindi").val($(".start_day.English").val())
  $(".start_day.Gujarati").val($(".start_day.English").val())
});

$(document).on('input', '.end_day.English', function(){
  $(".end_day.Hindi").val($(".end_day.English").val())
  $(".end_day.Gujarati").val($(".end_day.English").val())
});

