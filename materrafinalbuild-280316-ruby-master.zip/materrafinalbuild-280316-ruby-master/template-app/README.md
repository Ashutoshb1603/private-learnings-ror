# **Ruby** | _**MaterraFinalBuild**_ | _**280316** | _**studio_pro**_

## **Catalog ProjectId: 146576** | **Catalog BuildId: 17290**

## NOTE FOR DEVELOPERS:
Clone the code-engine branch into your working branch. The contents of the branch may get overwritten.
## Author:
Code-Engine
## Assembled Features To Block Status

| **Feature-Name**        | **Block-Name**        | **Path**  | **Status**  |
|:-------------|:-------------|:-------------|:-------------|
| LanguageOptions      | bx_block_language_options<br>      | {+app/controllers/bx_block_language_options+}<br> | {+Non-Empty+} |
| Dashboard4      | bx_block_dashboard<br>      | {+app/controllers/bx_block_dashboard+}<br> | {+Non-Empty+} |
| AdminConsole2      | bx_block_admin<br>      | {+app/controllers/bx_block_admin+}<br> | {+Non-Empty+} |
| DataImportexportcsv      | bx_block_data_import_export<br>      | {+app/controllers/bx_block_data_import_export+}<br> | {+Non-Empty+} |
| RolesPermissions2      | bx_block_roles_permissions<br>      | {+app/controllers/bx_block_roles_permissions+}<br> | {+Non-Empty+} |
| PostCreation2      | bx_block_posts<br>      | {+app/controllers/bx_block_posts+}<br> | {+Non-Empty+} |
| NotificationSettings      | bx_block_notifsettings<br>      | {+app/controllers/bx_block_notifsettings+}<br> | {+Non-Empty+} |
| Profilebio      | bx_block_profile<br>bx_block_profile_bio<br>      | {+app/controllers/bx_block_profile+}<br>{+app/controllers/bx_block_profile_bio+}<br> | {+Non-Empty+} |
| UploadMedia2      | bx_block_upload_media<br>      | {+app/controllers/bx_block_upload_media+}<br> | {+Non-Empty+} |
| PhotoLibrary3      | bx_block_photo_library<br>      | {++}<br> | {+Non-Empty+} |
| VideoLibrary      | bx_block_video_library<br>      | {++}<br> | {+Non-Empty+} |
| BulkUploading      | bx_block_bulk_uploading<br>      | {+app/controllers/bx_block_bulk_uploading+}<br> | {+Non-Empty+} |
| SignuploginModule2      | bx_block_login<br>bx_block_forgot_password<br>account_block<br>      | {+app/controllers/bx_block_login+}<br>{+app/controllers/bx_block_forgot_password+}<br>{+app/controllers/account_block+}<br> | {+Non-Empty+} |
| PushNotifications      | bx_block_push_notifications<br>      | {+app/controllers/bx_block_push_notifications+}<br> | {+Non-Empty+} |
| VideoManagement      | bx_block_video_management<br>      | {+app/controllers/bx_block_video_management+}<br> | {+Non-Empty+} |
| ForgotPassword3      | bx_block_forgot_password<br>      | {+app/controllers/bx_block_forgot_password+}<br> | {+Non-Empty+} |
| PhoneLogin      | bx_block_login<br>bx_block_forgot_password<br>      | {+app/controllers/bx_block_login+}<br>{+app/controllers/bx_block_forgot_password+}<br> | {+Non-Empty+} |
| PhoneVerification      | bx_block_phone_verification<br>      | {+app/controllers/bx_block_phone_verification+}<br> | {+Non-Empty+} |
| GoogleLogin14      | account_block<br>bx_block_login<br>      | {+app/controllers/account_block+}<br>{+app/controllers/bx_block_login+}<br> | {+Non-Empty+} |
| TaskGroups      | bx_block_tasks<br>      | {++}<br> | {+Non-Empty+} |
| TaskList      | bx_block_tasks<br>      | {++}<br> | {+Non-Empty+} |
| ContentManagement      | bx_block_content_management<br>      | {+app/controllers/bx_block_content_management+}<br> | {+Non-Empty+} |
| Location6      | bx_block_location<br>      | {+app/controllers/bx_block_location+}<br> | {+Non-Empty+} |
| Settings5      | bx_block_settings<br>      | {+app/controllers/bx_block_settings+}<br> | {+Non-Empty+} |
| Notifications3      | bx_block_notifications<br>bx_block_push_notifications<br>      | {+app/controllers/bx_block_notifications+}<br>{+app/controllers/bx_block_push_notifications+}<br> | {+Non-Empty+} |
| Calendar3      | bx_block_scheduling<br>      | {+app/controllers/bx_block_scheduling+}<br> | {+Non-Empty+} |
| TwofactorAuthentication2      | account_block<br>bx_block_forgot_password<br>      | {+app/controllers/account_block+}<br>{+app/controllers/bx_block_forgot_password+}<br> | {+Non-Empty+} |
| GeolocationReporting2      | bx_block_location<br>      | {+app/controllers/bx_block_location+}<br> | {+Non-Empty+} |
| ProjectTaskTracking      | bx_block_tasks<br>      | {++}<br> | {+Non-Empty+} |
| LiveChatSummary2      | bx_block_chat<br>      | {+app/controllers/bx_block_chat+}<br> | {+Non-Empty+} |
| VisualAnalytics      | bx_block_visual_analytics<br>      | {++}<br> | {+Non-Empty+} |
| LanguageSupport      | bx_block_languagesupport      | {-app/controllers/bx_block_languagesupport-} | {-Empty-} |
| WeatherIntegration      | bx_block_weatherintegration      | {-app/controllers/bx_block_weatherintegration-} | {-Empty-} |
| StatisticsReports2      | bx_block_statisticsreports2      | {-app/controllers/bx_block_statisticsreports2-} | {-Empty-} |
| DownloadableProducts2      | bx_block_downloadableproducts2      | {-app/controllers/bx_block_downloadableproducts2-} | {-Empty-} |
| OfflineBrowsing      | bx_block_offlinebrowsing      | {-app/controllers/bx_block_offlinebrowsing-} | {-Empty-} |
| OfflineWork      | bx_block_offlinework      | {-app/controllers/bx_block_offlinework-} | {-Empty-} |
| VideoEmbeddingYoutube      | bx_block_videoembeddingyoutube      | {-app/controllers/bx_block_videoembeddingyoutube-} | {-Empty-} |
| Download      | bx_block_download      | {-app/controllers/bx_block_download-} | {-Empty-} |
| ExpenseTracking      | bx_block_expensetracking      | {-app/controllers/bx_block_expensetracking-} | {-Empty-} |
| GroupChat      | bx_block_groupchat      | {-app/controllers/bx_block_groupchat-} | {-Empty-} |
| Surveys      | bx_block_surveys      | {-app/controllers/bx_block_surveys-} | {-Empty-} |
| AssessmentTest      | bx_block_assessmenttest      | {-app/controllers/bx_block_assessmenttest-} | {-Empty-} |
| BudgetingForecasting      | bx_block_budgetingforecasting      | {-app/controllers/bx_block_budgetingforecasting-} | {-Empty-} |
| Chat9      | bx_block_chat9      | {-app/controllers/bx_block_chat9-} | {-Empty-} |
| ChatBackuprestore      | bx_block_chatbackuprestore      | {-app/controllers/bx_block_chatbackuprestore-} | {-Empty-} |
| LiveChat2      | bx_block_livechat2      | {-app/controllers/bx_block_livechat2-} | {-Empty-} |
| MapSettings      | bx_block_mapsettings      | {-app/controllers/bx_block_mapsettings-} | {-Empty-} |
| Analytics9      | bx_block_analytics9      | {-app/controllers/bx_block_analytics9-} | {-Empty-} |
| Videos8      | bx_block_videos8      | {-app/controllers/bx_block_videos8-} | {-Empty-} |
| Geofence2      | bx_block_geofence2      | {-app/controllers/bx_block_geofence2-} | {-Empty-} |
| InventoryManagement2      | bx_block_inventorymanagement2      | {-app/controllers/bx_block_inventorymanagement2-} | {-Empty-} |
| Maps2      | bx_block_maps2      | {-app/controllers/bx_block_maps2-} | {-Empty-} |
| CfDbSetup      | bx_block_cfdbsetup      | {-app/controllers/bx_block_cfdbsetup-} | {-Empty-} |

## GRAFANA BACKEND URL
 - https://grafana.project-name-notfound-280316-ruby.b280316.none.eastus.az.svc.builder.ai

This application is a Ruby API. Full README coming soon...