module AccountBlock
  class UserMailer < ApplicationMailer
    def send_password
      @account = params[:account]
      @temporary_password = AESCrypt.decrypt(@account.temporary_password, ENV['ENCRYPT_KEY'])
      @user_name = @account.email.split("@").first
      @host = Rails.env.development? ? 'http://localhost:3000' : params[:host]
      mail(
          to: @account.email,
          from: 'builder.bx_dev@engineer.ai',
          subject: 'Setup profile') do |format|
        format.html { render 'send_password' }
      end
    end
  end
end