ActiveAdmin.register BxBlockRolesPermissions::Role, as: "Roles" do
  permit_params :name, :status, :created, :custom_id
	actions :all

  controller do
    def create
      params[:role] = params[:role].merge("created"=> Time.now.to_date.to_s)
      super
      current_admin_user.role_created_bies.create(role_id: resource.id)
    end
  end

	show do
    attributes_table do
      row :custom_id
      row :name
      row :status
      row :created
    end
    panel 'Permissions' do
      attributes_table_for roles.role_permissions do
        row :id
        row :title
        row :actions
        row :menu_id
      end
    end
  end

    form do |f|
      f.inputs 'Details' do
        f.input :name
        f.input :status, include_blank: false
      end
    f.actions
  end


end
