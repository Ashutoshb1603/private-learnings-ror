ActiveAdmin.register BxBlockRolesPermissions::Menu, as: 'Menus' do
	permit_params :title, :permission_category_id
	actions :all
end
