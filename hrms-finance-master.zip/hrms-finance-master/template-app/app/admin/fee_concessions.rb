ActiveAdmin.register BxBlockFee::FeeConcession, as: "Fee Concession" do
  permit_params :name, :valid_until, :fee_concession_type_id, :amount, :mode, :custom_id
  actions :all

  show do
    attributes_table do
      row :custom_id
      row :fee_concession_type do
        resource.fee_concession_type
      end
      row :name
      row :valid_until
      row :mode
      row :amount
    end
  end
end
