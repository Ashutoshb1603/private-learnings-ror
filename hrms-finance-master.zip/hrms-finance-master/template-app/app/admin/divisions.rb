ActiveAdmin.register BxBlockDivision::Division, as: "Division" do
  permit_params :title, :academic_class_id
	actions :all, except: [:destroy]

	show do
    attributes_table do
      row :title
      row :academic_class do |object|
        if object&.academic_class.present?
          link_to object&.academic_class&.name, "/admin/academic_classes/#{object&.academic_class&.id}"
        end
      end
    end
  end

  form do |f|
    f.inputs 'Details' do
      f.input :title
      f.input :academic_class, as: :select, collection: BxBlockAcademicClass::AcademicClass.all.map { |n| [n.name, n.id] }, include_blank: false, :input_html => { :width => 'auto' }

    end
    f.actions
  end

  index do
    selectable_column
    id_column
    column :title
    column :academic_class, sortable: :academic_class do |object|
      if object&.academic_class.present?
        link_to object&.academic_class&.name, "/admin/academic_classes/#{object&.academic_class&.id}"
      end
    end
    column :created_at
    column :updated_at
    actions
  end
end
