ActiveAdmin.register BxBlockProfile::Profile, as: "Organisation Profile" do
	# menu false
  permit_params :name, :business_location, :address, :email, :contact_no, :license_no, :fiscal_year, :city, :state, :pin_code, :website_url, :profile_pic, :fax_no
	actions :show, :edit, :update, :index

  index do
    selectable_column
    id_column
    column :name
    column :business_location
    column :address
    column :email
    column :contact_no
    column :license_no
    column :fiscal_year
    column :city
    column :state
    column :pin_code
    column :website_url
    column :fax_no
    column :profile_pic, as: :file
    actions
  end

  show do
    attributes_table do
      row :name
      row :business_location
      row :address
      row :email
      row :contact_no
      row :license_no
      row :fiscal_year
      row :city
      row :state
      row :pin_code
      row :website_url
      row :fax_no
      row :profile_pic, as: :file
    end
  end


	form do |f|
    f.inputs 'Details' do
      f.input :name
      f.input :business_location
      f.input :address
      f.input :email
      f.input :contact_no
      f.input :license_no
      f.input :fiscal_year
      f.input :city
      f.input :state
      f.input :pin_code
      f.input :website_url
      f.input :fax_no
      f.input :profile_pic, as: :file
    end
    f.actions
  end

  controller do
    def scoped_collection
      super.joins(account: :role).where('roles.name = ?', 'Organisation')
    end
  end
end
