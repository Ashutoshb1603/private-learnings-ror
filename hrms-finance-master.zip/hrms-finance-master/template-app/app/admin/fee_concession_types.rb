ActiveAdmin.register BxBlockFee::FeeConcessionType, as: "Fee Concession Type" do
  permit_params :name, :description
  actions :all

  show do
    attributes_table do
      row :name
      row :description
    end
  end
end
