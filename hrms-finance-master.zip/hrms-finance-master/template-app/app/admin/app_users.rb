ActiveAdmin.register AccountBlock::Account, as: "User" do
  # menu parent: 'All Users', label: 'App Users'
  Formtastic::FormBuilder.perform_browser_validations = true

  permit_params :first_name, :last_name, :full_phone_number, :phone_number, :email, :user_name, :activated, :country_code, :device_id, :unique_auth_id, :password, :temporary_password, :type, :role_id, profile_attributes: [:id, :name, :business_location, :address, :email, :contact_no, :license_no, :fiscal_year, :city, :state, :pin_code, :website_url, :fax_no, :profile_pic, :_destroy]

  index do
    selectable_column
    id_column
    column "Name" do |user|
      user&.first_name
    end
    column  :full_phone_number
    column  :email
    column  :activated
    column  :user_name
    column "Type" do |user|
      user.role
    end
    column :lms_role
    column :lms_account_id
    actions
    # actions do |resourse|
    #   item "Profile", "/admin/profiles/#{resourse&.profile&.id}" if resourse&.profile.present?
    # end

  end

  controller do
    def build_new_resource
      super.tap { |resource| resource.build_profile }
    end

    def find_resource
      super.tap do |resource|
        resource.build_profile unless resource.profile.present?
      end
    end

    def create
      super
      @relative_account = AccountBlock::RelativeAccount.create(relative_accountable_id:current_admin_user.id, relative_accountable_type: "BxBlockAdminConsole::AdminUser", account_id:resource.id)
      resource.referenceable_id = current_admin_user.id
      resource.referenceable_type = "BxBlockAdminConsole::AdminUser"
      resource.save
      if params[:account][:password].present?
        account_password = resource.account_passwords.new(password: params[:account][:password])
        account_password.save
      end
    end

    def update
      super
      if params[:account][:password].present?
        account_password = resource.account_passwords.new(password: params[:account][:password])
        account_password.save
      end
    end
  end

  show :title => proc {|user| user.first_name.to_s } do
    attributes_table do
      row "Name" do |object|
        object&.first_name
      end
      row :full_phone_number
      row :country_code
      row :phone_number
      row :email
      row :activated
      row :device_id
      row :unique_auth_id
      row :role
      row :created_at
      row :updated_at
      row :user_name
      row :lms_role
      row :school_id
      row :lms_account_id
      row :login_type
      row "Env" do |object|
        if Rails.env.development?
          "Dev"
        elsif Rails.env.staging?
          "Stag"
        else
          Rails.env
        end
      end
    end
    panel 'Profile' do
      attributes_table_for user.profile do
        row :id
        row :name
        row :business_location
        row :address
        row :email
        row :contact_no
        row :license_no
        row :fiscal_year
        row :city
        row :state
        row :pin_code
        row :website_url
        row :profile_image do |profile|
          unless profile.nil?
              image_tag profile.profile_pic, hight: 120, width: 120 rescue nil
          end
        end
        row :fax_no
      end
    end
  end


  form do |f|
    render 'form', context: self, f: f
  end

  
  # Filters
  filter :first_name 
  filter :full_phone_number
  filter :phone_number
  filter :email
  filter :created_at, as: :date_range, datepicker_options: { max_date: Date.today}, :input_html => { class: 'datepicker' }
  filter :user_name

end


