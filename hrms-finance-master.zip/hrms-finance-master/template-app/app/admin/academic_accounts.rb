ActiveAdmin.register BxBlockAcademicAccount::AcademicAccount, as: "AcademicAccount" do
  permit_params :name, :description, :code, :account_type_id, :is_sub_account, :parent_academic_account_id
	actions :all

	show do
    attributes_table do
      row :account_type do |object|
        if object&.account_type.present?
          link_to object&.account_type&.name, "/admin/account_types/#{object&.account_type&.id}"
        end
      end
      row :name
      row :code
      row :description
      row :is_sub_account
    end
  end
end
