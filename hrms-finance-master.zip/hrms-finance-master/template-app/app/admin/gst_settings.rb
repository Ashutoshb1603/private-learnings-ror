ActiveAdmin.register BxBlockGstSetting::GstSetting, as: "GstSetting" do
  permit_params :gst_number, :legal_name, :trade_name, :regesterd_on
	actions :all
  before_action :check_gst_setting_exist, only: [:create]



  controller do

    def create
      if @gst_setting == true
        redirect_to gst_setting_params, :alert => "Gst is already exist. You can update it."
      else
        gst_setting = BxBlockGstSetting::GstSetting.new(gst_setting_params)   
        if gst_setting.save
            redirect_to gst_setting_params  
        else
            redirect_to new_admin_gst_setting_path, flash: { error: gst_setting.errors }
        end
      end
    end


    def check_gst_setting_exist
      @gst_setting = nil
      if BxBlockGstSetting::GstSetting.first.present? 
        @gst_setting = true
      else
        @gst_setting = false
      end
    end

    private

      def gst_setting_params
        params.require(:bx_block_gst_setting_gst_setting).permit(:gst_number, :legal_name, :trade_name, :regesterd_on)
      end
  end

	show do
    attributes_table do
      row :gst_number
      row :legal_name
      row :trade_name
      row :regesterd_on
    end
  end
end

