ActiveAdmin.register BxBlockProfile::Profile, as: "Employee Profile" do
  # menu false
  permit_params :custom_id, :first_name, :last_name, :email, :contact_no, :address, :street, :city, :state, :pin_code, :date_of_birth, :age, :nationality, :gender, :marital_status, :about_me
  actions :all

  index do
    selectable_column
    id_column
    column :custom_id
    column :first_name
    column :last_name
    column :email
    column :contact_no
    column :address
    column :street
    column :city
    column :state
    column :pin_code
    column :date_of_birth
    column :age
    column :nationality
    column :gender
    column :marital_status
    column :about_me
    actions
  end

  show do
    attributes_table do
      row :custom_id
      row :first_name
      row :last_name
      row :email
      row :contact_no
      row :address
      row :street
      row :city
      row :state
      row :pin_code
      row :date_of_birth
      row :age
      row :nationality
      row :gender
      row :marital_status
      row :about_me
    end
  end


  form do |f|
    f.inputs do
      f.input :custom_id
      f.input :first_name
      f.input :last_name
      f.input :email
      f.input :contact_no
      f.input :address
      f.input :street
      f.input :city
      f.input :state
      f.input :pin_code
      f.input :date_of_birth
      f.input :age
      f.input :nationality
      f.input :gender
      f.input :marital_status
      f.input :about_me
    end
    f.actions
  end

  controller do
    def scoped_collection
      super.joins(account: :role).where('roles.name = ?', 'Employee')
    end
  end
end
