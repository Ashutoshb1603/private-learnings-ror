ActiveAdmin.register BxBlockFine::Fine, as: "Fine" do
  permit_params :name, :day, :duration, :fine_amount, :mode
	actions :all

	 show do
    attributes_table do
      row :name
      row :day
      row :duration
      row :fine_amount
      row :mode  
    end
  end
end