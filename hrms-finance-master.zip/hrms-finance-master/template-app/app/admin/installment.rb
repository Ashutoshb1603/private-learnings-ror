ActiveAdmin.register BxBlockInstallment::Installment, as: "Installment" do
  permit_params :name, :duration_no, :duration, :description
	actions :all

	 show do
    attributes_table do
      row :name
      row :duration_no
      row :duration
      row :description
    end
  end
end