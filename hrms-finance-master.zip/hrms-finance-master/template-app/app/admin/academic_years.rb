ActiveAdmin.register BxBlockAcademicYear::AcademicYear, as: "AcademicYear" do
  permit_params :year
	actions :all, except: [:destroy]

	show do
    attributes_table do
      row :year
    end
    panel 'Academic Class' do
      attributes_table_for academic_year.academic_classes do
        row :id
        row :name
      end
    end
  end
end