ActiveAdmin.register BxBlockHrms::Designation, as: 'Designation' do
  permit_params :name, :creator_id
  actions :all

  index do
    selectable_column
    id_column
    column :name
    column :added_by do |object|
      object&.creator&.role&.name
    end
    column :created_at
    column :updated_at
    actions
  end

  show do
    attributes_table do
      row :name
      row :added_by do
        resource&.creator&.role&.name
      end
      row :created_at
      row :updated_at
    end
  end

  form do |f|
    f.inputs do
      f.input :name
      f.input :creator_id, label: 'Added By', as: :select, collection: AccountBlock::Account.all.map { |obj| [obj&.role.name, obj.id]}
    end
    f.actions
  end
end
