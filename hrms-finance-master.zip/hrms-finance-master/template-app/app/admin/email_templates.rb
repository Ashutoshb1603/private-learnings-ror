ActiveAdmin.register BxBlockEmailTemplate::EmailTemplate, as: "EmailTemplate" do
  permit_params :name, :created, :subject, :description
  actions :all

  index do
    selectable_column
    id_column
      column :name
      column :created 
      column :subject  
      column :description  
    actions
  end

  show do
    attributes_table do
      row :name
      row :created
      row :subject  
      row :description 
    end
  end

  form do |f|
    f.inputs do
      f.input :name
      f.input :created
      f.input :subject
      f.input :description
    end
    f.actions
  end

end
