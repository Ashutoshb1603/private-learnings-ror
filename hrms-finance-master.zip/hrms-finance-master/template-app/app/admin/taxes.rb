ActiveAdmin.register BxBlockTax::Tax, as: "Tax" do
  permit_params :name, :tax_percentage, :description, :custom_id, :is_gst, :tax_type
	actions :all

	show do
    attributes_table do
      row :name
      row :tax_percentage
      row :description
      row :custom_id
      row :is_gst
      row :tax_type
    end
  end
end