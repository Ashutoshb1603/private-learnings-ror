ActiveAdmin.register BxBlockStudent::Student, as: "Student" do
  permit_params :first_name, :last_name, :father_name, :mother_name, :division_id, :dob, :gender, :registration_no, :roll_no
	actions :all

	show do
    attributes_table do
      row :first_name
      row :last_name
      row :father_name
      row :mother_name
      row :division_id
      row :dob
      row :gender
      row :registration_no
      row :roll_no
    end
  end
end