ActiveAdmin.register BxBlockAcademicAccount::AccountType, as: 'Account Type' do
	permit_params :name
	actions :all, except: [:destroy]
end
