ActiveAdmin.register BxBlockInvoiceTemplate::InvoiceTemplate, as: "InvoiceTemplate" do
  permit_params :name, :subject, :description, sender_email: [], cc_email: [], bcc_email: []
  actions :all

  index do
    selectable_column
    id_column
      column :name
      column :sender_email
      column :cc_email  
      column :bcc_email 
      column :subject 
      column :description 
    actions
  end

   controller do
    def create
      params[:bx_block_invoice_template_invoice_template][:sender_email]=  params[:bx_block_invoice_template_invoice_template][:sender_email].reject { |c| c.empty? }
      params[:bx_block_invoice_template_invoice_template][:cc_email]=  params[:bx_block_invoice_template_invoice_template][:cc_email].reject { |c| c.empty? }
      params[:bx_block_invoice_template_invoice_template][:bcc_email]=  params[:bx_block_invoice_template_invoice_template][:bcc_email].reject { |c| c.empty? }
      super
    end
    def update
      params[:bx_block_invoice_template_invoice_template][:sender_email]=  params[:bx_block_invoice_template_invoice_template][:sender_email].reject { |c| c.empty? }
      params[:bx_block_invoice_template_invoice_template][:cc_email]=  params[:bx_block_invoice_template_invoice_template][:cc_email].reject { |c| c.empty? }
      params[:bx_block_invoice_template_invoice_template][:bcc_email]=  params[:bx_block_invoice_template_invoice_template][:bcc_email].reject { |c| c.empty? }
      super
    end
   end

   show do
    attributes_table do
      row :name
      row :sender_email
      row :cc_email  
      row :bcc_email 
      row :subject 
      row :description 
    end
  end

  form do |f|
    f.inputs do
      f.input :name
      f.input :sender_email, as: :select, collection: AccountBlock::Account.all.map{|e| ["#{e.name} - <#{e.email}>",e.email]},include_blank: false, :input_html => {:width => 'auto', multiple: true}
       f.input :cc_email, as: :select, collection: AccountBlock::Account.all.map{|e| ["#{e.name} - <#{e.email}>",e.email]},include_blank: false, :input_html => {:width => 'auto', multiple: true}
        f.input :bcc_email, as: :select, collection: AccountBlock::Account.all.map{|e| ["#{e.name} - <#{e.email}>",e.email]},include_blank: false, :input_html => {:width => 'auto', multiple: true}
      f.input :subject 
      f.input :description
    end
    f.actions
  end
end




#  f.input :academic_year, as: :select, collection: BxBlockAcademicYear::AcademicYear.all.map { |y| [y.year, y.id] }, include_blank: false, :input_html => { :width => 'auto' }
#     end
# module BxBlockInvoiceTemplate
#   class InvoiceTemplate < BxBlockInvoiceTemplate::ApplicationRecord
#     self.table_name = :invoice_templates
#     validates :name, presence: true
#   end
# end

