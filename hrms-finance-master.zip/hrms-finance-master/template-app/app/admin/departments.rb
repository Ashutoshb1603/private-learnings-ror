ActiveAdmin.register BxBlockHrms::Department, as: 'Department' do
  permit_params :name, :creator_id
  actions :all

  index do
    selectable_column
    id_column
    column :name
    column :lead
    column :email
    column :added_by do |object|
      object&.creator&.role&.name
    end
    column :created_at
    column :updated_at
    column :parent_department do |object|
      object&.parent_department&.name
    end
    actions
  end

  show do
    attributes_table do
      row :name
      row :added_by do
        resource&.creator&.role&.name
      end
      row :created_at
      row :updated_at
      row :parent_department do
        resource&.parent_department&.name
      end
    end
  end

  form do |f|
    f.inputs do
      f.input :name
      f.input :creator_id, label: 'Added By', as: :select, collection: AccountBlock::Account.all.map { |obj| [obj&.role.name, obj.id]}
      f.input :parent_department_id, label: 'Parent Department', as: :select, collection: BxBlockHrms::Department.all.map { |obj| [obj&.parent_department&.name, obj.id]}
    end
    f.actions
  end
end
