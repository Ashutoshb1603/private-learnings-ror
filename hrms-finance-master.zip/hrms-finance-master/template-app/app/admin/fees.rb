ActiveAdmin.register BxBlockFee::Fee, as: "Fee" do
  permit_params :name, :valid_until, :academic_account_id, :amount, :custom_id ,tax_ids: []


 form do |f|
    f.inputs do
      f.input :academic_account, as: :select, collection: BxBlockAcademicAccount::AcademicAccount.all.map { |adc| [adc.name, adc.id] }, include_blank: false, :input_html => { :width => 'auto'} 
      f.input :valid_until
      f.input :name
      f.input :amount
      f.input :tax_ids, as: :select, collection: BxBlockTax::Tax.all.map { |fee| [fee.tax_percentage.to_s + "%", fee.id] }, include_blank: false, :input_html => { :width => 'auto', multiple: true } 
    end
    f.actions
  end


	show do
    attributes_table do
      row :name
      row :valid_until
      row :academic_account
      row :amount
      row :tax_ids do|fee|
        fee&.tax_ids.reject { |e| e.nil? || e&.empty? }
      end
      row :custom_id
    end
  end

  index do
    selectable_column
    id_column
    column :name
    column :valid_until
    column :academic_account, sortable: :academic_account do |object|
      if object&.academic_account.present?
        link_to object&.academic_account&.name, "/admin/academic_accounts/#{object&.academic_account&.id}"
      end
    end
    column :amount
    column :tax_ids do|fee|
          fee&.tax_ids.reject { |e| e.nil? || e&.empty? }
        end
    column :custom_id
    column :created_at
    column :updated_at
    actions
  end
end