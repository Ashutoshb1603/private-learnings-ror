ActiveAdmin.register BxBlockRolesPermissions::PermissionCategory, as: 'Permission Category' do
  permit_params :title
  actions :all, except: [:destroy]
end
