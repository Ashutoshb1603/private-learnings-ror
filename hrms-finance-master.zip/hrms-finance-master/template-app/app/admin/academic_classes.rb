ActiveAdmin.register BxBlockAcademicClass::AcademicClass, as: "AcademicClass" do
  permit_params :name, :academic_year_id
	actions :all, except: [:destroy]

	show do
    attributes_table do
      row :name
      row :academic_year do |object|
        if object&.academic_year.present?
          link_to object&.academic_year&.year, "/admin/academic_years/#{object&.academic_year&.id}"
        end
      end
    end
    panel 'Academic Divisions' do
      attributes_table_for academic_class.divisions do
        row :id
        row :title
      end
    end
  end

    form do |f|
    f.inputs 'Details' do
      f.input :name
      f.input :academic_year, as: :select, collection: BxBlockAcademicYear::AcademicYear.all.map { |y| [y.year, y.id] }, include_blank: false, :input_html => { :width => 'auto' }
    end
    f.actions
  end

  index do
    selectable_column
    id_column
    column :name
    column :academic_year, sortable: :academic_year do |object|
      if object&.academic_year.present?
        link_to object&.academic_year&.year, "/admin/academic_years/#{object&.academic_year&.id}"
      end
    end
    column :created_at
    column :updated_at
    actions
  end
end