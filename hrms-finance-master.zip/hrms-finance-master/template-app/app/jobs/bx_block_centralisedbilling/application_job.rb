module BxBlockCentralisedbilling
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
