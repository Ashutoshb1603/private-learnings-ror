module BxBlockContentmanagement
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
