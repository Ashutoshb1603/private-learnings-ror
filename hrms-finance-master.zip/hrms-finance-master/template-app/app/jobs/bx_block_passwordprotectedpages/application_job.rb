module BxBlockPasswordprotectedpages
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
