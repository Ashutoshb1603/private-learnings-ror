module BxBlockSummarycard
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
