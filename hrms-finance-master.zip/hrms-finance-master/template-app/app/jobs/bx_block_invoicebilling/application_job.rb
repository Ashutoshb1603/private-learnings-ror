module BxBlockInvoicebilling
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
