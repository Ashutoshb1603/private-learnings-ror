module BxBlockCvresumecandidatemanagement
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
