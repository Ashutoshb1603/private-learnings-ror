module BxBlockGraphicalcharts
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
