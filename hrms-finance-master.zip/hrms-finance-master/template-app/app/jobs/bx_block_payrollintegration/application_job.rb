module BxBlockPayrollintegration
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
