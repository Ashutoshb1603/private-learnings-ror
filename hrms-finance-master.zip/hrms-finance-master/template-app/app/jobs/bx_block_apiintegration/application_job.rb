module BxBlockApiintegration
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
