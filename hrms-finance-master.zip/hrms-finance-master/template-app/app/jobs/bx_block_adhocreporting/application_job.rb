module BxBlockAdhocreporting
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
