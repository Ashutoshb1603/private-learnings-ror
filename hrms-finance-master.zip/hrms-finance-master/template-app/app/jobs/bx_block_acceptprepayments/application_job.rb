module BxBlockAcceptprepayments
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
