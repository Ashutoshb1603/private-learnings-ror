module BxBlockAccounttransfer
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
