module BxBlockPayments
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
