module BxBlockPeoplemanagement
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
