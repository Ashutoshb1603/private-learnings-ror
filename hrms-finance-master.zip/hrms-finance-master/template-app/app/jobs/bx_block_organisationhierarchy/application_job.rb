module BxBlockOrganisationhierarchy
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
