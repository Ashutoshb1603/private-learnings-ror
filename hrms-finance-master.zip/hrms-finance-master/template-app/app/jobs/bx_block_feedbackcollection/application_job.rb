module BxBlockFeedbackcollection
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
