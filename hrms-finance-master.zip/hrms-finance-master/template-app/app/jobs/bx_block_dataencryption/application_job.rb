module BxBlockDataencryption
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
