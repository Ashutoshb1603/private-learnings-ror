module BxBlockTeambuilder
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
