module BxBlockPerformancetracker
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
