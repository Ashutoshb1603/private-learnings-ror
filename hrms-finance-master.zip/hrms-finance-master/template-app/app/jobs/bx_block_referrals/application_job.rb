module BxBlockReferrals
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
