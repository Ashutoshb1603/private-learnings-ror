module BxBlockReviewandapproval
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
