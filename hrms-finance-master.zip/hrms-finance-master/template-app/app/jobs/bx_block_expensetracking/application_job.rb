module BxBlockExpensetracking
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
