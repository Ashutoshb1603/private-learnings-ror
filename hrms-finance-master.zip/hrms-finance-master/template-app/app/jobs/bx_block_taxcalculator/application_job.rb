module BxBlockTaxcalculator
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
