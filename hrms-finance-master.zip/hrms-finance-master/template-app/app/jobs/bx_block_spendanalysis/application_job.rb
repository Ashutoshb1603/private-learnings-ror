module BxBlockSpendanalysis
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
