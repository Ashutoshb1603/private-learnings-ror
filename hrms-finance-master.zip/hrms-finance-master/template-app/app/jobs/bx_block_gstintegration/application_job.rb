module BxBlockGstintegration
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
