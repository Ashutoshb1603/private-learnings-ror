module BxBlockSinglesignonsso
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
