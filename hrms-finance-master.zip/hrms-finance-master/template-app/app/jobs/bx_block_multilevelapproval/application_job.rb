module BxBlockMultilevelapproval
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
