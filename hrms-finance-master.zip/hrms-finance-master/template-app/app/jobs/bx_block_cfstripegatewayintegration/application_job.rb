module BxBlockCfstripegatewayintegration
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
