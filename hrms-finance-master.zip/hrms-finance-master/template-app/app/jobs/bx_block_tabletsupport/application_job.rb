module BxBlockTabletsupport
  class ApplicationJob < BuilderBase::ApplicationJob
  end
end
