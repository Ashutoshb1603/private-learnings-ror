module BxBlockRolesPermissions
  class PermissionCategory < ApplicationRecord
    self.table_name = :permission_categories
    validates :title, uniqueness: true, presence: true
    has_many :menus, class_name: 'Menu'

    accepts_nested_attributes_for :menus

  end
end
