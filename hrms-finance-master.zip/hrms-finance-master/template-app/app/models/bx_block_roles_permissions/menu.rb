module BxBlockRolesPermissions
  class Menu < ApplicationRecord
    self.table_name = :menus
    validates :title, uniqueness: true, presence: true
    has_many :role_permissions, class_name: 'RolePermission', dependent: :destroy
    belongs_to :permission_category, class_name: 'PermissionCategory'
    default_scope { order(:id) }
    scope :get_all, -> {all.pluck(:title)}
  end
end
