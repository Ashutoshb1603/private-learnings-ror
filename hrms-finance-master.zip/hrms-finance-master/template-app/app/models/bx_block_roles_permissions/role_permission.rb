module BxBlockRolesPermissions
	class RolePermission < ApplicationRecord
    self.table_name = :role_permissions
    belongs_to :role, class_name: 'BxBlockRolesPermissions::Role'
    belongs_to :menu, class_name: 'Menu'
	end
end
