module BxBlockRolesPermissions
	class RoleCreatedBy < ApplicationRecord
		self.table_name = :role_created_bies
    belongs_to :role_created_byable, polymorphic: true
    belongs_to :role, class_name: "BxBlockRolesPermissions::Role"
	end
end
