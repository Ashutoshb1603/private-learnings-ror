module BxBlockRolesPermissions
  class Role < ApplicationRecord
    FUll_ACCESS = %w[FullAccess View Create Edit Delete Approve]
    CSV_HEADERS = %w[id role_name created_on created_by status]
    CSV_SAMPLE_HEADERS = %w[role_name status]
    self.table_name = :roles

    scope :order_by_created, -> { order(created_at: :desc) }
    has_many :accounts, class_name: 'AccountBlock::Account', dependent: :destroy
    has_many :role_permissions, class_name: 'BxBlockRolesPermissions::RolePermission', dependent: :destroy
    has_one :role_created_bie, class_name: 'BxBlockRolesPermissions::RoleCreatedBy', dependent: :destroy
    validates_uniqueness_of :name, case_sensitive: false, message: lambda{|x, y| "#{y[:value]} is already present" }
    validates_presence_of :name, { message: "Role name can't be blank" }
    enum status: [:active, :inactive]
    after_create :update_custom_id

    def update_custom_id
      self.custom_id = ("000000" + self.id.to_s).last(6)
      self.save
    end

    def self.import(file, current_user)
      invaild_data = []
      CSV.foreach(file.path, headers: true) do |row|
        begin
          role = create!(name: row[0], created: Time.zone.now, created_by: current_user.role_name, status: row[1])
        rescue => e
          invaild_data << row.to_h.merge("errors" => e)
          next
        end
        current_user.role_created_bies.create!(role_id: role.id)
        Menu.get_all.each do |obj|
          next unless row[obj].present?

          menu_id = Menu.find_by("title ILIKE ?", obj).id
          actions = row[obj].split(',').map { |m| m.delete(' ').camelize }
          actions = FUll_ACCESS if actions.include?('FullAccess')
          actions.prepend('View') if %w[Create Edit Delete Approve].any? {|obj| actions.include?(obj) } && !actions.include?("View")
          role.role_permissions.create!(menu_id: menu_id, title: obj, actions: actions)
        end
      end
      invaild_data
    end

    def self.to_sample_csv
      attributes = CSV_SAMPLE_HEADERS + Menu.get_all
      CSV.generate(headers: true) do |csv|
        csv << attributes
        all.each do |role|
          csv << [role.name, role.status] + role.find_data
        end
      end
    end

    def self.to_sample_csv
      attributes = CSV_SAMPLE_HEADERS + Menu.get_all
      CSV.generate(headers: true) do |csv|
        csv << attributes
        all.each do |role|
          csv << [role.name, role.status] + role.find_data
        end
      end
    end

    def self.to_csv
      attributes = CSV_HEADERS + Menu.get_all
      CSV.generate(headers: true) do |csv|
        csv << attributes
        all.each do |role|
          csv << [role.custom_id, role.name, role.created&.to_date, role&.role_created_by, role.status] + role.find_data
        end
      end
    end

    def find_data
      Menu.ids.map { |menu_id| self.role_permissions.find_by(menu_id: menu_id)&.actions&.join(', ') }
    end

    def role_created_by
      if self.role_created_bie&.role_created_byable_type == 'BxBlockAdminConsole::AdminUser'
       'Super Admin'
      else
        self.role_created_bie&.role_created_byable&.role_name
      end
    end
  end
end
