module AccountBlock
	class AccountTd < ApplicationRecord
		self.table_name = :account_tds
		belongs_to :section, class_name: "AccountBlock::Section"
		validates_presence_of :tax_name, { message: "Tax name can't be blank" }
		validates_uniqueness_of :tax_name, case_sensitive: false, message: lambda{|x, y| "#{y[:value]} is already present" }
		has_many :vendors, class_name: "AccountBlock::Vendor", dependent: :destroy
		has_many :business_customers, class_name: "BxBlockProfile::BusinessCustomer"
	end
end
