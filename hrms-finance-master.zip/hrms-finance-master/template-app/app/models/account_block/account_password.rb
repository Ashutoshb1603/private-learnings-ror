module AccountBlock
	class AccountPassword < ApplicationRecord
    self.table_name = :account_passwords
		belongs_to :account, class_name: "AccountBlock::Account"
		before_save :encrypt_password
		def encrypt_password
			encrypted_data = AESCrypt.encrypt(self.password, ENV['ENCRYPT_KEY'])
			self.password = encrypted_data
		end
	end
end
