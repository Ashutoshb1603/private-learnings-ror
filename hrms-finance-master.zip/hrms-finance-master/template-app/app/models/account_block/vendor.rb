module AccountBlock
  class Vendor < AccountBlock::ApplicationRecord
    self.table_name = :vendors
    scope :order_by_created, -> { order(created_at: :desc) }
    validates :salutation,:first_name,:last_name ,:company_name ,:vendor_email ,:phone_no_mob ,:phone_no_work, :website_url , presence: true
    validates :vendor_email, uniqueness: { case_sensitive: false, message: lambda{|x, y| "#{y[:value]} is already present" }}
    validates :phone_no_mob, uniqueness: { case_sensitive: false, message: lambda{|x, y| "#{y[:value]} is already present" }}
    validates :phone_no_work, uniqueness: { case_sensitive: false, message: lambda{|x, y| "#{y[:value]} is already present" }}
    validate :valid_email
    validate :valid_phone_number_mob, :valid_phone_number_work
    belongs_to :account, class_name: "AccountBlock::Account" ,foreign_key: :account_id
    has_many :expenses, class_name: 'BxBlockExpensetracking::Expense'
    has_many :recurring_expenses,class_name: "BxBlockExpensetracking::RecurringExpense"
    belongs_to :account_td, class_name: "AccountBlock::AccountTd"
    belongs_to :gst_treatment, class_name: "BxBlockProfile::GstTreatment"
    belongs_to :payment_term, class_name: "BxBlockProfile::PaymentTerm"
    after_create :update_custom_id
    before_save :same_as_billing_address

    def update_custom_id
      self.custom_id = ("000000" + self.id.to_s).last(6)
      self.save
    end

    def self.to_csv
      attributes = ["ID", "Name", "Company", "Email", "Contact No."]
      CSV.generate(headers: true) do |csv|
        csv << attributes
        all.each do |vendor|
          csv << [vendor.custom_id , vendor&.name, vendor.company_name, vendor.vendor_email, vendor&.full_phone_no_mob]
        end
      end
    end

    def self.to_sample_csv
      attributes = ['Salutation', 'First name', 'Last name', 'Company', 'Email', 'Contact No code', 'Contact no mob', 'Phone no work code', 'Phone no work', 'Website url', 'GST treatment', 'GSTIN/UIN', 'PAN Number', 'Source of Supply', 'Currency', 'Payment Tearms', 'TDS', 'Billing Street', 'Billing Address', 'Same as Billing Address', 'Shipping Street', 'Shipping Address', 'Remarks']
      CSV.generate(headers: true) do |csv|
        csv << attributes
        all.each do |vendor|
          csv << [vendor.salutation, vendor.first_name, vendor.last_name, vendor.company_name, vendor.vendor_email, vendor.phone_no_mob_code, vendor.phone_no_mob, vendor.phone_no_work_code, vendor.phone_no_work, vendor.website_url, vendor&.gst_treatment&.name, vendor.gstin_uin, vendor.pan_number, vendor.state_source_of_supply, vendor.currency, vendor&.payment_term&.term_name, vendor&.account_td&.tax_name, vendor.billing_address, vendor.billing_address2, vendor.is_same_billing_address, vendor.shipping_address, vendor.shipping_address, vendor.remarks]
        end
      end
    end

    def self.import(file, user)
      invaild_data = []
      CSV.foreach(file.path, headers: true) do |row|
        gst_treat = BxBlockProfile::GstTreatment.find_by('name ILIKE ?', row[10].to_s.strip)
        gst_treatment_id = gst_treat.present? ? gst_treat.id : nil

        payment_term = BxBlockProfile::PaymentTerm.find_by('term_name ILIKE ?', row[15].to_s.strip)
        payment_term_id = payment_term.present? ? payment_term.id : nil

        tds = AccountBlock::AccountTd.find_by('tax_name ILIKE ?', row[16].to_s.strip)
        tds_id = tds.present? ? tds.id : nil

        is_same_as_billing_address = ActiveModel::Type::Boolean.new.cast(row[19].strip)
        if is_same_as_billing_address
          vendor = AccountBlock::Vendor.create(salutation: row[0].to_s.strip, first_name: row[1].to_s.strip, last_name: row[2].to_s.strip, company_name: row[3].to_s.strip, vendor_email: row[4].to_s.strip, phone_no_mob_code: row[5].to_i, phone_no_mob: row[6].to_s.strip, phone_no_work_code: row[7].to_i, phone_no_work: row[8].to_s.strip, website_url: row[9].to_s.strip, gst_treatment_id: gst_treatment_id, gstin_uin: row[11].to_s.strip, pan_number: row[12].to_s.strip, state_source_of_supply: row[13].to_s.strip, currency: row[14].to_s.strip, payment_term_id: payment_term_id, account_td_id: tds_id, billing_address: row[17].to_s.strip, billing_address2: row[18].to_s.strip, is_same_billing_address: true, remarks: row[22], account_id: user.id)
          if vendor.errors.any?
            invaild_data << row.to_h.merge("Error" => vendor.errors.full_messages.join(", "))
          end
        else
          vendor = AccountBlock::Vendor.create(salutation: row[0].to_s.strip, first_name: row[1].to_s.strip, last_name: row[2].to_s.strip, company_name: row[3].to_s.strip, vendor_email: row[4].to_s.strip, phone_no_mob_code: row[5].to_i, phone_no_mob: row[6].to_s.strip, phone_no_work_code: row[7].to_i, phone_no_work: row[8].to_s.strip, website_url: row[9].to_s.strip, gst_treatment_id: gst_treatment_id, gstin_uin: row[11].to_s.strip, pan_number: row[12].to_s.strip, state_source_of_supply: row[13].to_s.strip, currency: row[14].to_s.strip, payment_term_id: payment_term_id, account_td_id: tds_id, billing_address: row[17].to_s.strip, billing_address2: row[18].to_s.strip, is_same_billing_address: false, shipping_address: row[20].to_s.strip, shipping_address2: row[21].to_s.strip, remarks: row[22], account_id: user.id)
          if vendor.errors.any?
            invaild_data << row.to_h.merge("Error" => vendor.errors.full_messages.join(", "))
          end
        end
      end
      invaild_data
    end

    def name
      self.first_name.to_s + " " + self.last_name.to_s rescue ""
    end

    def full_phone_no_mob
      "+" + self.phone_no_mob_code.to_s + " " + self.phone_no_mob.to_s rescue ""
    end

    def valid_email
      unless EmailValidation.new(vendor_email).valid?
        errors.add(:vendor_email, "Invalid email format.")
      end
    end
    def valid_phone_number_mob
      if phone_no_mob_code.present?
        phone_no_mob_check = phone_no_mob_code.to_s + phone_no_mob.to_s
      else
        phone_no_mob_check = 91.to_s + phone_no_mob.to_s
      end
      unless Phonelib.valid?(phone_no_mob_check)
        errors.add(:phone_no_mob, "Invalid or Unrecognized Phone Number Mobile")
      end
    end
    def valid_phone_number_work
      if phone_no_work_code.present?
        phone_no_work_check = phone_no_work_code.to_s + phone_no_work.to_s
      else
        phone_no_work_check = 91.to_s + phone_no_work.to_s
      end
      unless Phonelib.valid?(phone_no_work_check)
        errors.add(:phone_no_work, "Invalid or Unrecognized Phone Number Work")
      end
    end

    def same_as_billing_address
      if is_same_billing_address
        self.shipping_address = billing_address
        self.shipping_address2 = billing_address2
      end
    end
  end
end
