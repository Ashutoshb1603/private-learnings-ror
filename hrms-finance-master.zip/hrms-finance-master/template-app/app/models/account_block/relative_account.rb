module AccountBlock
  class RelativeAccount < ApplicationRecord
    self.table_name = :relative_accounts
    belongs_to :relative_accountable, polymorphic: true
    belongs_to :account, class_name: "AccountBlock::Account", optional: true
  end
end
