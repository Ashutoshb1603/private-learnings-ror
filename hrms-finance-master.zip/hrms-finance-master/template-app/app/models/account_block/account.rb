module AccountBlock
  class Account < AccountBlock::ApplicationRecord
    self.table_name = :accounts

    include Wisper::Publisher
    enum login_type: ["Email", "Phone"]
    scope :newest_first, -> { order(created_at: :desc) }
    attr_accessor :current_password
    has_secure_password
    before_validation :parse_full_phone_number, :set_temporary_password
    before_create :temporary_password_to_encrypt
    validates :email, uniqueness: { case_sensitive: false, message: lambda{|x, y| "#{y[:value]} is already present" }}
    validates :first_name, :email, :full_phone_number, presence: true
    validates :full_phone_number, uniqueness: { message: lambda{|x, y| "#{y[:value]} is already present" }}
    validates :user_name, uniqueness: true, allow_blank: true

    # before_save :email_or_full_phone_number_must_exit
    after_create :update_custom_id, :create_profile, :send_temporary_password
    belongs_to :role, class_name: "BxBlockRolesPermissions::Role", optional: true
    has_one :profile, class_name: "BxBlockProfile::Profile", dependent: :destroy
    has_many :vendor, class_name: "AccountBlock::Vendor", dependent: :destroy
    has_many :departments, class_name: 'BxBlockHrms::Department'
    belongs_to :department, class_name: 'BxBlockHrms::Department', optional: true
    has_many :designations, class_name: 'BxBlockHrms::Designation'
    belongs_to :designation, class_name: 'BxBlockHrms::Designation', optional: true
    has_many :account_passwords, class_name: "AccountBlock::AccountPassword"
    has_many :relative_accounts, class_name: "AccountBlock::RelativeAccount", as: :relative_accountable
    has_many :role_created_bies, class_name: "BxBlockRolesPermissions::RoleCreatedBy", as: :role_created_byable
    has_many :individual_customers, class_name: "BxBlockProfile::IndividualCustomer", dependent: :destroy
    has_one  :business_customer, class_name: "BxBlockProfile::BusinessCustomer", dependent: :destroy
    has_one :contact_detail, class_name: "BxBlockAddress::ContactDetail", dependent: :destroy
    scope :by_role, -> (role) { includes(:role).where(roles: {name: role}) }
    scope :employees, -> { includes(:role).where(roles: {name: "Employee"}) }
    has_many :payment_terms, class_name: "BxBlockProfile::PaymentTerm", dependent: :destroy
    has_many :items, class_name: 'BxBlockContentmanagement::Item', dependent: :destroy
    has_many :recurring_expenses, class_name: "BxBlockExpensetracking::RecurringExpense", foreign_key: :expense_id

    delegate :name, to: :role, prefix: true, allow_nil: true

    accepts_nested_attributes_for :profile
    enum customer_type: ["individual","business"]

    def name
      self.first_name.present? ? self.first_name : ""
    end
    private

    def update_custom_id
      self.custom_id = ("000000" + self.id.to_s).last(6)
      self.save
    end

    def send_temporary_password
      unless self.lms_role == "admin"
        AccountBlock::UserMailer.with(account: self).send_password.deliver
      end
    end

    def create_profile
      unless self.profile.present?
        BxBlockProfile::Profile.create(account_id: self.id)
      end
    end

    def self.import(file, current_user)
      invaild_data = []
      CSV.foreach(file.path, headers: true) do |row|
        role = BxBlockRolesPermissions::Role.find_by("name ILIKE ?", row[1].to_s.strip)
        if row[4].to_s == "Active"
          status = true
        else
          status = false
        end
        if Phonelib.valid?(row[3])
          if role.present?
            # begin
              user = Account.create(first_name: row[0], role_id: role&.id, email: row[2], full_phone_number: row[3], activated: status)
            # rescue => e
            #   invaild_data << row.to_h
            #   next
            # end
            if user.errors.any?
              if user.errors.messages[:email].present?
                if user.errors.messages[:email].join("") == "can't be blank"
                  invaild_data << row.to_h.merge("Error" => "Email" +" "+ user.errors.messages[:email].join(""))
                else
                  invaild_data << row.to_h.merge("Error" => "Email" +" "+ user.errors.messages[:email].join(""))
                end
              elsif user.errors.messages[:full_phone_number].present?
                if user.errors.messages[:full_phone_number].join("") == "can't be blank"
                  invaild_data << row.to_h.merge("Error" => "Phone" +" "+ user.errors.messages[:full_phone_number].join(""))
                else
                  invaild_data << row.to_h.merge("Error" => "Phone" +" "+ user.errors.messages[:full_phone_number].join(""))
                end
              else
                if user.errors.messages[:first_name].join("") == "can't be blank"
                  invaild_data << row.to_h.merge("Error" => "Name" +" "+ user.errors.messages[:first_name].join(""))
                else
                  invaild_data << row.to_h.merge("Error" => "Name" +" "+ user.errors.messages[:first_name].join(""))
                end
              end
            else
              account_password = user.account_passwords.new(password: user.temporary_password)
              account_password.save
              AccountBlock::RelativeAccount.create(relative_accountable_id:current_user.id, relative_accountable_type: "AccountBlock::Account", account_id: user.id )
            end
          else
            invaild_data << row.to_h.merge("Error" => "Role must exist")
          end
        else
          invaild_data << row.to_h.merge("Error" => "Invalid phone number")
        end
      end
      invaild_data
    end

    def self.to_csv
      attributes = %w{Id Name Role Email Phone Status }
      CSV.generate(headers: true) do |csv|
        csv << attributes
        all.each do |account|
          csv << [account.custom_id, account.first_name&.capitalize, account&.role&.name, account.email, account.full_phone_number, account.activated ? "Active" : "Inactive"]
        end
      end
    end

    def self.to_sample_csv
      attributes = %w{Name Role Email Phone Status }
      CSV.generate(headers: true) do |csv|
        csv << attributes
        all.each do |account|
          csv << [account.first_name, account&.role&.name, account.email, account.full_phone_number, account.activated ? "Active" : "Inactive"]
        end
      end
    end

    def parse_full_phone_number
      phone = Phonelib.parse(full_phone_number)
      self.full_phone_number = phone.sanitized
      self.country_code      = phone.country_code
      self.phone_number      = phone.raw_national
    end

    def set_temporary_password
      if self.new_record? && self.password.nil?
        password = SecureRandom.hex(4)
        # password = "password"
        self.password = password
        self.temporary_password = password
      end
    end

    def temporary_password_to_encrypt
      encrypted_data = AESCrypt.encrypt(self.temporary_password, ENV['ENCRYPT_KEY'])
      self.temporary_password = encrypted_data
    end

    def email_or_full_phone_number_must_exit
      unless full_phone_number.present? || email.present?
        errors.add(:full_phone_number, "Please enter full phone number or email")
        errors.add(:email, "Please enter email or full phone number")
      end
      
    end

    def valid_phone_number
      unless Phonelib.valid?(full_phone_number)
        errors.add(:full_phone_number, "Invalid or Unrecognized Phone Number")
      end
    end

  end
end
