module AccountBlock
  class Section < AccountBlock::ApplicationRecord
    self.table_name = :sections
    validates_presence_of :name, { message: "Name can't be blank" }
	  validates_uniqueness_of :name, case_sensitive: false, message: lambda{|x, y| "#{y[:value]} is already present" }
    has_many :vendors, class_name: "AccountBlock::AccountTd", dependent: :destroy
  end 
end 