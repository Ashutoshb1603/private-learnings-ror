module BxBlockFine
  class Fine < BxBlockFine::ApplicationRecord
    require 'csv'
    self.table_name = :fines
    CSV_HEADERS = %w[id name fine_category day duration fine_amount mode sub_fine_name sub_fine_category sub_fine_day sub_fine_duration sub_fine_amount sub_fine_mode]

    validates_uniqueness_of :name, case_sensitive: false, message: lambda{|x, y| "#{y[:value]} is already present" }
    validates_presence_of :name, { message: "Fine name can't be blank" }
    validates_presence_of :fine_category, { message: "Category can't be blank" }
    validates_presence_of :fine_amount, { message: "Amount can't be blank" }
    validates_presence_of :mode, { message: "Mode can't be blank" }
   
    enum duration: { 'days' => 'days', 'week' => 'week', 'month' => 'month' }
    enum mode: { 'amount' => 'amount', 'percentage' => 'percentage' }
    enum fine_category: %i[late_fine miscellaneous]

    has_many   :sub_fines,   class_name: "Fine", foreign_key: "fine_id", dependent: :destroy
    belongs_to :parent_fine, class_name: "Fine", foreign_key: "fine_id", optional: true

    accepts_nested_attributes_for :sub_fines

    after_create :update_custom_id

    def self.import(file)
      invaild_data = []
      CSV.foreach(file.path, headers: true) do |row|
        keys = %w[sub_fine_name sub_fine_category sub_fine_day sub_fine_duration sub_fine_amount sub_fine_mode]
        begin
          if keys.any? { |key| row[key].present? }
            fine = Fine.create_with(row.to_h.except("name", "sub_fine_name", "sub_fine_category", "sub_fine_day", "sub_fine_duration", "sub_fine_amount", "sub_fine_mode")).find_or_create_by!(name: row["name"])

            raise "Fine category should be 'late_fine' to create sub fines" if fine.miscellaneous?
            fine.sub_fines.create!(name: row["sub_fine_name"], fine_category: row["sub_fine_category"], day: row["sub_fine_day"], duration: row["sub_fine_duration"], fine_amount: row["sub_fine_amount"], mode: row["sub_fine_mode"])
          else
            create!(row.to_h.except("name", "sub_fine_name", "sub_fine_category", "sub_fine_day", "sub_fine_duration", "sub_fine_amount", "sub_fine_mode"))
          end
        rescue => e
          invaild_data << row.to_h.merge("errors" => e)
        end
      end
      invaild_data
    end

    def update_custom_id
      self.custom_id = ('000000' + id.to_s).last(6)
      save
    end

    def has_parent?
      self.parent_fine.present?
    end

    def self.to_csv
      fines_attributes = %w[id name fine_category day duration fine_amount mode]
      CSV.generate(headers: true) do |csv|
        csv << CSV_HEADERS
        includes(:sub_fines).each do |fine|
          next if fine.has_parent?
          if fine.sub_fines.present?
            fine.sub_fines.each do |sub_fine|
              csv << fines_attributes.map { |attr| fine.send(attr) } + (fines_attributes - ['id']).map { |attr| sub_fine.send(attr) }
            end
          else
            csv << fines_attributes.map { |attr| fine.send(attr) }
          end
        end
      end
    end
  end
end
