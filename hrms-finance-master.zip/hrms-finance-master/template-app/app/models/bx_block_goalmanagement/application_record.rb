module BxBlockGoalmanagement
  class ApplicationRecord < BuilderBase::ApplicationRecord
    self.abstract_class = true
  end
end
