module BxBlockGstSetting
	class GstSetting < ApplicationRecord
    self.table_name = :gst_settings
		validates :gst_number, presence: true, uniqueness: true, :length => {:maximum => 15 }
	end
end