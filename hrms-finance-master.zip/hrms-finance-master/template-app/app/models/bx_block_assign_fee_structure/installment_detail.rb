module BxBlockAssignFeeStructure
	class InstallmentDetail < BxBlockAssignFeeStructure::ApplicationRecord
		self.table_name = :installment_details
		belongs_to :fine, class_name: "BxBlockFine::Fine", optional: true
		belongs_to :installment, class_name: "BxBlockInstallment::Installment"
	end
end
