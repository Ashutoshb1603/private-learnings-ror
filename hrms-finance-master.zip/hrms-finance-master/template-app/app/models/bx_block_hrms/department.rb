module BxBlockHrms
  class Department < BxBlockHrms::ApplicationRecord
    require 'csv'
    self.table_name = :departments
    belongs_to :creator, class_name: 'AccountBlock::Account', foreign_key: :creator_id
    has_many :employees, class_name: 'AccountBlock::Account'
    has_many :sub_departments, class_name: 'Department'
    belongs_to :parent_department, class_name: 'Department'
    validates_presence_of :name

    delegate :name, to: :parent_department, prefix: true, allow_nil: true

    def self.import(file, creator_id)
      CSV.foreach(file.path, headers: true) do |row|
        department_id = find_by(name: row[3]).id
        create(name: row[0], lead: row[1], email: row[2], creator_id: creator_id, parent_department_id: department_id)
      end
    end

    def self.to_csv
      attributes = %w[id name lead email added_by added_date modified_by, parent_department]
      CSV.generate(headers: true) do |csv|
        csv << attributes
        all.each do |department|
          csv << [department.id, department.name, department.lead, department.email, department&.creator&.role.name,
                  department.created_at, department.updated_at, department&.parent_department_name]
        end
      end
    end
  end
end
