module BxBlockHrms
  class Designation < ApplicationRecord
    self.table_name = :designations
    belongs_to :creator, class_name: 'AccountBlock::Account', foreign_key: :creator_id
    has_many :employees, class_name: 'AccountBlock::Account'
    validates_presence_of :name

    def self.import(file, creator_id)
      CSV.foreach(file.path, headers: true) do |row|
        Designation.create! row.to_hash.merge(creator_id: creator_id)
      end
    end

    def self.to_csv
      attributes = %w[id name added_by added_date modified_by]
      CSV.generate(headers: true) do |csv|
        csv << attributes
        all.each do |designation|
          csv << [designation.id, designation.name, designation&.creator&.role&.name,
                  designation.created_at, designation.updated_at]
        end
      end
    end
  end
end
