module BxBlockProfile
	class SecondaryDetail < ApplicationRecord
		self.table_name = :secondary_details
		belongs_to :individual_customer, class_name: "BxBlockProfile::IndividualCustomer"
	end
end
