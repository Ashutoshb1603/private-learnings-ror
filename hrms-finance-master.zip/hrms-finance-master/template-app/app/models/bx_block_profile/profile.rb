module BxBlockProfile
	class Profile < ApplicationRecord
		self.table_name = :profiles
		# validates :email, presence: true
		belongs_to :account, class_name: "AccountBlock::Account"
		has_one_attached :profile_pic
	end
end
