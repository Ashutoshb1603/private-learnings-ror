module BxBlockProfile
	class BusinessCustomer < ApplicationRecord
		self.table_name = :business_customers

		enum tax_preference: ["taxable","tax_exempt"]
		belongs_to :account, class_name: "AccountBlock::Account"
		belongs_to :gst_treatment, class_name: "BxBlockProfile::GstTreatment"
		belongs_to :payment_term, class_name: "BxBlockProfile::PaymentTerm",optional: true
        has_many :recurring_expenses, class_name: "BxBlockExpensetracking::RecurringExpense", as: :customer
	    
	    validates :email, presence: true, uniqueness: { message: "Email has already exist in Business Customer"}
	    validates :contact_number, presence: true, uniqueness: { message: "Contact Number has already exist in Business Customer"}
	    validates :website_url, presence: true, uniqueness: { message: "Website Url has already exist in Business Customer"}
   	    validate :validate_email

    def self.to_csv
      attributes = ["id", "company_name", "primary_contact", "email", "contact_number", "website_url", "billing_street", "billing_address", "shipping_street", "shipping_address", "gstin_number", "place_of_supply", "tax_preference", "remarks", "account_id", "created_at", "updated_at", "gst_treatment_id", "payment_term_id", "country_code"]
      CSV.generate(headers: true) do |csv|
        csv << attributes
        all.each do |customer|
          csv <<  [customer.id, customer.company_name, customer.primary_contact, customer.email, customer.contact_number, customer.website_url, customer.billing_street, customer.billing_address, customer.shipping_street, customer.shipping_address, customer.gstin_number, customer.place_of_supply, customer.tax_preference, customer.remarks, customer.account_id, customer.created_at, customer.updated_at, customer.gst_treatment_id, customer.payment_term_id, customer.country_code]
        end
      end
    end

    def self.import(file)
      CSV.foreach(file.path, headers: true) do |row|
        BusinessCustomer.create row.to_hash 
      end
    end

    private

	  def validate_email
	   	individual_customer = IndividualCustomer.where(email: self.email).last
	   	if individual_customer.present?
	   	 	 errors.add(:email, 'Email already exist in Individual customer')
	   	end
	  end

	end
end
