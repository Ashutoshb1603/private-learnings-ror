module BxBlockProfile
	class IndividualCustomer < ApplicationRecord
       self.table_name = :individual_customers

       validates :email, presence: true, uniqueness: { message: "Email has already exist in Individual Customer"}
       validates :phone_number, presence: true, uniqueness: { message: "Phone Number has already exist in Individual Customer"}
       validates_presence_of :first_name, :last_name, :gender, :relationships, :phone_number, :billto
       validate :validate_email

       enum gender: ["Male","Female", "other"]
       enum relationships: ["Father", "Mother","Guardian"]
       enum billto: ["primary","secondary"]

       has_one :contact_detail, class_name: "BxBlockAddress::ContactDetail", dependent: :destroy
       has_many :secondary_details, class_name: "BxBlockProfile::SecondaryDetail", dependent: :destroy
       belongs_to :account, class_name: "AccountBlock::Account"
      has_many :recurring_expenses, class_name: "BxBlockExpensetracking::RecurringExpense", as: :customer

        def self.to_csv
          attributes = ["id", "first_name", "last_name", "gender", "relationships", "phone_number", "email", "remarks", "billto", "account_id", "created_at", "updated_at", "country_code"]
          CSV.generate(headers: true) do |csv|
            csv << attributes
            all.each do |customer|
              csv <<  [customer.id, customer.first_name, customer.last_name, customer.gender, customer.relationships, customer.phone_number, customer.email, customer.remarks, customer.billto, customer.account_id, customer.created_at, customer.updated_at, customer.country_code]
            end
          end
        end

        def self.import(file)
          CSV.foreach(file.path, headers: true) do |row|
            IndividualCustomer.create row.to_hash 
          end
        end

       private

       def validate_email
       	 business_customers = BusinessCustomer.where(email: self.email).last
       	 if business_customers.present?
       	 	 errors.add(:email, 'Email already exist in Business customer')
       	 end
       end
	end
end
