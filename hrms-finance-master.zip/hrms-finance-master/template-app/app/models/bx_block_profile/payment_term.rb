module BxBlockProfile
	class PaymentTerm < ApplicationRecord
		self.table_name = :payment_terms
		belongs_to :account, class_name: "AccountBlock::Account"
		has_many :business_customers, class_name: "BxBlockProfile::BusinessCustomer", dependent: :destroy
		has_many :vendors, class_name: "AccountBlock::Vendor", dependent: :destroy
		validates_presence_of :term_name, { message: "Term name can't be blank" }
		validates_uniqueness_of :term_name, case_sensitive: false, message: lambda{|x, y| "#{y[:value]} is already present" }
	end
end
