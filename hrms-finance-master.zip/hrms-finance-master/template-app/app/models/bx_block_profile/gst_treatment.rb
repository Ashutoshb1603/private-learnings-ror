module BxBlockProfile
	class GstTreatment < ApplicationRecord
		self.table_name = :gst_treatments
		has_many :business_customers, class_name: "BxBlockProfile::BusinessCustomer", dependent: :destroy
		has_many :vendors, class_name: "AccountBlock::Vendor", dependent: :destroy
		has_many :recurring_expenses, class_name: 'BxBlockExpensetracking::RecurringExpense'
	end
end
