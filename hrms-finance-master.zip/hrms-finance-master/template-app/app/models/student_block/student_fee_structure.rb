module StudentBlock
	class StudentFeeStructure < ApplicationRecord
		self.table_name = :student_fee_structures
		belongs_to :fee_structure, class_name: "BxBlockFeeStructure::FeeStructure"

		enum status: {pending: "pending", assigned: "assigned"} 
	end
end
