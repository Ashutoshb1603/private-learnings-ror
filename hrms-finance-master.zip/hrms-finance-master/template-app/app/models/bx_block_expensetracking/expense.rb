module BxBlockExpensetracking
  class Expense < BxBlockExpensetracking::ApplicationRecord
    self.table_name = :expenses
    belongs_to :vendor, class_name: "AccountBlock::Vendor" ,foreign_key: :vendor_id
     has_one_attached :expense_recipt
  end
end
