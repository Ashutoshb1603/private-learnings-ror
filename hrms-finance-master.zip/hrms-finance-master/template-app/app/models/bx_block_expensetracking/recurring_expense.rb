module BxBlockExpensetracking
  class RecurringExpense < BxBlockExpensetracking::ApplicationRecord
    self.table_name = :recurring_expenses
    validate :validate_percentage

    belongs_to :vendor, class_name: "AccountBlock::Vendor" ,foreign_key: :vendor_id
    belongs_to :customer, :polymorphic => true
    belongs_to :tax, class_name: 'BxBlockTax::Tax', foreign_key: :tax_id, optional: true
    belongs_to :gst_treatment, class_name: 'BxBlockProfile::GstTreatment', foreign_key: :gst_treatment_id, optional: true
    enum repeat_every: { "Weeks" => "weeks", "Days" => "days", "Months" => 'months', 'Years' => 'years'}
    belongs_to :reverse_charge_account, class_name: "BxBlockAcademicAccount::AcademicAccount" ,foreign_key: :reverse_charge_account_id, optional: true
    belongs_to :expense_account, class_name: "AccountBlock::Account", foreign_key: :expense_id
    has_many :recurring_expense_histories, class_name: 'BxBlockExpensetracking::RecurringExpenseHistory', dependent: :destroy
    has_many :expense_histories, class_name: 'BxBlockExpensetracking::ExpenseHistory', dependent: :destroy
    # before_save :set_last_expense_date

    enum reverse_charge_mode: %i[amount percentage]

    def store_history(message)
      self.recurring_expense_histories.create(description: message)
    end

    def self.to_csv
      attributes = %w{id  expense_type  sac  hsn  expense_name  paid_through  currency  ammount  repeat_every  start_date  end_date  expense_id  vendor_id  customer_id  tax  source_of_supply  destination_of_supply  gst_treatment  reverse_charge_account  reverse_charge  comment  ammount_is  created_at  updated_at  gst_in  stop  bill_every_count  bill_every_option  reason_for_exemption }
      CSV.generate(headers: true) do |csv|
        csv << attributes
        all.each do |expense|
          csv << [expense.id,expense.expense_type,expense.sac,expense.hsn,expense.expense_name,expense.paid_through,expense.currency,expense.ammount,expense.repeat_every,expense.start_date,expense.end_date,expense.expense_id,expense.vendor_id,expense.customer_id,expense.tax,expense.source_of_supply,expense.destination_of_supply,expense.gst_treatment,expense.reverse_charge_account,expense.reverse_charge,expense.comment,expense.ammount_is,expense.created_at,expense.updated_at,expense.gst_in,expense.stop,expense.bill_every_count,expense.bill_every_option,expense.reason_for_exemption]
        end
      end
    end

    def self.import(file)
      CSV.foreach(file.path, headers: true) do |row|
        BxBlockExpensetracking::RecurringExpense.create row.to_hash 
      end
    end

    def set_last_expense_date
      self.last_expense_date = self.start_date
      set_last_and_next_expense_data
    end  

    def set_last_and_next_expense_data
      self.next_expense_date = self.last_expense_date + self.repeat_count.to_i.send(self.repeat_every.downcase.to_s)
    end

    private
      def validate_percentage
        if reverse_charge_mode == 'percentage' && reverse_charge > 100
          errors.add(:reverse_charge, "Percentage should be less than 100%")
        end
      end

  end
end
