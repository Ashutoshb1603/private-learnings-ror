module BxBlockExpensetracking
	class RecurringExpenseHistory < ApplicationRecord
    self.table_name = :recurring_expense_histories

    belongs_to :recurring_expense, class_name: 'RecurringExpense'
	end	
end
