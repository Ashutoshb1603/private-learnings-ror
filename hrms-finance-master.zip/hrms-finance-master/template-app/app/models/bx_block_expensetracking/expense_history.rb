module BxBlockExpensetracking
	class ExpenseHistory < ApplicationRecord
		self.table_name = :expense_histories

		# belongs_to :account, class_name: "AccountBlock::Account"
		belongs_to :recurring_expense, class_name: 'BxBlockExpensetracking::RecurringExpense'
	end
end
