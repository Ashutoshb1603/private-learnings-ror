module BxBlockAddress
  class Location < ApplicationRecord
    self.table_name = :locations
    has_many :employees, class_name: "AccountBlock::Account"
    belongs_to :creator, class_name: "AccountBlock::Account"
  end
end
