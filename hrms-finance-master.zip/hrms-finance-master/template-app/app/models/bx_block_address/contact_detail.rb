module BxBlockAddress
	class ContactDetail < ApplicationRecord
    self.table_name = :contact_details
    belongs_to :individual_customer, class_name: "BxBlockProfile::IndividualCustomer"
    validates :street_address,:address, :city, :state, :pin_code, :country, :email, :country_code, :phone_number, :billing_street,
     :billing_address, :shiping_street, :shiping_address, presence: true
  end
end
