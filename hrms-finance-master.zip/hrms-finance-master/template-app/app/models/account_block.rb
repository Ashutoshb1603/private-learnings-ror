module AccountBlock
  def self.table_name_prefix
    'account_block_'
  end
end
