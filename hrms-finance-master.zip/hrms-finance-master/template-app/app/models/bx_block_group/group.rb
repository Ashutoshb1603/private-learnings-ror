module BxBlockGroup
	class Group < BxBlockGroup::ApplicationRecord
    self.table_name = :groups
		belongs_to :fee_structure, class_name: "BxBlockFeeStructure::FeeStructure"
	end
end