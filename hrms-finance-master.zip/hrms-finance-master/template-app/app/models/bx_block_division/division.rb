module BxBlockDivision
	class Division < BxBlockDivision::ApplicationRecord
		self.table_name = :divisions
		validates :title, presence: true
		belongs_to :academic_class, class_name: "BxBlockAcademicClass::AcademicClass"
		has_many :students, class_name: "BxBlockStudent::Student", dependent: :destroy
		has_many :fee_structures, class_name: "BxBlockFeeStructure::FeeStructure", dependent: :nullify
	end
end
