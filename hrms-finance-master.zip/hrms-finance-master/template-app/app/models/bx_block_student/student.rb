module BxBlockStudent
	class Student < BxBlockStudent::ApplicationRecord
		self.table_name = :students
		enum gender: [:male, :female, :others]
		validates :first_name, presence: true
    validates :last_name, presence: true
    validates :father_name, presence: true
    validates :dob, presence: true
    validates :gender, presence: true
    after_create :update_custom_id
    belongs_to :division, class_name: "BxBlockDivision::Division"
		# before_create :set_registration_no
		# private
		# def set_registration_no
		# 	self.registration_no = generate_registration_no.upcase
		# end

		# def generate_registration_no
		# 	loop do
		#   	set_registration_no = SecureRandom.hex(4)
		#   	break set_registration_no unless self.class.where(set_registration_no: set_registration_no).exists?
		# 	end
		# end

		def update_custom_id
	    self.custom_id = ("000000" + self.id.to_s).last(6)
	    self.save
    end

	end
end
