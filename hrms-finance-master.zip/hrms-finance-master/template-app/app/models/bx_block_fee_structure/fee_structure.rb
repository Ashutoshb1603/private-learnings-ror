module BxBlockFeeStructure
	class FeeStructure < BxBlockFeeStructure::ApplicationRecord
		self.table_name = :fee_structures
		after_create :update_custom_id

		has_many :sub_fee_structures, class_name: "BxBlockFeeStructure::SubFeeStructure", dependent: :destroy
		has_many :fee, through: :sub_fee_structures
		accepts_nested_attributes_for :sub_fee_structures, :allow_destroy => true
		belongs_to :academic_year, class_name: "BxBlockAcademicYear::AcademicYear"#, optional: true
		has_many :student_fee_structures, class_name: "StudentBlock::StudentFeeStructure", dependent: :destroy
		# belongs_to :academic_class, class_name: "BxBlockAcademicClass::AcademicClass", optional: true
		# belongs_to :division, class_name: "BxBlockDivision::Division", optional: true
		# belongs_to :installment, class_name: "BxBlockInstallment::Installment", optional: true
		# belongs_to :fine, class_name: "BxBlockFine::Fine", optional: true
		has_one :group, class_name: "BxBlockGroup::Group", dependent: :destroy
		has_many :installments, class_name: "BxBlockInstallment::Installment", dependent: :destroy
		# has_many :installment_details, class_name: "BxBlockAssignFeeStructure::InstallmentDetail", dependent: :destroy
		# validates :due_date, presence: true
		validates :name, presence: true
		scope :name_records, -> { self.where("name is not null").where.not(name: "") }

		accepts_nested_attributes_for :sub_fee_structures, allow_destroy: true
		accepts_nested_attributes_for :installments, allow_destroy: true
		accepts_nested_attributes_for :group, allow_destroy: true

		def total_amount
			sub_fee_structures.map { |sfs| sfs.amount_after_concession.nil? ? sfs.fee.amount : sfs.amount_after_concession }.sum
		end

		def update_custom_id
			self.custom_id = ("000000" + self.id.to_s).last(6)
      		self.save
		end 

		def self.import(file)
			CSV.foreach(file.path, headers: true) do |row|
				FeeStructure.create! row.to_hash
			end
		end

		def self.to_csv
	    attributes = %w[id fee_structure_name academic_year class division fee_type]
	    CSV.generate(headers: true) do |csv|
	      csv << attributes
	      all.each do |fs|
	        csv << [fs.id, fs.name, fs.academic_year.year, fs.grade, fs.division, fs.fee_type]
	      end
	    end
	  end
	end
end