module BxBlockFeeStructure
	class SubFeeStructure < BxBlockFeeStructure::ApplicationRecord
		self.table_name = :sub_fee_structures
		belongs_to :fee_structure, class_name: "BxBlockFeeStructure::FeeStructure"
		belongs_to :fee, class_name: "BxBlockFee::Fee"
		belongs_to :fee_concession, class_name: "BxBlockFee::FeeConcession",  optional: true

 	  accepts_nested_attributes_for :fee
 	  after_update :calcu_amount_after_concession

 	  def calcu_amount_after_concession
		  if fee_concession_id.present? && fee_concession.amount.positive?	
		  	if fee_concession.percentage?
		  		total_amount_after_concession = fee.amount - fee.amount * fee_concession.amount/100
		  	else
		  		total_amount_after_concession = fee.amount - fee_concession.amount
		  	end 
		  	self.update_column(:amount_after_concession, total_amount_after_concession)
		  end
 	  end
	end
end