module BxBlockTax
	class Tax < BxBlockTax::ApplicationRecord
		self.table_name = :taxes

		has_many :recurring_expenses, class_name: 'BxBlockExpensetracking::RecurringExpense'
    validates_uniqueness_of :name, case_sensitive: false, message: lambda{|x, y| "#{y[:value]} is already present" }
    validates_presence_of :name, { message: "Tax name can't be blank" }
		validates_presence_of :tax_percentage, { message: "Tax % can't be blank" }
    validate :validate_gst_type
		before_create :check_tax_type
		after_create :update_custom_id
		enum tax_type: [:SGST, :CGST, :IGST, :UTGST]

		def update_custom_id
      self.custom_id = ("000000" + self.id.to_s).last(6)
      self.save
    end

    def self.import(file)
			invaild_data = []
			CSV.foreach(file.path, headers: true) do |row|
				tax = Tax.create(name: row[0], tax_percentage: row[1], is_gst: row[2], tax_type: row[3], description: row[4])
		 		if tax.errors.any?
		 			if tax.errors.messages[:name].present?
	          invaild_data << row.to_h.merge("Error" => "Tax name" +" "+ tax.errors.messages[:name].join(""))
	        elsif tax.errors.messages[:tax_percentage].present?
            invaild_data << row.to_h.merge("Error" => "Tax Parcentage" +" "+ tax.errors.messages[:tax_percentage].join(""))
          elsif tax.errors.messages[:tax_type].present?
          	invaild_data << row.to_h.merge("Error" => tax.errors.messages[:tax_type].join(""))
	        end
        else
        end
			end
			invaild_data
		end

		def self.to_csv
	    attributes = ["ID", "Tax Name", "Tax%", "Is GST?" "Tax Type", "Description"]
	    CSV.generate(headers: true) do |csv|
	      csv << attributes
	      all.each do |tax|
	        csv << [tax&.id, tax&.name, tax&.tax_percentage, tax&.is_gst, tax&.tax_type, tax&.description]
	      end
	    end
	  end

	  def self.to_sample_csv
	    attributes = ["Tax Name", "Tax%", "Is GST?", "Tax Type", "Description"]
	    CSV.generate(headers: true) do |csv|
	      csv << attributes
	      all.each do |tax|
	        csv << [tax&.name, tax&.tax_percentage, tax&.is_gst, tax&.tax_type, tax&.description]
	      end
	    end
	  end

	  private

	  def validate_gst_type
	  	if is_gst == true
	  		errors.add(:tax_type, "Tax type must be present") unless tax_type.present?
	  	end	
	  end	

	  def check_tax_type
	  	self.tax_type = nil if self.is_gst == false
	  end 	

	end
end
