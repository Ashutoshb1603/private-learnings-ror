module BxBlockContentmanagement
	class Unit < ApplicationRecord
    self.table_name = :units
    belongs_to :account, class_name: "AccountBlock::Account"
    has_many :items, class_name: "BxBlockContentmanagement::Item", dependent: :destroy
	end
end
