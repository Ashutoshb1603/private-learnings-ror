module BxBlockContentmanagement
	class Item < ApplicationRecord
		self.table_name = :items
	  belongs_to :account, class_name: "AccountBlock::Account"
	  belongs_to :unit, class_name: "BxBlockContentmanagement::Unit"
	  has_many :item_informations, class_name: "BxBlockContentmanagement::ItemInformation", dependent: :destroy
	  enum item_type: ["Goods", "Services"]

	  accepts_nested_attributes_for :item_informations

	  def self.to_csv
      attributes = %w[hsn_or_sac name price unit]
      CSV.generate(headers: true) do |csv|
        csv << attributes
        all.each do |item|
          csv << [item.hsn_or_sac, item.name, item.item_informations.first.price, item.unit.name]
        end
      end
    end  

     def self.import(file, current_user)
      invaild_data = []
      CSV.foreach(file.path, headers: true) do |row|
        unit_id = Unit.find_by('name ILIKE ?', row['unit'])&.id
        begin
          current_user.items.create!(hsn_or_sac: row['hsn_or_sac'], name: row['name'], unit_id: unit_id, item_informations_attributes: [ {price: row['price']} ])
        rescue => e
          invaild_data << row.to_h.merge('errors' => e)
        end
      end
      invaild_data
    end

	end
end