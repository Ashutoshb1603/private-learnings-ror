module BxBlockContentmanagement
	class ItemInformation < ApplicationRecord
		self.table_name = :item_informations
		belongs_to :item, class_name: "BxBlockContentmanagement::Item"
		enum information_type: ["Sales", "Purchase"]
	end
end
