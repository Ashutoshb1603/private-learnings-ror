class BxBlockAdminConsole::AdminUser < ApplicationRecord
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  devise :database_authenticatable,
         :recoverable, :rememberable, :validatable
  has_many :relative_accounts, class_name: "AccountBlock::RelativeAccount", as: :relative_accountable
  has_many :role_created_bies, class_name: "BxBlockRolesPermissions::RoleCreatedBy", as: :role_created_byable
  
end
