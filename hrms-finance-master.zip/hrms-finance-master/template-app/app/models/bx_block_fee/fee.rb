module BxBlockFee
	class Fee < BxBlockFee::ApplicationRecord
		require 'csv'
		self.table_name = :fees
		after_create :update_custom_id
		scope :order_by_created, -> { order(created_at: :desc) }
    validates_uniqueness_of :name, case_sensitive: false, message: lambda{|x, y| "#{y[:value]} is already present" }
    validates_presence_of :name, { message: "Fee name can't be blank" }
    validates_presence_of :valid_until, { message: "Fee valid until can't be blank" }
    validates_presence_of :amount, { message: "Fee amount can't be blank" }
    validate :validate_amount
		belongs_to :academic_account, class_name: "BxBlockAcademicAccount::AcademicAccount", optional: true
		has_many :sub_fee_structures, class_name: "BxBlockFeeStructure::SubFeeStructure", dependent: :destroy
		has_many :fee_structures, through: :sub_fee_structures
		
    delegate :name, to: :academic_account, prefix: :academic_account, allow_nil: true

    	# default_scope -> { order(id: :desc) } 

		def self.import(file)
			invaild_data = []
      tax_ids = []
			CSV.foreach(file.path, headers: true) do |row|
				academic_account = BxBlockAcademicAccount::AcademicAccount.find_by("name ILIKE ?", row[4].to_s.strip)
				if row[2].present?
					row[2].split(",").each do |tax_name|
						tax = BxBlockTax::Tax.find_by('name ILIKE ?', tax_name.strip)
						if tax.present?
							tax_ids << tax.id
						end
					end
				end
				fee = Fee.create(name: row[0], valid_until: row[1], tax_ids: tax_ids, amount: row[3], academic_account_id: academic_account.present? ? academic_account.id : nil)
				if fee.errors.messages[:name].present?
					invaild_data << row.to_h.merge("Error" => fee.errors.messages[:name].join(""))
				elsif fee.errors.messages[:valid_until].present?
					invaild_data << row.to_h.merge("Error" => fee.errors.messages[:valid_until].join(""))
				elsif fee.errors.messages[:amount].present?
					invaild_data << row.to_h.merge("Error" => fee.errors.messages[:amount].join(""))
				end
			end
			invaild_data
		end

		def update_custom_id
	      self.custom_id = ("000000" + self.id.to_s).last(6)
	      self.save
	  end

		def self.to_sample_csv
			attributes = ['Fee Name', 'Valid Until', 'Tax%', 'Amount', 'Account']
			CSV.generate(headers: true) do |csv|
				csv << attributes
				all.each do |fee|
					csv << [fee.name, fee.valid_until.to_date, fee.taxs_name, fee.amount, fee.academic_account_name]
				end
			end
		end

		def self.to_csv
	    attributes = ['ID', 'Fee Name', 'Valid Until', 'Tax%', 'Amount', 'Account']
	    CSV.generate(headers: true) do |csv|
	      csv << attributes
	      all.each do |fee|
	        csv << [fee.id, fee.name, fee.valid_until.to_date, fee.taxs, fee.amount, fee.academic_account_name]
	      end
	    end
	  end

	  def taxs
			# BxBlockTax::Tax.where(id: self.tax_ids).pluck(:name, :tax_percentage).join(", ")
			tax_value = []
			taxes = BxBlockTax::Tax.where(id: self.tax_ids)
			if taxes.any?
				taxes.each do |tax|
					tax_value << "#{tax.name} #{tax.tax_percentage}%"
				end
			end
			tax_value.join(", ")
	  end

	  def taxs_name
			tax_value = []
			taxes = BxBlockTax::Tax.where(id: self.tax_ids)
			if taxes.any?
				taxes.each do |tax|
					tax_value << "#{tax.name}"
				end
			end
			tax_value.join(", ")
	  end

	  def validate_amount
	  	unless amount.to_f > 0
	  		errors.add(:amount, "Amount should be more than 0.")
	  	end
	  end
	end
end
