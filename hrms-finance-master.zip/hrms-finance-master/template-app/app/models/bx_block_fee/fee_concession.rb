module BxBlockFee
  class FeeConcession < BxBlockFee::ApplicationRecord
    require 'csv'
    self.table_name = :fee_concessions
    validates :name, :valid_until, :amount, presence: true
    validates_uniqueness_of :name, case_sensitive: false, message: lambda{|x, y| "#{y[:value]} is already present" }
    validate :validate_percentage

    after_create :update_custom_id
    
    has_one :sub_fee_strucher, class_name: 'BxBlockFeeStructure::SubFeeStructure'
    belongs_to :fee_concession_type, class_name: 'BxBlockFee::FeeConcessionType'

    enum mode: %i[amount percentage]

    delegate :name, to: :fee_concession_type, prefix: :fee_concession_type

    # default_scope -> { order(id: :desc) }

    def validate_percentage
      if mode == 'percentage' && amount > 100
        errors.add(:mode, "Percentage should be less than 100%")
      end
    end

    def update_custom_id
      self.custom_id = ('000000' + id.to_s).last(6)
      save
    end

    def self.import(file)
      invaild_data = []
      CSV.foreach(file.path, headers: true) do |row|
        fee_concession_type_id = FeeConcessionType.find_by('name ILIKE ?', 
          row[0])&.id
        begin
          FeeConcession.create!(name: row[1], valid_until: row[2], mode: row[3], amount: row[4],fee_concession_type_id: fee_concession_type_id)
        rescue => e
          invaild_data << row.to_h.merge("errors" => e)
        end
      end
      invaild_data
    end

    def self.to_csv
      attributes = %w[custom_id fee_concession_type name valid_until mode amount]
      CSV.generate(headers: true) do |csv|
        csv << attributes
        all.each do |fee_concession|
          csv << [fee_concession.custom_id, fee_concession.fee_concession_type_name, fee_concession.name,
                  fee_concession.valid_until, fee_concession.mode, fee_concession.amount]
        end
      end
    end
  end
end
