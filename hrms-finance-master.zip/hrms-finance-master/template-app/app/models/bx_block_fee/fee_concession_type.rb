module BxBlockFee
  class FeeConcessionType < BxBlockFee::ApplicationRecord
    self.table_name = :fee_concession_types

    acts_as_paranoid without_default_scope: true
    validates_uniqueness_of :name, case_sensitive: false, message: lambda{|x, y| "#{y[:value]} is already present" }
    validates :name, presence: { message: "Name is already exist" }
    has_many :fee_concessions, class_name: 'BxBlockFee::FeeConcession'

    scope :not_deleted, -> { where(deleted_at: nil)}

  end
end
