module BxBlockEmailTemplate
	class EmailTemplate < BxBlockEmailTemplate::ApplicationRecord
		self.table_name = :email_templates
		validates_presence_of :name, { message: "Name can't be blank" }
		validates_presence_of :subject, { message: "Subject can't be blank" }
		has_many :installments, class_name: "BxBlockInstallment::Installment", dependent: :nullify
	end
end
