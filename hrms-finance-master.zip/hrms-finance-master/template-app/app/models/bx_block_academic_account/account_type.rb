module BxBlockAcademicAccount
	class AccountType < ApplicationRecord
		self.table_name = :account_types
		validates_uniqueness_of :name, {case_sensitive: false, message: lambda{|x, y| "#{y[:value]} is already present"}}
		validates_presence_of :name, { message: "Account type name can't be blank" }
		after_create :update_custom_id
		has_many :academic_accounts, class_name: "BxBlockAcademicAccount::AcademicAccount"
		def update_custom_id
      self.custom_id = ('000000' + id.to_s).last(6)
      self.save
    end
	end
end