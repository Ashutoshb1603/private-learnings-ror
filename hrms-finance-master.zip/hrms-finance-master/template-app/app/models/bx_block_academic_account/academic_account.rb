module BxBlockAcademicAccount
  class AcademicAccount < ApplicationRecord
    self.table_name = :academic_accounts
    scope :order_by_created, -> { order(created_at: :desc) }
    has_many :fees, class_name: "BxBlockFee::Fee"
    has_many :recurring_expenses, class_name: "BxBlockExpensetracking::RecurringExpense"
    belongs_to :parent_academic_account, class_name: "BxBlockAcademicAccount::AcademicAccount", optional: true
    has_many :child_academic_accounts, class_name: "BxBlockAcademicAccount::AcademicAccount", foreign_key: "parent_academic_account_id", dependent: :destroy
    belongs_to :account_type, class_name: "BxBlockAcademicAccount::AccountType"
    validates_uniqueness_of :name, {case_sensitive: false, message: lambda{|x, y| "#{y[:value]} is already present" }}
    validates_presence_of :name, { message: "Account name can't be blank" }
    after_create :update_custom_id

    def update_custom_id
      self.custom_id = ('000000' + id.to_s).last(6)
      self.save
    end

    def self.import(file)
      invaild_data = []
      saved_date = []
      CSV.foreach(file.path, headers: true) do |row|
        account_type = AccountType.find_by("name ILIKE ?", row[1].to_s.strip)
        parent_account = AcademicAccount.find_by("name ILIKE ?", row[4].to_s.strip)
        if  account_type.present?
          # begin
            if parent_account.present?
              account = AcademicAccount.create(name: row[0], account_type_id: account_type&.id, code: row[2], description: row[3], parent_academic_account_id: parent_account&.id, is_sub_account: true)
              if account.errors.any?
                invaild_data << row.to_h.merge("Error" => account.errors.messages[:name].join(""))
              else
                hash = row.to_h
                hash.delete("Error")
                saved_date << hash
              end
            else
              account = AcademicAccount.create(name: row[0], account_type_id: account_type&.id, code: row[2], description: row[3])
              if account.errors.any?
                invaild_data << row.to_h.merge("Error" => account.errors.messages[:name].join(""))
              else
                hash = row.to_h
                hash.delete("Error")
                saved_date << hash
              end
            end
          # rescue => e
          #   invaild_data << row.to_h
          #   next
          # end
        else
          invaild_data << row.to_h.merge("Error" => "Account type must exist")
        end
      end
      # data = ["invalid_data" => invaild_data, "saved_data" => saved_date]
      invaild_data
    end

    def self.to_csv
      attributes = ["ID", "Account Name", "Account Type", "Account Code", "Description", "Parent Account"]
      CSV.generate(headers: true) do |csv|
        csv << attributes
        all.each do |acad_account|
          csv << [acad_account.custom_id, acad_account&.name, acad_account&.account_type&.name, acad_account&.code, acad_account.description, acad_account&.parent_academic_account&.name]
        end
      end
    end
    def self.to_sample_csv
      attributes = ["Account Name", "Account Type", "Account Code", "Description", "Parent Account"]
      CSV.generate(headers: true) do |csv|
        csv << attributes
        all.each do |acad_account|
          csv << [acad_account&.name, acad_account&.account_type&.name, acad_account&.code, acad_account.description, acad_account&.parent_academic_account&.name]
        end
      end
    end
  end
end