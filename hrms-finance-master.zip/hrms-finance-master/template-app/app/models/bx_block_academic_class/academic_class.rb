module BxBlockAcademicClass
	class AcademicClass < BxBlockAcademicClass::ApplicationRecord
		self.table_name = :academic_classes
		validates :name, presence: true
		has_many :divisions, class_name: "BxBlockDivision::Division", dependent: :destroy
		belongs_to :academic_year, class_name: "BxBlockAcademicYear::AcademicYear"
		has_many :fee_structures, class_name: "BxBlockFeeStructure::FeeStructure", dependent: :nullify
	end
end
