module BxBlockInvoiceTemplate
	class InvoiceTemplate < BxBlockInvoiceTemplate::ApplicationRecord
		self.table_name = :invoice_templates
		validates_presence_of :name, { message: "Invoice name can't be blank" }
		validates_presence_of :subject, { message: "Invoice subject can't be blank" }
		has_many :installments, class_name: "BxBlockInstallment::Installment", dependent: :nullify
	end
end

