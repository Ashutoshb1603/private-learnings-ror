module BxBlockReviewandapproval
  class Approval < BxBlockReviewandapproval::ApplicationRecord
    self.table_name = :approvals
     
    include Wisper::Publisher
    
    #associations
    has_many :approvars, class_name: "BxBlockReviewandapproval::Approvar", dependent: :destroy
    has_many :rules, class_name: "BxBlockReviewandapproval::Rule", dependent: :destroy
    
    #enum declaration
    # enum execution_on: {create: 0 ,update: 1} 
  end
end 