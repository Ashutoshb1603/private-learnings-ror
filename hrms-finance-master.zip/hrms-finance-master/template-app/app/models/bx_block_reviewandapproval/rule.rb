module BxBlockReviewandapproval
  class Rule < BxBlockReviewandapproval::ApplicationRecord
    self.table_name = :approval_rules
    include Wisper::Publisher

    #associations
    belongs_to :approval ,class_name: "BxBlockReviewandapproval::Approval",foreign_key: :approval_id 
  end
end 