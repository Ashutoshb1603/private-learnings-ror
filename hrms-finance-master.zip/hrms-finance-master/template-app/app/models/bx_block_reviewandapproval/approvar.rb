module BxBlockReviewandapproval
  class Approvar < BxBlockReviewandapproval::ApplicationRecord
    self.table_name = :approvars
     
    include Wisper::Publisher

    #associations
    belongs_to :approval ,class_name: "BxBlockReviewandapproval::Approval",foreign_key: :approval_id 
    has_many :approvar_tasks , class_name: "BxBlockReviewandapproval::ApprovarTask"
    has_many :approvar_actions , class_name: "BxBlockReviewandapproval::ApprovarAction"
    #enum declaration
    # enum approvar_type: {role:0, user:1} 
  end
end 