module BxBlockReviewandapproval
  class ApprovarTask < BxBlockReviewandapproval::ApplicationRecord
    self.table_name = :approvar_tasks
     
    include Wisper::Publisher

    #associations
    belongs_to :approvar ,class_name: "BxBlockReviewandapproval::Approvar",foreign_key: :approvar_id 

    #enum declaration
    # enum approvar_type: {role:0, user:1} 
  end
end 