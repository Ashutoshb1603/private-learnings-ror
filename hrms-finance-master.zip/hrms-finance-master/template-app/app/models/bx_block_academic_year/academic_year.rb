module BxBlockAcademicYear
	class AcademicYear < BxBlockAcademicYear::ApplicationRecord
		self.table_name = :academic_years
		validates :year, presence: { message: "Year can't be blank" }
		validates :year, uniqueness: {case_sensitive: false, message: lambda{|x, y| "#{y[:value]} is already present"}}
		has_many :academic_classes, class_name: "BxBlockAcademicClass::AcademicClass", dependent: :destroy
		has_many :fee_structures, class_name: "BxBlockFeeStructure::FeeStructure", dependent: :destroy
	end
end
