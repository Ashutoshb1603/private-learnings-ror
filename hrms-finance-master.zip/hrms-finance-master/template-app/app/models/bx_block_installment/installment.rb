module BxBlockInstallment
	class Installment < BxBlockInstallment::ApplicationRecord
		require 'csv'
		self.table_name = :installments
		# enum duration: { "weeks" => 'weeks', "months" => "months", "year" => "year" }
		enum bill_duration: [:weeks, :months, :year]
		# enum name: { "Monthly Plan" => 'monthly', "Quarterly Plan" => "quarterly", "Half Yearly Plan" => "half_yearly", "Yearly Plan" => "yearly", "Weekly Plan"=> "weekly" }
		# enum mode: [:amount, :percentage]
		enum concession_type: [:amount, :percentage]
		enum payment_collection: [:manual_due_dates, :equally_distributes]
		enum payment_option: %w[razorpay payu 2k_payment_service]
		validates_presence_of :name, { message: "Installment name can't be blank" }
		after_create :update_custom_id
		has_many :installment_details, class_name: "BxBlockAssignFeeStructure::InstallmentDetail", dependent: :destroy
		belongs_to :fee_structure, class_name: "BxBlockFeeStructure::FeeStructure"
		belongs_to :invoice_template, class_name: "BxBlockInvoiceTemplate::InvoiceTemplate", optional: true
		belongs_to :email_template, class_name: "BxBlockEmailTemplate::EmailTemplate", optional: true
		scope :having_range_between, ->(start_range, end_range) { where(description: start_range..end_range) }
		accepts_nested_attributes_for :installment_details, allow_destroy: true

		def self.import(file)
			CSV.foreach(file.path, headers: true) do |row|
				Installment.create! row.to_hash
			end
		end

		def update_custom_id
      self.custom_id = ("000000" + self.id.to_s).last(6)
      self.save
    end

		def self.to_csv
	    attributes = %w{id name duration_no bill_duration description }
	    CSV.generate(headers: true) do |csv|
	      csv << attributes
	      all.each do |installment|
	        csv << attributes.map{ |attr| installment.send(attr) }
	      end
	    end
	   end
	end
end



