module AccountBlock
  class EmployeeSerializer < BuilderBase::BaseSerializer
    attributes *[:custom_id]

    attribute :employee_name do |object|
      object.first_name + object.last_name
    end

    attribute :department do |object|
      object.department&.name
    end

    attribute :designation do |object|
      object.designation&.name
    end

    # attribute :department do |object|
    #   object.designation&.name
    # end
  end
end
