module AccountBlock
    class SectionSerializer < BuilderBase::BaseSerializer
      attributes *[
        :id,
        :name,
      ]
    end
  end
  