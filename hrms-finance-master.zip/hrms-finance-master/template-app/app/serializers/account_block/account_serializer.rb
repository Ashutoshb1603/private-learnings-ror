module AccountBlock
  class AccountSerializer < BuilderBase::BaseSerializer
    attributes *[
      :activated,
      :country_code,
      :email,
      :first_name,
      :full_phone_number,
      :last_name,
      :phone_number,
      :type,
      :status,
      :created_at,
      :updated_at,
      :device_id,
      :unique_auth_id,
      :custom_id
    ]

    attribute :country_code do |object|
      country_code_for object
    end

    attribute :phone_number do |object|
      phone_number_for object
    end

    attribute :status do |object|
      object.activated
    end

    attribute :role do |object|
      object&.role&.name
    end
    attribute :role_id do |object|
      object&.role&.id
    end
    attribute :password do |object|
      if object.account_passwords.any?
        AESCrypt.decrypt(object.account_passwords.last&.password, ENV['ENCRYPT_KEY']) rescue nil
      elsif object.temporary_password.present?
        AESCrypt.decrypt(object.temporary_password, ENV['ENCRYPT_KEY']) rescue nil
      end
    end
    class << self
      private

      def country_code_for(object)
        return nil unless Phonelib.valid?(object.full_phone_number)
        Phonelib.parse(object.full_phone_number).country_code
      end

      def phone_number_for(object)
        return nil unless Phonelib.valid?(object.full_phone_number)
        Phonelib.parse(object.full_phone_number).raw_national
      end
    end
  end
end
