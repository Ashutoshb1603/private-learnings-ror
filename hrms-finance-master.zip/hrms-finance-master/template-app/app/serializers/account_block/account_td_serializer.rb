module AccountBlock
    class AccountTdSerializer < BuilderBase::BaseSerializer
      attributes *[
         :id,
         :section_id,
         :section,
         :tax_rate,
         :tax_name ,
         :status ,
      ]

      attribute :section do |object|
        object&.section&.name rescue nil
      end
    end
  end
  