module AccountBlock
  class EmailAccountSerializer
    include FastJsonapi::ObjectSerializer

    attributes *[
      :first_name,
      :last_name,
      :full_phone_number,
      :country_code,
      :phone_number,
      :email,
      :activated,
      :user_name,
      :role_id,
      :school_id,
      :lms_token,
      :status,
    ]
    attribute :status do |object|
      object.activated
    end
  end
end
