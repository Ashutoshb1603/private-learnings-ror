module AccountBlock
  class VendorSerializer < BuilderBase::BaseSerializer
    attributes *[
       :salutation,
       :first_name,
       :last_name ,
       :company_name,
       :vendor_email,
       :phone_no_mob,
       :phone_no_mob_code,
       :phone_no_work,
       :phone_no_work_code,
       :website_url,
       :gst_treatment_id,
       :gst_treatment,
       :gstin_uin,
       :pan_number,
       :currency,
       :payment_term_id,
       :payment_term,
       :account_td_id,
       :account_tds,
       :state_source_of_supply ,
       :billing_address,
       :billing_address2,
       :shipping_address,
       :shipping_address2,
       :is_same_billing_address,
       :remarks
    ]

    attribute :gst_treatment do |object|
      object&.gst_treatment&.name rescue nil
    end

    attribute :payment_term do |object|
      object&.payment_term&.term_name rescue nil
    end

    attribute :account_tds do |object|
      object&.account_td&.tax_name rescue nil
    end

  end
end
