module BxBlockExpensetracking
  class RecurringExpenseHistorySerializer < BuilderBase::BaseSerializer
  	attributes *[
      :description,
      :created_at
  	]
  end
end