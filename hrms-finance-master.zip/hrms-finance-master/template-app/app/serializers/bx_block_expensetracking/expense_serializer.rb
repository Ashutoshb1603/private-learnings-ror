module BxBlockExpensetracking
  class ExpenseSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes *[
      :expense_type,
      :hns_code, 
      :date, 
      :currency, 
      :expence_account, 
      :ammount, 
      :tax, 
      :vendor, 
      :invoice, 
      :paid_trough, 
      :source_of_supply, 
      :destination_of_supply, 
      :gst_treatment, 
      :reverse_charge, 
      :reverse_charge_account, 
      :reverse_charge_ammount, 
      :comment,
      :expense_recipt,
      :ref_no,
      :status,
      :customer,
      :account_is,
      :exchange_rate,
      :exchange_amount,
      :is_tax_inclusive
  
    ] 

    attribute :expense_recipt do |object|
      ""
    end
  
    attribute :ref_no do |object|
      ""      
    end
  
    attribute :status do |object|
      ""      
    end


    attribute :customer do |object|
      ""      
    end
  
  
    attribute :vendor do |object|
      AccountBlock::Vendor.find(object.vendor_id).first_name rescue nil
    end
    

  end
end
