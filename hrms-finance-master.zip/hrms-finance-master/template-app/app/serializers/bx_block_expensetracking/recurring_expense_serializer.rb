module BxBlockExpensetracking
  class RecurringExpenseSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes *[
      :expense_type,
      :sac,
      :hsn,
      :expense_name,
      :paid_through,
      :currency,
      :exchange_rate,
      :exchange_amount,
      :ammount ,
      :repeat_every,
      :start_date ,
      :end_date ,
      :vendor_id,
      :customer_id,
      :tax_id,
      :source_of_supply,
      :destination_of_supply,
      :gst_treatment_id,
      :reverse_charge,
      :comment,
      :ammount_is,
      :gst_in,
      :reason_for_exemption,
      :bill_every_count,
      :bill_every_option,
      :is_reverse_charge,
      :reverse_charge_mode,
      :reverse_charge,
      :last_expense_date,
      :next_expense_date
    ]
  
    attribute :status do |object|
       object.stop == true ? false : true
    end

    attribute :expense_account do |object|
      object.expense_account
    end

    attribute :customer do |object|
      object.customer
    end
  
    attribute :vendor do |object|
      AccountBlock::Vendor.find(object.vendor_id).first_name rescue nil
    end
    
    attribute :reverse_charge_account do |object|
      object.reverse_charge_account
    end

  end
end
