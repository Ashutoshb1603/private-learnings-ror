module BxBlockExpensetracking
	class ExpenseHistorySerializer < BuilderBase::BaseSerializer
		attributes *[
			:date,
			:status,
			:paid_through,
			:amount,
			:expense_id
		]
	end
end