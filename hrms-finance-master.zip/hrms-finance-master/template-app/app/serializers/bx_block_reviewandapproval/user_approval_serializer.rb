module BxBlockReviewandapproval
  class UserApprovalSerializer < BuilderBase::BaseSerializer
    attributes *[
      :id,
      :academic_year,
      :student_name,
      :created_at,
      :updated_at,
      :class, 
      :division,
      :due_date,
      :status,
    ]

    attribute :academic_year do |object|
      object.division.academic_class.academic_year.year 
    end

    attribute :student_name do |object|
      "#{object.first_name} #{object.last_name}"
    end

    attribute :class do |object|
      "fee_structures"#object.division.academic_class.class
    end

    attribute :division do |object|
      object.division.title
    end

    attribute :due_date do |object|
      ""
    end
  end
end

