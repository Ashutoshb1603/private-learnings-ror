module BxBlockReviewandapproval
  class ApprovalSerializer < BuilderBase::BaseSerializer
    attributes *[
      :module_name,
      :approval_name,
      :execution_on, 
      :description,
      :rules,  
      :approvars,
    ]

    attribute :rules do |object|
      object.rules
    end
 
    attribute :approvars do |object|
      add_task_to_approvars(object)      
    end

    class << self
      private

      def add_task_to_approvars(object)
        resp_arr = []
        object.approvars.each{|i|  resp_arr << i.serializable_hash.merge(tasks:i.approvar_tasks,approvar_action: i.approvar_actions)}
        resp_arr
      end
    end
  end
end
