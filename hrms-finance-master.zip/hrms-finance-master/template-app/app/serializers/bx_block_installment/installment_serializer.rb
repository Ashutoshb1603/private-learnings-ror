module BxBlockInstallment
  class InstallmentSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes *[
      :id,
      :name,
      :duration_no,
      :duration,
      :description,
      :created_at,
      :updated_at,
      :custom_id
    ] 
  end
end
