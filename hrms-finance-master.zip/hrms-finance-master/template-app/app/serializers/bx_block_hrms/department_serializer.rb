module BxBlockHrms
  class DepartmentSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :id, :name, :lead, :email, :created_at, :updated_at

    attribute :added_by do |object|
      object&.creator&.role&.name
    end

    attribute :parent_department do |object|
      object&.parent_department&.name
    end
  end
end
