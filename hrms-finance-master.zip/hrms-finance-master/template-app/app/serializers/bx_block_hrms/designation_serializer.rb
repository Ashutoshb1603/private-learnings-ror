module BxBlockHrms
  class DesignationSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :id, :name, :created_at, :updated_at

    attribute :added_by do |object|
      object&.creator&.role&.name
    end
  end
end
