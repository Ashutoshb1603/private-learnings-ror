module BxBlockStudent
  class StudentSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes *[
      :id,
      :first_name,
      :last_name,
      :father_name,
      :mother_name,
      :division_id,
      :image,
      :dob,
      :gender,
      :registration_no,
      :roll_no,
      :created_at,
      :updated_at,
      :custom_id,
    ] 
  end
end
