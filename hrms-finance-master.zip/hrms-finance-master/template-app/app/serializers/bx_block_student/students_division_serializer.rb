module BxBlockStudent
  class StudentsDivisionSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes *[
      :id,
      :first_name,
      :last_name,
      :created_at,
      :updated_at,
      :custom_id,
    ] 
  end
end
