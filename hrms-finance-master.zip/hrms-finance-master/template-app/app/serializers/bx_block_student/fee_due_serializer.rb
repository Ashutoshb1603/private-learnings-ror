module BxBlockStudent
    class FeeDueSerializer < BuilderBase::BaseSerializer
      include FastJsonapi::ObjectSerializer
      attributes *[
        :id,
        :registration_no,
        :roll_no,
      ] 
      attribute :name do |object|
        "#{object.first_name}" + " #{object.last_name}"
      end

      attribute :division do |object|
        division = BxBlockDivision::Division.find(object.division_id)
        if division.present? && division.title.present?
          division.title
        else
          ""
        end
      end

      attribute :class do |object|
        academic_class = BxBlockDivision::Division.find(object.division_id)
        if academic_class.present? && academic_class.academic_class_id.present?
          academic_cls = BxBlockAcademicClass::AcademicClass.find(academic_class.academic_class_id) 
          academic_cls.name
        else
          ""
        end
      end

    end
  end