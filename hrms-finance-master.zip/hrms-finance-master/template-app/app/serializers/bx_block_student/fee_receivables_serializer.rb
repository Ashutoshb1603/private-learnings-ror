module BxBlockStudent
    class FeeReceivablesSerializer < BuilderBase::BaseSerializer
      include FastJsonapi::ObjectSerializer
      attributes *[
        :id,
        :registration_no,
        :roll_no,
      ] 

      attribute :division do |object|
        division = BxBlockDivision::Division.find(object.division_id)
        if division.present? && division.title.present?
          division.title
        else
          ""
        end
      end

      attribute :class do |object|
        academic_class = BxBlockDivision::Division.find(object.division_id)
        if academic_class.present? && academic_class.academic_class_id.present?
          academic_cls = BxBlockAcademicClass::AcademicClass.find(academic_class.academic_class_id) 
          academic_cls.name
        else
          ""
        end
      end

    end
  end