module BxBlockAcademicAccount
  class AcadamicAccountSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :name, :account_type_id, :account_type, :code, :description, :is_sub_account, :custom_id
    attribute :account_type_id do |object|
      object&.account_type_id
    end
    attribute :account_type do |object|
      object&.account_type&.name
    end

		attribute :parent_academic_account_id do |object|
			if object.is_sub_account?
				object&.parent_academic_account_id
			end
		end
		attribute :parent_account_name do |object|
			if object.is_sub_account?
				object&.parent_academic_account&.name
			end
		end
		attribute :child_academic_accounts do |object|
			if object.child_academic_accounts.present?
				object&.child_academic_accounts
			end
		end
  end
end
