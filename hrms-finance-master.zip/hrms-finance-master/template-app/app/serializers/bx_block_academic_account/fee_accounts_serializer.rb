module BxBlockAcademicAccount
  class FeeAccountsSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :name
  end
end
