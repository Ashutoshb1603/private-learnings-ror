module BxBlockAcademicAccount
  class ParentAccountSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :name
  end
end
