module BxBlockAcademicAccount
  class AccountTypeSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :name
  end
end
