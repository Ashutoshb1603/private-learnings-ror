module BxBlockAcademicYear
  class AcademicYearSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes *[
      :id,
      :year
    ] 
  end
end
