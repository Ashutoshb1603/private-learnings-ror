module BxBlockFeeStructure
  class SubFeeStructureSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :id, :name, :academic_year, :grade, :division, :is_class, :is_class_and_division, :is_group, :due_date,
               :fee_type

    attribute :group_list do |object|
      if object.is_group
        students = LmsBlock::StudentBlock::StudentsService.new.get_students_by_filter(object.group.student_ids, 1)
        # return render json: students, status: students['status'] unless students['status'] == 200
        return students unless students['status'] == 200
        data = []
        students['data'].each do |student|
          id = student['id']
          email = student['attributes']['email']
          name = student['attributes']['first_name'] + ' ' + student['attributes']['last_name']
          fee_structures = StudentBlock::StudentFeeStructure.joins(:fee_structure).where("student_id = #{id}").select(
            'id', 'fee_structures.name', 'status', 'fee_structure_id'
          )
          data << { id: id, name: name, email: email, fee_structures: fee_structures } if fee_structures.any?
        end
        data
      elsif nil
      end
    end

    attribute :sub_fee_structures do |object|
      NewSubFeeStructureSerializer.new(object.sub_fee_structures)
    end

    attribute :installments do |object|
      InstallmentsSerializer.new(object.installments)
    end
  end
end
