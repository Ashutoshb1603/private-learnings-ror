module BxBlockFeeStructure
  class InstallmentsSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :id, :name, :created_at, :updated_at, :custom_id, :total_amount, :discounted_amount, :installment_code, :concession, :concession_type, :bill_duration_no, :bill_duration, :billing_cycle, :payment_option, :invoice_template_id, :invoice_template_name, :email_template_id, :email_template_name, :fee_structure_id, :payment_collection, :installment_details
    attribute :installment_details do |object|
      installment_details = []
      object.installment_details.each do |ins_details|
        fine_name = ins_details&.fine&.name
        installment_details << ins_details.attributes.merge(fine_name: fine_name)
      end
      installment_details
    end
    # attribute :installments do |object|
    #   BxBlockInstallment::Installment.where(fee_structure_id: object.id).order("created_at DESC")
    # end
    attribute :invoice_template_name do |object|
			object&.invoice_template&.name
    end
    attribute :email_template_name do |object|
			object&.email_template&.name
    end
  end
end
