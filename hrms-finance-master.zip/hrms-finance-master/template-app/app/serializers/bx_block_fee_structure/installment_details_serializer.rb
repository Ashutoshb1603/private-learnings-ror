module BxBlockFeeStructure
  class InstallmentDetailsSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :id, :name, :created_at, :updated_at, :custom_id, :total_amount, :discounted_amount, :installment_code, :concession, :concession_type, :bill_duration_no, :bill_duration, :billing_cycle, :payment_option, :invoice_template_id, :email_template_id, :fee_structure_id, :payment_collection
    attribute :installment_details do |object|
      BxBlockAssignFeeStructure::InstallmentDetail.where(installment_id: object.id).order("created_at DESC")
    end
  end
end
