module BxBlockFeeStructure
  class ShowFeeCollectionSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes *[
      :id,
    ]

    attribute :student_name do |object|
      object&.student&.first_name
    end

    attribute :student_id do |object|
      object&.student&.custom_id
    end

    attribute :academic_year do |object|
      object.academic_year&.year
    end
    attribute :class do |object|
      object.academic_class.name
    end

    attribute :division do |object|
      object.division.title
    end

    # attribute :total_amount do |object|
    #   object.division&.title
    # end

    attribute :fee_structure do |object|
        object.fee_structure.name
    end

    attribute :sub_fee_structures do |object|
      BxBlockFeeStructure::NewSubFeeStructureSerializer.new(object.fee_structure.sub_fee_structures)
    end

    attribute :installments do |object|
      InstallmentsSerializer.new(object.fee_structure.installments)
    end

  end
end