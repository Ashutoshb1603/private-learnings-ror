module BxBlockFeeStructure
  class NewSubFeeStructureSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :id, :amount_after_concession

    attribute :fee_name do |object|
      object&.fee&.name
    end
    
    attribute :amount do |object|
      object&.fee&.amount
    end

    attribute :taxs do |object|
      BxBlockTax::Tax.where(id: object&.fee&.tax_ids)
    end

    attribute :concession do |object|
      BxBlockFee::FeeConcessionSerializer.new(object.fee_concession)
    end
    
  end
end