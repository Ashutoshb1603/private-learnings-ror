module BxBlockFeeStructure
  class FeeCollectionSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :id, :name, :grade, :grade_id, :division, :division_id, :is_class, :is_class_and_division, :is_group, :academic_year, :fee_type, :custom_id


    attribute :total_amount do |object|
      object.total_amount
    end

    attribute :sub_fee_structures do |object|
      NewSubFeeStructureSerializer.new(object.sub_fee_structures)
    end

    attribute :installment do |object|
      InstallmentsSerializer.new(object.installments)
    end
  end
end