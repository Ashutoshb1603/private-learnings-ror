module BxBlockFeeStructure
  class EmailTemplateSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :id, :name
  end
end
