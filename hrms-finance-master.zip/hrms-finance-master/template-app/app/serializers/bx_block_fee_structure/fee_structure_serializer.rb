module BxBlockFeeStructure
  class FeeStructureSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :id, :grade, :division, :is_class, :is_class_and_division, :is_group, :name, :academic_year, :fee_type, :custom_id

    attribute :academic_year do |object|
      object.academic_year&.year
    end
    # attribute :fee_type do |object|
    #   object&.sub_fee_structures.last&.fee_type
    # end
  end
end
