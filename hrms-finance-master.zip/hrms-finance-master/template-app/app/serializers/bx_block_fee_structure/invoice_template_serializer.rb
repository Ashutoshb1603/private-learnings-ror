module BxBlockFeeStructure
  class InvoiceTemplateSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :id, :name
  end
end
