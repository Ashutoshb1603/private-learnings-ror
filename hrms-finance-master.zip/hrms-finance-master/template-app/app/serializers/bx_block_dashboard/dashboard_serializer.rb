module BxBlockDashboard
  class DashboardSerializer < BuilderBase::BaseSerializer

  end
end