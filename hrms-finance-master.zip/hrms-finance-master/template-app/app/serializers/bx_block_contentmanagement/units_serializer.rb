module BxBlockContentmanagement
	class UnitsSerializer < BuilderBase::BaseSerializer
		attributes *[
		  :name,
		  :quantity_code,
			:created_at,
			:updated_at
		]
	end
end