module BxBlockContentmanagement
	class ItemsSerializer < BuilderBase::BaseSerializer
		attributes *[
		  :name,
		  :hsn_or_sac,
		  :tax_preference,
		  :unit_id,
		  :account_id,
		]

		attribute :item_informations do |obj|
			BxBlockContentmanagement::ItemInformationsSerializer.new(obj.item_informations).serializable_hash
		end
	end
end