module BxBlockContentmanagement
	class ItemInformationsSerializer < BuilderBase::BaseSerializer
		attributes *[
		  :information_type,
		  :price,
		  :information_account,
		  :description,
		  :item_id,
		]
	end
end