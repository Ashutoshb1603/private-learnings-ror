module BxBlockGstSetting
  class GstSettingSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes *[
      :gst_number,
      :legal_name,
      :trade_name,
      :regesterd_on
    ] 
  end
end