module BxBlockProfile
	class BusinessCustomersSerializer < BuilderBase::BaseSerializer
        

	  attributes *[:company_name, :primary_contact, :email, :country_code, :contact_number, :website_url, :billing_street, :billing_address, :shipping_street, :shipping_address], if: Proc.new { |record, params| params[:is_business] == true}

      attributes *[:gst_treatment, :gstin_number, :place_of_supply, :tax_preference, :payment_term, :remarks], if: Proc.new { |record, params| params[:is_business] == false }    

      # attribute :gst_treatment, if: Proc.new { |record, params| params[:is_business] == false } do |object|
      #   { 
      #     id: object.gst_treatment.id,
      #    name: object.gst_treatment.name,
      #    description: object.gst_treatment.description
      #   } if object.gst_treatment.present?
      # end

      attribute :payment_term, if: Proc.new { |record, params| params[:is_business] == false } do |object|
        { 
          id: object.payment_term.id,
         term_name: object.payment_term.term_name,
         no_of_days: object.payment_term.no_of_days
        } if object.payment_term.present?
      end

      # attribute :contact_number do |object|
      #   "#{object.country_code}"+"-"+"#{object.contact_number}"
      # end
      attribute :country_code do |object|
        "#{object.country_code}"
      end

      attribute :contact_number do |object|
        "#{object.contact_number}"
      end
	end
end