module BxBlockProfile
	class PaymentTermSerializer < BuilderBase::BaseSerializer
		include FastJsonapi::ObjectSerializer
		attributes *[
			:id,
			:term_name, 
			:no_of_days,
			:account_id,
			:status,
		]

	end
end