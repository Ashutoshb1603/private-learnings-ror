module BxBlockProfile
	class IndividualCustomersSerializer < BuilderBase::BaseSerializer

    attribute :primary_details do |object|
    	PrimaryDetailsSerializer.new(object).serializable_hash[:data] if object.present?
    end
	
	attribute :contact_detail do |object|
    	BxBlockAddress::ContactDetailsSerializer.new(object.contact_detail).serializable_hash[:data] if object.contact_detail.present?
	end

    attribute :secondary_details do |object|
			SecondaryDetailsSerializer.new(object.secondary_details).serializable_hash[:data] if object.secondary_details.present?
	end

	end
end