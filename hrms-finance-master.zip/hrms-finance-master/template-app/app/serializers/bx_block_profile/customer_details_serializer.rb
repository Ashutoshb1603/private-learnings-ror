module BxBlockProfile
	class CustomerDetailsSerializer < BuilderBase::BaseSerializer
     
     attribute :customer_name do |object, params|
     	 if params[:customer_type].eql?("business")
     	 	  object.primary_contact
     	 	else
     	 		object.first_name + " "+ object.last_name
     	 	end
     end
     
     attribute :customer_type do |object, params|
        params[:customer_type]
     end
     
	 attribute :country_code do |object, params|
		if params[:customer_type].eql?("business")
			   "+#{object.country_code}"
			 else
		  "+#{object.country_code}"
			 end
	end

     attribute :contact_no do |object, params|
     	if params[:customer_type].eql?("business")
     	 	  "#{object.contact_number}"
     	 	else
           "#{object.phone_number}"
     	 	end
     end

     attribute :email do |object|
     	object.email
     end
     
     attribute :company_email do |object, params|
     	if params[:customer_type].eql?("business")
     	 	  object.email
     	 	else
     	 		nil
     	 	end
     end
	end
end