module BxBlockProfile
  class ProfileSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes *[
      :id,
      :name,
      :business_location,
      :address,
      :address2,
      :email,
      :contact_no,
      :license_no,
      :fiscal_year,
      :city,
      :state,
      :pin_code,
      :website_url,
      :profile_image,
      :fax_no,
      :account
    ]

    attribute :profile_image do |object|
      if object.profile_pic.attached?
        # ENV["API_BASE_URL"] + Rails.application.routes.url_helpers.rails_blob_url(object.profile_pic, only_path: true)
        object.profile_pic.service_url
      end
    end
  end
end
