module BxBlockProfile
	class CustomersSerializer < BuilderBase::BaseSerializer
	  attributes :id
    
    attribute :customer_name do |object|
      "#{object.user_first_name} #{object.user_last_name}"
    end

    attribute :company_name do |object|
      object.try(:company_name) ? object.company_name : object.first_name + object.last_name
    end

    attribute :phone do |object|
      object.try(:primary_contact) ? object.primary_contact : object.phone_number
    end

    attribute :customer_type do |object|
      object.class.to_s == "BxBlockProfile::IndividualCustomer" ? 'individual' : 'business'
    end
	end
end