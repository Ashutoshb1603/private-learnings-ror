module BxBlockProfile
	class SecondaryDetailsSerializer < BuilderBase::BaseSerializer
		attributes *[
			:first_name,
			:last_name,
			:gender,
			:nationality,
			:admission_number,
			:class_name,
			:class_division,
			:individual_customer_id
		]

	 # attributes *[:nationality, :admission_number, :class_name, :class_division], if: Proc.new { |record, params| params[:is_secondary] == true}

  #    attributes *[:relationships, :phone_number, :email, :remarks], if: Proc.new { |record, params| params[:is_secondary] == false }    
	end
end