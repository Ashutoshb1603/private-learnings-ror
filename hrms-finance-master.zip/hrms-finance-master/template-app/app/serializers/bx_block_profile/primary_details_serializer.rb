module BxBlockProfile
	class PrimaryDetailsSerializer < BuilderBase::BaseSerializer
	attributes *[
		  :first_name,
			:last_name,
			:gender,
			:relationships,
			:phone_number,
			:email,
			:remarks,
			:billto
		]

    # attribute :phone_number do |object|
    #   "#{object.country_code}"+"-"+"#{object.phone_number}"
    # end
	attribute :country_code do |object|
		"#{object.country_code}"
	  end

	attribute :phone_number do |object|
		"#{object.phone_number}"
	  end

	end
end