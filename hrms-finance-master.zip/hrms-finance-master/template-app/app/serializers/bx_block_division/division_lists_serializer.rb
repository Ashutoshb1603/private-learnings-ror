module BxBlockDivision
  class DivisionListsSerializer < BuilderBase::BaseSerializer
    attributes :id, :title
  end
end
