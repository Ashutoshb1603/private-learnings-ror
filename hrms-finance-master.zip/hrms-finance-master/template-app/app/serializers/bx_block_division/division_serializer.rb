module BxBlockDivision
  class DivisionSerializer < BuilderBase::BaseSerializer
    attributes :id, :title, :academic_class
  end
end
