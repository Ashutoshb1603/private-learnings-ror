module BxBlockTax
  class TaxNamesSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes *[
      :id,
      :name
    ] 
  end
end
