module BxBlockTax
  class TaxSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes *[
      :id,
      :name,
      :tax_percentage,
      :description,
      :custom_id,
      :tax_type,
      :is_gst
    ] 
  end
end
