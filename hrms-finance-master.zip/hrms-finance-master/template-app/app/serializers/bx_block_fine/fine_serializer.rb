module BxBlockFine
  class FineSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes *[
      :id,
      :name,
      :day,
      :duration,
      :fine_category,
      :fine_amount,
      :mode,
      :created_at,
      :updated_at,
      :custom_id,
      :sub_fines
    ] 
  end
end
