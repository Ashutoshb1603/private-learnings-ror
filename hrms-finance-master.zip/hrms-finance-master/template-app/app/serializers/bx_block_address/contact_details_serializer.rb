module BxBlockAddress
  class ContactDetailsSerializer < BuilderBase::BaseSerializer
    
    attributes *[
      :street_address,
      :address,
      :city,
      :state,
      :pin_code,
      :country,
      :email,
      :phone_number,
      :billing_street,
      :billing_address,
      :shiping_street,
      :shiping_address,
      :individual_customer_id
    ]
    # attribute :phone_number do |object|
    #   "#{object.country_code}"+"-"+"#{object.phone_number}"
    # end
    attribute :phone_number do |object|
      "#{object.phone_number}"
    end
    attribute :country_code do |object|
      "#{object.country_code}"
    end
  end
end
