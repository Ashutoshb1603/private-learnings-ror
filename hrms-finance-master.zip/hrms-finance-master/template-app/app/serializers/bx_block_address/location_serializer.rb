module BxBlockAddress
  class LocationSerializer
    include JSONAPI::Serializer
    attributes :branch_id, :branch_name, :country, :state, :time_zone, :address, :street, :phone_number, :zip_code, :url
  end
end
