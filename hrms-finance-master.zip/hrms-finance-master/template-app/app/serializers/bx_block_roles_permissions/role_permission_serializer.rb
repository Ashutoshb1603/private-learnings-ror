module BxBlockRolesPermissions
  class RolePermissionSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :id, :actions, :menu

  end
end
