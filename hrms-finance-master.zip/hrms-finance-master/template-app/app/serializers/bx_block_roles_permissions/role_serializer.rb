module BxBlockRolesPermissions
  class RoleSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :id, :name, :status, :custom_id, :created

    attribute :created_by do |object|
      object.role_created_by
    end

    attribute :role_premissions do |object|
      RolePermissionSerializer.new(object.role_permissions.includes(:menu).order(:id))
    end
  end
end
