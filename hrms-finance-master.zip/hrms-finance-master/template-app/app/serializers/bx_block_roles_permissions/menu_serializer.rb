module BxBlockRolesPermissions
  class MenuSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :id, :title, :permission_category
  end
end
