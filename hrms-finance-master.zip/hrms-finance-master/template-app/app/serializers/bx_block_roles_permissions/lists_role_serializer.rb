module BxBlockRolesPermissions
  class ListsRoleSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :id, :name, :status, :custom_id, :created, :created_at, :updated_at

    attribute :created_by do |object|
      object.role_created_by
    end
  end
end
