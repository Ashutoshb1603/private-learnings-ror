module BxBlockRolesPermissions
  class PermissionCategorySerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :id, :title
    attribute :menus do |object|
      object.menus
    end
  end
end
