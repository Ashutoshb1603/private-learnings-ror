module BxBlockFee
  class FeeListsSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :id, :name, :amount

    attribute :tax do |object|
      BxBlockTax::Tax.where(id: object.tax_ids)
    end
  end
end
