module BxBlockFee
  class FeeSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :id, :name, :valid_until, :academic_account, :amount, :custom_id

    attribute :tax do |object|
      BxBlockTax::Tax.where(id: object.tax_ids)
    end

  end
end
