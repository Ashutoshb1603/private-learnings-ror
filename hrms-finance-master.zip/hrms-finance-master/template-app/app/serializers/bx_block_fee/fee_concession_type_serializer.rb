module BxBlockFee
  class FeeConcessionTypeSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :id, :name, :description, :deleted_at
  end
end
