module BxBlockFee
  class FeeConcessionSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes :id, :name, :valid_until, :fee_concession_type_id, :amount, :mode, :custom_id

    attribute :fee_concession_type do |object|
      FeeConcessionTypeSerializer.new(object&.fee_concession_type).serializable_hash
    end
  end
end
