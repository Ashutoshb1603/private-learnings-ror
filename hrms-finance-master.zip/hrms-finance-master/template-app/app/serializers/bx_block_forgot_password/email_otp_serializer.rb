module BxBlockForgotPassword
  class EmailOtpSerializer < BuilderBase::BaseSerializer
  end
end
