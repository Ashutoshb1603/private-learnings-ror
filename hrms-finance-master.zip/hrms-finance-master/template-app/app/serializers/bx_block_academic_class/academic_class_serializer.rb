module BxBlockAcademicClass
  class AcademicClassSerializer < BuilderBase::BaseSerializer
    include FastJsonapi::ObjectSerializer
    attributes *[
      :id,
      :name
    ] 
  end
end
