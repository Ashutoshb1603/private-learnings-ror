//= require active_admin/base
// active_admin.js
// require additional-methods
//= require jquery.validate

$(document).ready(function () {
  var today = new Date();
  $('#q_created_at_gteq_datetime').datepicker({
      dateFormat: "yy-mm-dd",
      autoclose:true,
      endDate: "today",
      maxDate: today
  }).on('changeDate', function (ev) {
          $(this).datepicker('hide');
      });

  $('#q_created_at_lteq_datetime').datepicker({
      dateFormat: "yy-mm-dd",
      autoclose:true,
      endDate: "today",
      maxDate: today
  })

	$('#q_created_at_gteq_datetime'). on('change', function(){
		var startDate = $('#q_created_at_gteq_datetime').val();
		var endDate = $('#q_created_at_lteq_datetime').val();
		if (endDate){
			if (endDate < startDate){
				alert('End date should be greater than Start date.');
				$('#q_created_at_gteq_datetime').val('');
			}
		}
	})

	$('#q_created_at_lteq_datetime'). on('change', function(){
		var startDate = $('#q_created_at_gteq_datetime').val();
		var endDate = $('#q_created_at_lteq_datetime').val();
		if (endDate < startDate){
			alert('End date should be greater than Start date.')
			$('#q_created_at_lteq_datetime').val('');
		}
	})
});