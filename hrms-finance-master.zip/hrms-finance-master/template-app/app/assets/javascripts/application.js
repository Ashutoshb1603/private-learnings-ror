//= require jquery
//= require jquery_ujs

$(document).ready(function()  {
     $('#toggle-all, input:checkbox').click(
 function () 
 {
           $('#table, :checkbox').attr(':checked','checked').true;
         },function(){
    $('#table :checkbox').attr(':checked').false;
         }
  );
});