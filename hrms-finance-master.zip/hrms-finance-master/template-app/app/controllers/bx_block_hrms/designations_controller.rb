module BxBlockHrms
  class DesignationsController < ApplicationController
    before_action :set_designation, only: %i[update show destroy]

    def index
      designations = Designation.paginate(page: params[:page], per_page: 20)
      if designations.present?
        render json: DesignationSerializer.new(designations, meta: { total_pages: designations.total_pages, message: 'Designations list' }).serializable_hash,
               status: :ok
      else
        render json: { message: 'Record not found' }, status: :not_found
      end
    end

    def create
      designation = current_user.designations.create(designation_params)
      if designation.present?
        render json: DesignationSerializer.new(designation, meta: {
                                          message: 'Designation successfully Created.'
                                        }).serializable_hash, status: :created
      else
        render json: { errors: format_activerecord_errors(designation.errors) }, status: :unprocessable_entity
      end
    end

    def update
      if @designation.update(designation_params)
        render json: DesignationSerializer.new(@designation, meta: { message: 'Designation successfully Updated.' }).serializable_hash,
               status: :ok
      else
        render json: { errors: format_activerecord_errors(@designation.errors) }, status: :unprocessable_entity
      end
    end

    def show
      render json: DesignationSerializer.new(@designation, meta: { message: 'Designation Details.' }).serializable_hash, status: :ok
    end

    def destroy
      if @designation.destroy
        render json: { message: 'Designation was successfully destroyed.' }, status: :ok
      else
        render json: { errors: @designation.errors }, status: :unprocessable_entity
      end
    end

    def import
      Designation.import(params[:file], current_user.id)
      render json: { message: 'Designation data is successfully Imported' }, status: :created
    end

    def export
      csv_data = Designation.all
      respond_to do |format|
        format.csv { send_data csv_data.to_csv, filename: "Designation-#{DateTime.now}.csv" }
      end
    end

    def filter
      designations = Designation.all
      designations = designations.where(name: params[:name]) if params[:name].present?
      if params[:role_id].present?
        designations = designations.where(creator_id: AccountBlock::Account.where(role_id: params[:role_id]).ids)
      end
      designations = designations.paginate(page: params[:page], per_page: 20)
      if designations.present?
        render json: DesignationSerializer.new(designations, meta: { total_pages: designations.total_pages, message: ' Designation filtered list' }).serializable_hash,
               status: :ok
      else
        render json: { message: 'No records.' }, status: :not_found
      end
    end

    def search
      designations = Designation.where('name ILIKE ?', "%#{params[:name]}%").paginate(page: params[:page], per_page: 20)
      if designations.present?
        render json: DesignationSerializer.new(designations, meta: { total_pages: designations.total_pages, message: 'Designation search list' }).serializable_hash,
               status: :ok
      else
        render json: { message: 'No records.' }, status: :not_found
      end
    end

    private

      def designation_params
        params.permit(:name)
      end

      def set_designation
        @designation = Designation.find(params[:id])
        render json: { message: 'Record not found' }, status: :not_found unless @designation.present?
      end
  end
end
