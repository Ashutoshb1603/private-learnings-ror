module BxBlockHrms
  class DepartmentsController < ApplicationController
    before_action :set_department, only: %i[update show destroy]

    def index
      departments = Department.paginate(page: params[:page], per_page: 20)
      if departments.present?
        render json: DepartmentSerializer.new(departments, meta: { total_pages: departments.total_pages, message: 'Departments list' }).serializable_hash,
               status: :ok
      else
        render json: {message:"No records."}, status: :ok
      end
    end

    def create
      department = current_user.departments.create(department_params)
      if department.present?
        render json: DepartmentSerializer.new(department, meta: {
                                          message: 'Department successfully Created.'
                                        }).serializable_hash, status: :created
      else
        render json: { errors: format_activerecord_errors(department.errors) }, status: :unprocessable_entity
      end
    end

    def update
      if @department.update(department_params)
        render json: DepartmentSerializer.new(@department, meta: { message: 'Department successfully Updated.' }).serializable_hash,
               status: :ok
      else
        render json: { errors: format_activerecord_errors(@department.errors) }, status: :unprocessable_entity
      end
    end

    def show
      render json: DepartmentSerializer.new(@department, meta: { message: 'Department Details.' }).serializable_hash, status: :ok
    end

    def destroy
      if @department.destroy
        render json: { message: 'Department was successfully destroyed.' }, status: :ok
      else
        render json: { errors: @department.errors }, status: :unprocessable_entity
      end
    end

    def import
      Department.import(params[:file], current_user.id)
      render json: { message: 'Department data is successfully Imported' }, status: :created
    end

    def export
      csv_data = Department.all
      respond_to do |format|
        format.csv { send_data csv_data.to_csv, filename: "department-#{DateTime.now}.csv" }
      end
    end

    def filter
      departments = Department.all
      departments = departments.where(name: params[:name]) if params[:name].present?
      if params[:role_id].present?
        departments = departments.where(creator_id: AccountBlock::Account.where(role_id: params[:role_id]).ids)
      end
      departments = departments.paginate(page: params[:page], per_page: 20)
      if departments.present?
        render json: DepartmentSerializer.new(departments, meta: { total_pages: departments.total_pages, message: ' Department filtered list' }).serializable_hash,
               status: :ok
      else
        render json: { message: 'No records.' }, status: :not_found
      end
    end

    def search
      departments = Department.where('name ILIKE ?', "%#{params[:name]}%").paginate(page: params[:page], per_page: 20)
      if departments.present?
        render json: DepartmentSerializer.new(departments, meta: { total_pages: departments.total_pages, message: 'Department search list' }).serializable_hash,
               status: :ok
      else
        render json: { message: 'No records.' }, status: :not_found
      end
    end

    private

      def department_params
        params.permit(:name, :lead, :email, :parent_department_id)
      end

      def set_department
        @department = Department.find(params[:id])
        render json: { message: 'Record not found' }, status: :not_found unless @department.present?
      end
  end
end
