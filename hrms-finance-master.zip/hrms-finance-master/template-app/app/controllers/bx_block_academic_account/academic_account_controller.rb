module BxBlockAcademicAccount
  class AcademicAccountController < ApplicationController
    before_action :current_user
    before_action :set_academic_account, only: [:update,:show, :destroy]

    def index
      academic_account = params[:page].present? ? AcademicAccount.order_by_created.paginate(page: params[:page], per_page: 20) : AcademicAccount.order_by_created.paginate(page: params[:page], per_page: nil)
      if academic_account.present?
        render json: AcadamicAccountSerializer.new(academic_account, meta: {total_pages: academic_account.total_pages, message: "Academic account lists"}).serializable_hash, status: :ok
      else
        render json: {message:"No records."}, status: :ok
      end
    end

    def create
      return render json: {errors: {message: ["Please select account type"]}}, status: :unprocessable_entity unless params[:academic_account][:account_type_id].present?
      academic_account = BxBlockAcademicAccount::AcademicAccount.new(academic_account_params)
      if academic_account.save
        if academic_account.is_sub_account?
          academic_account.update(parent_academic_account_id: params[:academic_account][:parent_academic_account_id])
        end
        render json: AcadamicAccountSerializer.new(academic_account, meta: {message: "Academic Account successfully Created."}).serializable_hash, status: :created
      else
        error = academic_account.errors.messages
        if error.keys.include?(:name)
          render json: {name_error: error[:name][0]}, status: :unprocessable_entity
        else
          render json: {other_error: error[error.keys[0]][0]}, status: :unprocessable_entity
        end
      end
    end

    def update
      return render json: {errors: {message: ["Please select account type"]}}, status: :unprocessable_entity unless params[:academic_account][:account_type_id].present?
      return render json: {errors: {message: ["Self account can't be parent account"]}}, status: :unprocessable_entity if params[:academic_account][:parent_academic_account_id].to_s == @academic_account.id.to_s
      if @academic_account.update(academic_account_params)
        if @academic_account.is_sub_account?
          @academic_account.update(parent_academic_account_id: params[:academic_account][:parent_academic_account_id])
        else
          @academic_account.update(parent_academic_account_id: nil)
        end
        render json: AcadamicAccountSerializer.new(@academic_account, meta: {message: "Academic account successfully Updated."}).serializable_hash, status: :created
      else
        error = @academic_account.errors.messages
        if error.keys.include?(:name)
          render json: {name_error: error[:name][0]}, status: :unprocessable_entity
        else
          render json: {other_error: error[error.keys[0]][0]}, status: :unprocessable_entity
        end
      end
    end

    def show
      render json: AcadamicAccountSerializer.new(@academic_account, meta: {message: "AcademicAccount Details."}).serializable_hash, status: :created
    end

    def destroy
      @academic_account.destroy
      render json: {message:"Academic Account was successfully destroyed."}, status: :ok
    end

    def bulk_destroy
      academic_account = AcademicAccount.where(id: params[:ids].split(","))
      return no_records_found unless academic_account.any?
      if academic_account.destroy_all
        render json: { message: 'Academic accounts was successfully destroyed.' }, status: :ok
      else
        render json: { errors: academic_account.errors }, status: :unprocessable_entity
      end
    end

    def account_types
      account_types = AccountType.all
      render json: AccountTypeSerializer.new(account_types), status: :ok
    end

    def account_type_lists
      account_types = ["Income", "Other Income", "Expense", "Cost of Goods Sold", "Other Expense", "Equity", "Liability", "Other Current Liability", "Credit Card", "Long Term Liability", "Other Liability", "Assets", "Other Asset", "Other Current Asset", "Cash", "Bank", "Fixed Asset", "Stock"]
      render json: {data: account_types}, status: :ok
    end

    def parent_accounts
      account_type = AccountType.find_by(id: params[:account_type_id])
      parent_account = account_type.academic_accounts.order("created_at ASC")
      render json: ParentAccountSerializer.new(parent_account), status: :ok
    end

    def fee_accounts
      academic_accounts = AcademicAccount.order_by_created
      render json: FeeAccountsSerializer.new(academic_accounts, meta: {}).serializable_hash, status: :ok
    end

    def import
      if CSV.read(params[:file].path).empty? || CSV.read(params[:file].path)[0].empty?
        return render json: { common_error: 'No records in CSV.' }, status: :not_found
      end
      unless CSV.foreach(params[:file], headers: true).count >= 1
        return render json: { common_error: 'No records in CSV.' }, status: :not_found
      end
      unless (["Account Name", "Account Type"] - CSV.open(params[:file].path, &:readline)).empty?
        return render json: { common_error: 'Invalid headers' }, status: :not_found
      end
      begin
        invaild_data = AcademicAccount.import(params[:file])
        if invaild_data.present?
          respond_to do |format|
            format.csv { send_data generate_csv(invaild_data), filename: "invaild_data_of_accounts.csv" }
          end
        else
          render json: {message: "All Accounts are imported successfully."}, status: :ok
        end
      rescue => e
        e.to_s.slice!("Validation failed: Name") if e.to_s.include?("Validation failed: Name")
        render json: { error: e }
      end
    end

    def academic_account_csv_sample_file
      csv_data = AcademicAccount.order(:id).limit(3)
      respond_to do |format|
        format.csv { send_data csv_data.to_sample_csv, filename: "sample_file_for_academic_account.csv" }
      end
    end

    def export
      csv_data = AcademicAccount.order(:id)
      respond_to do |format|
        format.csv { send_data csv_data.to_csv, filename: "Account-#{DateTime.now}.csv" }
      end
    end

    def bulk_update
      academic_accounts = AcademicAccount.where(id: params[:ids])
      if academic_accounts.any?
        academic_accounts.each do |acad_account|
          if params[:is_sub_account]
            acad_account.update(is_sub_account_params)
          else
            acad_account.update(acad_account_params)
          end
        end
        render json: AcadamicAccountSerializer.new(academic_accounts, meta: {message: "Academic Account successfully Updated."}).serializable_hash, status: :created
      else
        no_records_found
      end
    end

    def search
      if BxBlockAcademicAccount::AccountType.where("name ILIKE ?", "#{params[:name].strip}%").present?
        academic_accounts = AcademicAccount.joins('INNER JOIN account_types t on t.id = academic_accounts.account_type_id').where('t.name ILIKE ?', "#{params[:name].strip}%").order_by_created.paginate(page: params[:page], per_page: 20)
      else
        academic_accounts = AcademicAccount.where('name ILIKE ? OR code ILIKE ?', "%#{params[:name].strip}%", "%#{params[:name].strip}%").order_by_created.paginate(page: params[:page], per_page: 20)
      end
      if academic_accounts.present?
        render json: AcadamicAccountSerializer.new(academic_accounts, meta: { total_pages: academic_accounts.total_pages, message: 'Accounts search list' }).serializable_hash, status: :ok
      else
        no_records_found
      end
    end
    
    private

    def set_academic_account
      @academic_account =  AcademicAccount.find_by(id: params[:id])
      render json: {message:"Academic Account not found"}, :status => :not_found unless @academic_account.present?
    end

    def no_records_found
      render json: { message: 'No records.' }, status: :not_found
    end

    def academic_account_params
      params.require(:academic_account).permit(:name, :description, :code, :account_type_id, :is_sub_account)
    end

   def is_sub_account_params
      params.permit(:account_type_id, :parent_academic_account_id, :is_sub_account)
    end

    def acad_account_params
      params.permit(:account_type_id)
    end

    def generate_csv(data)
      attributes = ["Account Name", "Account Type", "Account Code", "Description", "Parent Account", "Error"]
      CSV.generate(headers: true) do |csv|
        csv << attributes
        data.each do |acad_account|
          csv << acad_account.to_h
        end
      end
    end

  end
end