module BxBlockContentmanagement
	class ItemsController < ApplicationController
    before_action :current_user
    before_action :set_items, only: %i[show update destroy]

    def index
      items = items_data.order(id: :desc)
      if items.present?
        render json: ItemsSerializer.new(items).serializable_hash, status: :ok
      else
        not_found
      end
    end

    def user_items
      items = current_user.items
      if items.present?
        render json: ItemsSerializer.new(items).serializable_hash, status: :ok
      else
        not_found
      end
    end

    def create
  		item = current_user.items.new(item_params)
  		if item.save
    		render json: ItemsSerializer.new(item).serializable_hash, status: :ok
    	else
    		render json: { errors: format_activerecord_errors(item.errors)}, status: :unprocessable_entity
    	end
    end

    def show
    	if @item.present?
    		render json: ItemsSerializer.new(@item).serializable_hash, status: :ok
    	else
    		not_found
    	end
    end

    def update
    	if @item.update(item_params)
        render json: ItemsSerializer.new(@item).serializable_hash, status: :ok
      else
        render json: { errors: format_activerecord_errors(@item.errors) }, status: :unprocessable_entity
      end
    end

    def destroy
      if @item.destroy
      	render json: {message: 'Item is successfully destroyed.' }, status: :ok
      else
        render json: { errors: format_activerecord_errors(@item.errors) }, status: :unprocessable_entity
      end
    end

    def bulk_destroy
      items = Item.where(id: params[:ids].split(','))
      return not_found unless items.any?
      if items.destroy_all
        render json: { message: 'Items was successfully destroyed.' }, status: :ok
      else
        render json: { errors: items.errors }, status: :unprocessable_entity
      end
    end

    def filter
      @items = items_data
      if params[:item_type].present?
        @items = @items.where(item_type: params[:item_type])
      end
      if params[:unit_id].present?
        @items = @items.where(unit_id: params[:unit_id])
      end
      @items = @items.order("created_at DESC").paginate(page: params[:page], per_page: 20)
      if @items.present?
        render json: ItemsSerializer.new(@items, meta: { total_pages: @items.total_pages, message: 'Item filtered list' }).serializable_hash, status: :ok
      else
        not_found
      end
    end

    def import
      if CSV.read(params[:file].path)[0].empty?
        return render json: { common_error: 'File is empty.' }, status: :not_found
      end
      unless (CSV.open(params[:file].path, &:readline) - %w[hsn_or_sac name price unit]).empty?
        return render json: { common_error: 'Invalid headers' }, status: :not_found
      end
      if CSV.read(params[:file].path)[1].empty?
        return render json: { common_error: 'No records in CSV.' }, status: :not_found
      end
      invaild_data = Item.import(params[:file], current_user)
      if invaild_data.present?
        respond_to do |format|
            format.csv { send_data generate_csv(invaild_data), filename: 'invaild_data_of_concession.csv' }
        end
      else
        render json: { message: 'All concession are imported successfully.' }, status: :created
      end
    end

    def export
      respond_to do |format|
        format.csv { send_data items_data.order(:id).to_csv, filename: "item_#{DateTime.now}.csv" }
      end
    end

    private

    def set_items
      @item = Item.find_by(id: params[:id])
      return not_found unless @item.present?
    end

    def item_params
      params.require(:data).permit(:item_type, :name, :unit_id, :hsn_or_sac, :tax_preference, item_informations_attributes: [:information_type, :price, :information_account, :description])
    end

    def items_data
      Item.all
    end

    def generate_csv(data)
      attributes = %w[hsn_or_sac name price unit]
      CSV.generate(headers: true) do |csv|
        csv << attributes
        data.each do |role|
          csv << role.to_h
        end
      end
    end
  end
end