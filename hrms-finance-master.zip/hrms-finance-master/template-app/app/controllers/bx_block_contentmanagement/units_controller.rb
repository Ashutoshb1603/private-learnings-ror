module BxBlockContentmanagement
  class UnitsController < ApplicationController
    before_action :current_user

    def create
      @unit = Unit.new(unit_params.merge(account_id:current_user.id))
      if @unit.save
        render json: UnitsSerializer.new(@unit).serializable_hash, status: :created
      else
         render json: { errors: format_activerecord_errors(@unit.errors)}, status: :unprocessable_entity
      end
    end

    def index
      @units = Unit.all
      if @units.present?
        render json: UnitsSerializer.new(@units).serializable_hash, status: :ok
      else
        render json: { errors: "units not present"}, status: :unprocessable_entity
      end
    end

    def update_unit
      unit_arr = []
      if unit_params.present?
        unit_params.each do |unit_data|
          @unit = Unit.find_by(id: unit_data["id"])
          if @unit.present?
            if @unit.update(unit_data)
              unit_arr << UnitsSerializer.new(@unit).serializable_hash[:data]
            else
              unit_arr << { errors: format_activerecord_errors(@unit.errors)}
            end
          else
            unit_arr << { errors: "unit is not present with this id #{unit_data["id"]}"}
          end
        end
      else
        unit_arr << {errors: "Please enter unit data"}
      end
      render json: {data: unit_arr}
    end

    def destroy
      @unit = Unit.find_by(id: params[:id], account_id: current_user.id)
      if @unit.present?
        @unit.destroy
        render json: {message:"Unit is successfully destroyed."}, status: :ok
      else
        render json: {errors:"Unit not found"}, :status => :not_found
      end
    end

    private

    def unit_params
      jsonapi_deserialize(params)
    end
  end
end