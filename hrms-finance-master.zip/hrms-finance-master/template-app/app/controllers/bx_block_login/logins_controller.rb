module BxBlockLogin
  class LoginsController < ApplicationController
    require "faraday"
    def create
      case params[:data][:type] #### rescue invalid API format
      when 'sms_account', 'email_account', 'social_account'
        account = OpenStruct.new(jsonapi_deserialize(params))
        account.type = params[:data][:type]

        output = AccountAdapter.new

        output.on(:account_not_found) do |account|
          render json: {
            errors: [{
              failed_login: 'Account not found, or not activated',
            }],
          }, status: :unprocessable_entity
        end

        output.on(:failed_login) do |account|
          render json: {
            errors: [{
              failed_login: 'Your password is incorrect',
            }],
          }, status: :unauthorized
        end

        output.on(:successful_login) do |account, token|
          account.update(lms_token: token)
          role = account&.role&.name
          render json: {meta: {role: role, account: account, token: token, profile_id: account&.profile&.id}}
        end

        output.login_account(account)
      else
        render json: {
          errors: [{
            account: 'Invalid Account Type',
          }],
        }, status: :unprocessable_entity
      end
    end
    def create_opt_for_login
      json_params = jsonapi_deserialize(params)
      if json_params['email'].present?
        # Get account by email
        account = AccountBlock::Account.where("LOWER(email) = ?", json_params['email'].strip.downcase).first
        return render json: {errors: [{account: 'Invalid Email'},]}, status: :unprocessable_entity if account.nil?
        return render json: {errors: [{account: 'Invalid Password'},]}, status: :unprocessable_entity unless account.authenticate(params[:data][:attributes][:password])
        return check_account_status if !account.activated
        account.update(login_type: "Email")

        email_otp = AccountBlock::EmailOtp.new(email: account.email.downcase)
        if email_otp.save
          send_email_for email_otp
          render json: serialized_email_otp(email_otp, account.id),
            status: :created
        else
          render json: {
            errors: [email_otp.errors],
          }, status: :unprocessable_entity
        end
      elsif json_params['full_phone_number'].present?
        # Get account by phone number
        phone = Phonelib.parse(json_params['full_phone_number']).sanitized
        account = AccountBlock::Account.find_by(full_phone_number: phone)
        return render json: {errors: [{account: 'Invalid Phone number or Password'},]}, status: :unprocessable_entity if account.nil?
        return render json: {errors: [{account: 'Invalid Password'},]}, status: :unprocessable_entity unless account.authenticate(params[:data][:attributes][:password])
        return check_account_status if !account.activated
        account.update(login_type: "Phone")

        sms_otp = AccountBlock::SmsOtp.new(full_phone_number: phone)
        if sms_otp.save
          render json: serialized_sms_otp(sms_otp, account.id), status: :created
        else
          render json: {
            errors: [sms_otp.errors],
          }, status: :unprocessable_entity
        end
      else
        return render json: {errors: [{account: 'Email or phone number required'},]}, status: :unprocessable_entity
      end
    end

    def login_otp_confirmation
      if create_params[:token].present? && create_params[:otp_code].present?
        # Try to decode token with OTP information
        begin
          token = BuilderJsonWebToken.decode(create_params[:token])
        rescue JWT::ExpiredSignature
          return render json: {
            errors: [{
              pin: 'OTP has expired, please request a new one.',
            }],
          }, status: :unauthorized
        rescue JWT::DecodeError => e
          return render json: {
            errors: [{
              token: 'Invalid token',
            }],
          }, status: :bad_request
        end

        # Try to get OTP object from token
        begin
          otp = token.type.constantize.find(token.id)
        rescue ActiveRecord::RecordNotFound => e
          return render json: {
            errors: [{
              otp: 'Token invalid',
            }],
          }, status: :unprocessable_entity
        end

        # Check OTP code
        if otp.pin == create_params[:otp_code].to_i
          if otp.created_at + 5.minutes < Time.now
            otp.destroy
            return render json: {errors: [{otp: 'OTP has expired, please request a new one or Resend OTP.'}]}, status: :unauthorized
          else
            otp.activated = true
            otp.save
            # if params[:data][:type] == "email_otp"
              if otp.class.name == "AccountBlock::SmsOtp"
                account = AccountBlock::Account.find_by(full_phone_number: otp.full_phone_number)
              else
                account = AccountBlock::Account.find_by(email: otp.email)
              end
              token = BuilderJsonWebToken.encode(account.id)
              # Delete OTP object as it's not needed anymore
              otp.destroy
              role = account&.role&.name
              account.update(lms_token: token)
              return render json: AccountBlock::EmailAccountSerializer.new(account, meta: {role: role, token: token, otp: "OTP validation success"}).serializable_hash, status: :created
              # return render json: {meta: {role: role, account: account, token: token, profile_id: account&.profile&.id, otp: "OTP validation success"}}, status: :created
            # else
            #   render json: {
            #     messages: [{
            #       otp: 'OTP validation success',
            #     }],
            #   }, status: :created
            # end
          end
        else
          return render json: {
            errors: [{
              otp: 'OTP has been expired/invalid. Please request a new one and try again.',
            }],
          }, status: :unprocessable_entity
        end
      else
        return render json: {
          errors: [{
            otp: 'Token and OTP code are required',
          }],
        }, status: :unprocessable_entity
      end
    end

    def resend_otp
      decode_token = BuilderJsonWebToken.decode(request.headers[:token]) if request.headers[:token]
      @token ||= decode_token
      current_user ||= AccountBlock::Account.find(@token.account_id) if @token
      if current_user.login_type == "Email"
        email_otp = AccountBlock::EmailOtp.new(email: current_user.email.downcase)
        if email_otp.save
          send_email_for(email_otp)
          token = token_for(email_otp, current_user.id)
          render json: BxBlockForgotPassword::EmailOtpSerializer.new(email_otp,
            meta: { token: token, message: "OTP sent successfully!" }).serializable_hash
        else
          render json: {
            errors: [email_otp.errors],
          }, status: :unprocessable_entity
        end
      else
        phone = Phonelib.parse(current_user.full_phone_number).sanitized
        sms_otp = AccountBlock::SmsOtp.new(full_phone_number: phone)
        if sms_otp.save
          token = token_for(sms_otp, current_user.id)
          render json: BxBlockForgotPassword::SmsOtpSerializer.new(sms_otp,
            meta: { token: token, message: "OTP sent successfully!" }).serializable_hash
        else
          render json: {
             errors: [sms_otp.errors],
          }, status: :unprocessable_entity
        end
      end
    end
    def login_with_lms
      account_params = OpenStruct.new(jsonapi_deserialize(params))
      if account_params.email.present?
        account = AccountBlock::Account.find_by(email: account_params.email)
      else
        phone = Phonelib.parse(account_params.full_phone_number).sanitized
        account = AccountBlock::Account.find_by(full_phone_number: phone)
      end
      if (account.present? && account&.lms_account_id.present?) || (account&.lms_role == "admin") || account.nil?
        data = LmsBlock::AccountBlock::LoginService.new().login_with_email_password(account_params)
        render json: data
      else
        data = HrmsBlock::AccountBlock::LoginService.new().login_with_email_password(account_params)
        render json: data, status: :ok if data.present?
      end
    end

    def resend_otp_with_lms
      if ActiveModel::Type::Boolean.new.cast(params[:is_otp_from_lms])
        data = LmsBlock::AccountBlock::OtpService.new().resend_otp(request.headers["token"])
        render json: data, status: :ok if data.present?
      else
        data = HrmsBlock::AccountBlock::LoginService.new().resend_otp(request.headers["token"])
        render json: data, status: :ok if data.present?
      end

      # if request.headers[:hrmstoken] == "hrms"
      #   decode_token = BuilderJsonWebToken.decode(request.headers[:token]) if request.headers[:token]
      #   @token ||= decode_token
      # end
      # account ||= AccountBlock::Account.find(@token.account_id) if @token
      # if (account.present? && account&.lms_account_id.present?) || (account&.lms_role == "admin") || account.nil?
      #   data = LmsBlock::AccountBlock::OtpService.new().resend_otp(request.headers["token"])
      #   render json: data, status: :ok if data.present?
      # else
      #   data = HrmsBlock::AccountBlock::LoginService.new().resend_otp(request.headers["token"], request.headers[:hrmstoken])
      #   render json: data, status: :ok if data.present?
      # end
    end

    def create_active_admin
      admin_user = BxBlockAdminConsole::AdminUser.new(email: 'admin@builder.ai', password: 'AdminUser@1234', password_confirmation: 'AdminUser@1234')
      if admin_user.save
      else
        render json: {errors: admin_user.errors }, status: :unprocessable_entity
      end
    end
    # def check_phone_number
    #   if params['full_phone_number'].present?
    #     query_phone_number = params['full_phone_number']
    #     query_phone_number = query_phone_number.gsub("+", "")
    #     query_phone_number = query_phone_number.gsub(" ", "")
    #     unless Phonelib.valid?(params['full_phone_number'])
    #       return render json: {error_code: 421, errors: "Invalid or Unrecognized Phone Number"}
    #     else
    #       return render json: {error_code: 200, errors: "no_error"}
    #     end
    #   end
    # end
    def send_email_for(otp_record)
      BxBlockForgotPassword::EmailOtpMailer
        .with(otp: otp_record, host: request.base_url)
        .otp_email.deliver
    end

    def serialized_email_otp(email_otp, account_id)
      token = token_for(email_otp, account_id)
      BxBlockForgotPassword::EmailOtpSerializer.new(
        email_otp,
        meta: { token: token, is_otp_from_lms: false }
      ).serializable_hash
    end

    def serialized_sms_otp(sms_otp, account_id)
      token = token_for(sms_otp, account_id)
      BxBlockForgotPassword::SmsOtpSerializer.new(
        sms_otp,
        meta: { token: token, is_otp_from_lms: false }
      ).serializable_hash
    end

    def token_for(otp_record, account_id)
      BuilderJsonWebToken.encode(
        otp_record.id,
        5.hours.from_now,
        type: otp_record.class,
        account_id: account_id
      )
    end
    private
    def check_account_status
      return render json: {errors: [{account: "Account not approved yet"}]}, status: :ok
    end
    def create_params
      params.require(:data)
        .permit(*[
          :email,
          :full_phone_number,
          :token,
          :otp_code,
          :new_password,
          :type,
        ])
    end
  end
end
