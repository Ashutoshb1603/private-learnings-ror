module BxBlockAcademicYear
  class AcademicYearsController < ApplicationController
    before_action :current_user
    before_action :set_academic_year, only: [:update,:show, :destroy]

    def index
      academic_years = AcademicYear.order("created_at DESC").paginate(page: params[:page], per_page: 20)
      if academic_years.present?
        render json: AcademicYearSerializer.new(academic_years, meta: {total_pages: academic_years.total_pages, message: "Academic year lists"}).serializable_hash, status: :ok
      else
        render json: {message:"No records."}, status: :ok
      end
    end

    def year_lists
      academic_years = AcademicYear.order("created_at DESC")
      if academic_years.present?
        render json: AcademicYearSerializer.new(academic_years, meta: {message: "Academic year lists"}).serializable_hash, status: :ok
      else
        render json: {message:"No records."}, status: :ok
      end
    end
    
    def create
      academic_year = BxBlockAcademicYear::AcademicYear.new(academic_year_params)
      if academic_year.save
        render json: AcademicYearSerializer.new(academic_year, meta: {message: "Academic year successfully Created."}).serializable_hash, status: :created
      else
        render json: {errors: academic_year.errors}, status: :unprocessable_entity
      end
    end

    def update
      if @academic_year.update(academic_year_params)
        render json: AcademicYearSerializer.new(@academic_year, meta: {message: "Academic year successfully Updated."}).serializable_hash, status: :created
      else
        render json: {errors: @academic_year.errors}, status: :unprocessable_entity
      end 
    end

    def show
      render json: AcademicYearSerializer.new(@academic_year, meta: {message: "Academic year Details."}).serializable_hash, status: :created
    end

    def destroy
      @academic_year.destroy
      render json: {message:"Academic year was successfully destroyed."}, status: :ok
    end

    private

    def set_academic_year
      @academic_year =  AcademicYear.find_by(id: params[:id])
      render json: {message:"Academic year not found"}, :status => :not_found unless @academic_year.present?
    end

    def academic_year_params
      params.require(:academic_year).permit(:year)
    end
  end
end
