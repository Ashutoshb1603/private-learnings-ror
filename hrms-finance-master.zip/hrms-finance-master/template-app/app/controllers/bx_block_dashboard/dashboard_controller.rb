module BxBlockDashboard
    class DashboardController < ApplicationController
        def fee_collection
            students = LmsBlock::StudentBlock::StudentsService.new.students_list(current_user.school_id, params[:page],
                                                                                 per_page: 20)
            return render json: students unless students['status'] == 200
      
            fee_collection = students['data'].map { |student| student_fee_collection(student) }
# we need to filter fee_collection data by today date 
# and distribute this data in some formate like year wise data, monthly wise, curret date, recieved, outstanding, recieveile.
# we also need to filter this data by studante class & division & date
# 
            if fee_collection.present?
              render json: { data: fee_collection }, status: :ok
            else
              render json: { message: 'No records.' }, status: :not_found
            end
        end

        def student_fee_collection(student)
            fee_structures = FeeStructure.includes(:installments).joins(:student_fee_structures).find_by(
              'student_fee_structures.student_id = ?', student['id']
            )
            fee_structures = FeeCollectionSerializer.new(fee_structures).serializable_hash
            student.merge(fee_structures: fee_structures)
        end
      
    end
  end
  