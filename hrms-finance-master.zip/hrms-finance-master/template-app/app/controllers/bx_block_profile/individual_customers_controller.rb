module BxBlockProfile
	class IndividualCustomersController < ApplicationController
    before_action :current_user,except: [:customers_search]

    def create
			individual_customer_arr = []

    	if individual_params["primary_details"].present? && individual_params["contact_details"].present?
    		errors = primary_params_validate(individual_params)
    		        return render json: {errors: errors}, status: :unprocessable_entity if errors.present?
			 	@individual_detail = current_user.individual_customers.new(individual_params["primary_details"])

		    if @individual_detail.save
					 	@contact_detail = BxBlockAddress::ContactDetail.new(individual_params["contact_details"])
					 	@contact_detail.individual_customer_id = @individual_detail.id
				    unless @contact_detail.save
				   	  individual_customer_arr << {contact_details: {errors: format_activerecord_errors(@contact_detail.errors)}}
				    end
					if individual_params["secondary_details"].present?
						individual_params["secondary_details"].each do |secondary_params|
						  @secondary_detail = @individual_detail.secondary_details.new(secondary_params)
							unless @secondary_detail.save
								individual_customer_arr << { secondary_details: {errors: format_activerecord_errors(@secondary_detail.errors)}}
							end
				   	end
				  end
		   	  render json: {data: IndividualCustomersSerializer.new(@individual_detail).serializable_hash[:data], errors:individual_customer_arr }, status: :created
		    else
		   	  render json: { errors: format_activerecord_errors(@individual_detail.errors)}, status: :unprocessable_entity
		    end
			end
    end

    def show
			@primary_detail = IndividualCustomer.find_by(id: params[:id]) # if we use find it will give error record not found and following code not work.
			if @primary_detail.present?
	      render json: IndividualCustomersSerializer.new(@primary_detail).serializable_hash , status: :ok
	    else
	    	render json: {errors:"Individual Customer not found"}, :status => :not_found
	    end
    end

    def update
      individual_customer_arr = []
      

    	if individual_params["primary_details"].present? 
        errors = primary_params_validate(individual_params) 
        return render json: {errors: errors}, status: :unprocessable_entity if errors.present?
				@primary_detail = IndividualCustomer.find_by(id: params[:id])
				if @primary_detail.present?
					primary_params = individual_params["primary_details"]
			     unless @primary_detail.update!(primary_params)
			   	  individual_customer_arr << { errors: format_activerecord_errors(@primary_detail.errors)}
			    end

					if individual_params["contact_details"].present? 
						@contact_detail = @primary_detail.contact_detail
						if @contact_detail.present?
							contact_params = individual_params["contact_details"].delete_if {|key, value| value.blank? }
					    unless @contact_detail.update!(contact_params)
					   	  individual_customer_arr << { contact_details: { errors: format_activerecord_errors(@contact_detail.errors)}}
					    end
						else
							individual_customer_arr << {contact_details: { errors: "Contact Details not exist" }} 
						end
					end

					if individual_params["secondary_details"].present? 
					  individual_params["secondary_details"].each do |secondary_params|
					  	 @secondary_detail = @primary_detail.secondary_details.find_by(id: secondary_params["id"])
						  if @secondary_detail.present?
								secondary_params_data = secondary_params.delete_if {|key, value| value.blank? }
								unless @secondary_detail.update!(secondary_params_data)
									individual_customer_arr << { secondary_details: { errors: format_activerecord_errors(@secondary_detail.errors)}}
								end
						  else
								individual_customer_arr << { secondary_details: { errors: "Secondary Details not exist for this id #{secondary_params["id"]}" }}
					 		end
					 	end
					end
         return render json: {data: IndividualCustomersSerializer.new(@primary_detail).serializable_hash[:data], errors: individual_customer_arr}, status: :ok
			  else
					return render json: { errors: "Primary Details not exist" }, status: :unprocessable_entity 
				end
			end
			
    end

    def destroy
      @individual_customer = IndividualCustomer.find_by(id: params[:id], account_id: current_user.id)
      if @individual_customer.present?
        @individual_customer.destroy
      	render json: {message:"Individual Customer was successfully destroyed."}, status: :ok
      else
        render json: {errors:"Individual Customer not found"}, :status => :not_found
      end
    end

     def get_states_name
      contries = Country[:IN]
      state_arr = []
      contries.states.each do |key, value|
        state_name = "#{value.name}"
        state_arr << {name: state_name} if state_name.present?
      end
      render json: {data: state_arr}, status: :ok 
    end

    def get_nationality
    	country_arr = [{name: "India"}]
    	country = Country.codes.map{|code| Country[code].name}.sort.select{|c| c!= "India"}.map { |country| { name: country }}
       country_arr << country
    	render json: {data: country_arr.flatten}, status: :ok
    end

    def customers_search
    #   @individual_customer = BxBlockProfile::IndividualCustomer.where(" first_name LIKE ? OR email LIKE ?","%#{params[:search_term]}%","%#{params[:search_term]}%")
    #   @business_customer = BxBlockProfile::BusinessCustomer.where(" company_name LIKE ? OR email LIKE ?","%#{params[:search_term]}%","%#{params[:search_term]}%")
	    #   return render json: {individual_customer: @individual_customer,business_customer: @business_customer } 
      # result = @individual_customer+@business_customer
      # return render json: {data: result} 
	 customer_list = []
	 params[:page] = params[:page].present? ? params[:page] : 1
	  if params[:search_term].present? 
		
		@individual_customers = BxBlockProfile::IndividualCustomer.where("first_name ILIKE ? OR last_name ILIKE ? OR email ILIKE ?", 
											  "%#{params[:search_term]}%", "%#{params[:search_term]}%", "%#{params[:search_term]}%").paginate(page: params[:page], per_page: 10)
	    customer_list << CustomerDetailsSerializer.new(@individual_customers, params: {customer_type: "individual"}).serializable_hash[:data] if @individual_customers.present?
		
		@business_customers = BxBlockProfile::BusinessCustomer.where("company_name ILIKE ? OR email ILIKE ?", "%#{params[:search_term]}%", "%#{params[:search_term]}%"
											  ).paginate(page: params[:page], per_page: 10)
		customer_list << CustomerDetailsSerializer.new(@business_customers, params: {customer_type: "business"}).serializable_hash[:data] if @business_customers.present?
        
      else
		@business_customers = BusinessCustomer.all.order('created_at desc').paginate(page: params[:page], per_page: 10)
		customer_list << CustomerDetailsSerializer.new(@business_customers, params: {customer_type: "business"}).serializable_hash[:data]
  
		@individual_customers = IndividualCustomer.order('created_at desc').all.paginate(page: params[:page], per_page: 10)
		customer_list << CustomerDetailsSerializer.new(@individual_customers, params: {customer_type: "individual"}).serializable_hash[:data]
	  end

		total_pages = @individual_customers.present? ? @individual_customers.total_pages : 0
		render json: {data: customer_list.flatten, meta:{total_pages: total_pages}}, status: :ok 
    end  
    
    def import 
      csv_data = BusinessCustomer.import(params[:file])
      render json: {message: "data is successfully imported"}, status: :ok
    end 

    def export
      csv_data = BusinessCustomer.order(:id)
      respond_to do |format|
        format.csv { send_data csv_data.to_csv, filename: "Vendor-#{DateTime.now}.csv" }
      end 
    end

    private

    def individual_params
     	jsonapi_deserialize(params)
    end

    def primary_params_validate(individual_params)
           errors = []
  		individual_params["primary_details"].each {|key, value| errors << {primary_detail:{"#{key}": "can't be blank" } } if value.blank? and key != "remarks"}
  		individual_params["contact_details"].each {|key, value| errors << {contact_detail:{"#{key}": "can't be blank" } } if value.blank? }
			individual_params["secondary_details"].each { |secondary_detail| secondary_detail.each {|key, value| errors <<  {"#{key}": "can't be blank" } if value.blank? }}
			
    		return errors
    end

    # def current_user
    #   validate_json_web_token 
    #   @current_user ||= AccountBlock::Account.find(@token.id) if @token.present? rescue  AccountBlock::Account.first #this need to be removed once the token issue is fixed
    # end

	end
end