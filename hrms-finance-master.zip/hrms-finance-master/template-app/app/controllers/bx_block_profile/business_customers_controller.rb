module BxBlockProfile
	class BusinessCustomersController < ApplicationController
    before_action :current_user

    def create
    	if business_params["business_details"].present? && business_params["other_details"].present?
    		params_data = business_params["business_details"].merge(business_params["other_details"])
    		@business_customer = BusinessCustomer.new(params_data.merge(account_id:current_user.id))
    		if @business_customer.save
    			business_details = BusinessCustomersSerializer.new(@business_customer, params: { is_business: true }).serializable_hash[:data]
    			other_details = BusinessCustomersSerializer.new(@business_customer, params: { is_business: false }).serializable_hash[:data]
    			render json: {data: {business_details: business_details, other_details: other_details} }, status: :created
    		else
    			 render json: { errors: format_activerecord_errors(@business_customer.errors)}, status: :unprocessable_entity
    		end
    	else
    		render json: {errors: "Please enter both business_details and other_details" }, status: :unprocessable_entity
    	end
    end

    def show
      @business_customer = BusinessCustomer.find_by(id:params[:id])
    	if @business_customer.present?
    		business_details = BusinessCustomersSerializer.new(@business_customer, params: { is_business: true }).serializable_hash[:data]
	   		other_details = BusinessCustomersSerializer.new(@business_customer, params: { is_business: false }).serializable_hash[:data]
	   		render json: {data: {business_details: business_details, other_details: other_details} }, status: :ok
    	else
    		render json: { errors: "business_customer not present"}, status: :unprocessable_entity
    	end
    end

    def update
    	@business_customer = BusinessCustomer.find_by(id:params[:id])
    	if business_params["business_details"].present? && business_params["other_details"].present?
	    	if @business_customer.present?
           params_data = business_params["business_details"].merge(business_params["other_details"])
          if @business_customer.update(params_data)
           business_details = BusinessCustomersSerializer.new(@business_customer, params: { is_business: true }).serializable_hash[:data]
    			 other_details = BusinessCustomersSerializer.new(@business_customer, params: { is_business: false }).serializable_hash[:data]
    		 	render json: {data: {business_details: business_details, other_details: other_details} }, status: :ok
    		  else
    		 	render json: { errors: format_activerecord_errors(@business_customer.errors)}, status: :unprocessable_entity
    		  end
	    	else
	    		render json: { errors: "business_customer not present"}, status: :unprocessable_entity
	    	end
      else
    	render json: {errors: "Please enter both business_details and other_details" }, status: :unprocessable_entity
      end
    end

    def destroy
      @business_customer = BusinessCustomer.find_by(id: params[:id], account_id: current_user.id)
      if @business_customer.present?
        @business_customer.destroy
      render json: {message:"Business Customer was successfully destroyed."}, status: :ok
      else
        render json: {errors:"Business Customer not found"}, :status => :not_found
      end
    end

    def get_gst_treatments
      gst_treatments = GstTreatment.all
      render json: {data: gst_treatments}, status: :ok
    end

    def get_states_name
      contries = Country[:IN]
      state_arr = []
      contries.states.each do |key, value|
        state_name = "[#{key}] - #{value.name}"
        state_arr << {name: state_name} if value.name.present?
      end
      render json: {data: state_arr}, status: :ok 
    end

    def add_payment_term
      @payment_term = current_user.payment_terms.new(business_params)
      if @payment_term.save!
        render json: {data: @payment_term}, status: :ok
      else
        render json: { errors: format_activerecord_errors(@payment_term.errors)}, status: :unprocessable_entity
      end
    end

    def update_payment_term
      if params[:data].present? && params[:data][:attributes].present? && params[:data][:attributes][:payment_terms].present?
        data = []
        params[:data][:attributes][:payment_terms].each do |payment_term|
          payment =  BxBlockProfile::PaymentTerm.find(payment_term[:id])
          payment.update(term_name: payment_term[:term_name], no_of_days: payment_term[:no_of_days]) if payment.present?
          data << payment
        end
        render json: {data: data, message: "Payment Term is successfully update."}, status: :created
      else
        render json: {message:"No records."}, status: :not_found
      end
      # payment_term =  BxBlockProfile::PaymentTerm.find(params[:data][:attributes][:id])
      # if payment_term.update(term_name: params[:data][:attributes][:term_name], no_of_days: params[:data][:attributes][:no_of_days])
      #   render json: {data: payment_term, message:"Payment Term is successfully update."}, status: :ok
      # else
      #   render json: { errors: format_activerecord_errors(payment_term.errors)}, status: :unprocessable_entity
      # end
    end

    def get_payment_terms
      @payment_terms = PaymentTerm.where(status: true)
      render json: {data: @payment_terms}, status: :ok 
    end

    def destroy_payment_terms
      @payment_term = PaymentTerm.find_by(id: params[:id])
      if @payment_term.present?
        @payment_term.update(status: false)
      render json: {message:"PaymentTerm is successfully destroyed."}, status: :ok
      else
        render json: {errors:"PaymentTerm not found"}, :status => :not_found
      end
    end
    

    def customer_name_list
      data = []
      customer =  BusinessCustomer.joins(:account).select(:id,:company_name,:phone_number,"accounts.first_name AS user_first_name","accounts.last_name AS user_last_name")
      customer = customer.where('business_customers.primary_contact ILIKE ?', "%#{params[:phone].gsub(/[^0-9A-Za-z]/, '')}%") if params[:phone].present?
      customer = customer.includes(:account).where("accounts.first_name ILIKE :q OR accounts.last_name ILIKE :q", q:"%#{params[:customer_name]}%") if params[:customer_name].present?
      customer = customer.where('business_customers.company_name ILIKE ?', "%#{params[:company_name]}%") if params[:company_name].present?
      customer = customer.where('business_customers.email ILIKE ?', "%#{params[:email]}%") if params[:email].present?
      data << customer

      customer = IndividualCustomer.joins(:account).select(:id,:first_name,:last_name,:phone_number,"accounts.first_name AS user_first_name","accounts.last_name AS user_last_name")
      customer = customer.where('individual_customers.phone_number ILIKE ?', "%#{params[:phone].gsub(/[^0-9A-Za-z]/, '')}%") if params[:phone].present?
      customer = customer.where("accounts.first_name ILIKE :q OR accounts.last_name ILIKE :q", q:"%#{params[:customer_name]}%") if params[:customer_name].present?
      customer = customer.where("individual_customers.first_name ILIKE :q OR individual_customers.last_name ILIKE :q", q:"%#{params[:company_name]}%") if params[:company_name].present?
      customer = customer.where('individual_customers.email ILIKE ?', "%#{params[:email]}%") if params[:email].present?
      data << customer
      return render json: CustomersSerializer.new(data.flatten).serializable_hash, status: :ok
    end

    
    def import 
      csv_data = BusinessCustomer.import(params[:file])
      render json: {message: "data is successfully imported"}, status: :ok
    end 

    def export
      csv_data = BusinessCustomer.order(:id)
      respond_to do |format|
        format.csv { send_data csv_data.to_csv, filename: "Vendor-#{DateTime.now}.csv" }
      end 
    end

    private

    def business_params
     	jsonapi_deserialize(params)
    end
    
    # def current_user
    #   validate_json_web_token
    #   @current_user ||= AccountBlock::Account.find(@token.id) if @token.present? rescue  AccountBlock::Account.first #this need to be removed once the token issue is fixed
    # end
	end
end