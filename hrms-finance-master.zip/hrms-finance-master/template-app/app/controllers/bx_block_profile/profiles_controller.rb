module BxBlockProfile
  class ProfilesController < ApplicationController
    before_action :current_user
    before_action :set_profile, only: [:update, :show, :destroy]

    # def index
    #  organisation_profile = OrganisationProfile.order("created_at DESC").paginate(page: params[:page], per_page: 10)
    #   if organisation_profile .present?
    #     render json: OrganisationProfileSerializer.new(organisation_profile , meta: {total_pages: organisation_profile .total_pages, message: "Organisation Profile lists"}).serializable_hash, status: :ok
    #   else
    #     render json: {message:"No records."}, status: :ok
    #   end
    # end
    
    # def create
    #   return render json: {errors: [{cover_image: 'Please enter emai id'}]}, status: :unprocessable_entity unless params[:organisation_profile][:email].present?
    #   @organisation_profile_exists = OrganisationProfile.find_by(account_id: current_user.id)
    #   return render json: {errors: [{message: 'Profile already exist. You can update it.'}]}, status: :unprocessable_entity if @organisation_profile_exists.present?
    #   organisation_profile = BxBlockOrganisationProfile::OrganisationProfile.new(organisation_profile_params.merge(account_id:current_user.id))
    #   if organisation_profile.save
    #     render json: OrganisationProfileSerializer.new(organisation_profile, meta: {message: "Organisation Profile successfully Created."}).serializable_hash, status: :created
    #   else
    #     render json: {errors: organisation_profile.errors}, status: :unprocessable_entity
    #   end
    # end

    def update
      return render json: {errors: [{cover_image: 'Please fill address'}]}, status: :unprocessable_entity unless params[:profile][:address].present?
      return render json: {errors: [{cover_image: 'Please enter emai id'}]}, status: :unprocessable_entity unless params[:profile][:email].present?
      return render json: {errors: [{cover_image: 'Please enter contact no'}]}, status: :unprocessable_entity unless params[:profile][:contact_no].present?
      @profile = Profile.find_by(id: params[:id], account_id: current_user.id)
      return render json: {errors: [{message: 'Profile does not exist.'},]}, status: :unprocessable_entity unless @profile.present?
      if @profile.update(profile_params)
        render json: ProfileSerializer.new(@profile, meta: {message: "Profile successfully Updated."}).serializable_hash, status: :created
      else
        render json: {errors: @profile.errors}, status: :unprocessable_entity
      end 
    end

    def update_profile
      return render json: {errors: [{cover_image: 'Please fill address'}]}, status: :unprocessable_entity unless params[:profile][:address].present?
      return render json: {errors: [{cover_image: 'Please enter emai id'}]}, status: :unprocessable_entity unless params[:profile][:email].present?
      return render json: {errors: [{cover_image: 'Please enter contact no'}]}, status: :unprocessable_entity unless params[:profile][:contact_no].present?
      @profile = current_user.profile
      return render json: {errors: [{message: 'Profile does not exist.'},]}, status: :unprocessable_entity unless @profile.present?
      if @profile.update(profile_params)
        render json: ProfileSerializer.new(@profile, meta: {message: "Profile successfully Updated."}).serializable_hash, status: :created
      else
        render json: {errors: @profile.errors}, status: :unprocessable_entity
      end 
    end

    def update_profile_pic
      @profile = current_user.profile
      if @profile.present?
        @profile.profile_pic.attach(params[:profile][:profile_image])
        render json: ProfileSerializer.new(@profile, meta: {message: "Profile pic successfully uploaded."}).serializable_hash, status: :created
      end
    end

    def show
      render json: ProfileSerializer.new(@profile, meta: {message: "Profile Details."}).serializable_hash, status: :created
    end

    def profile_detail
      render json: ProfileSerializer.new(current_user.profile, meta: {message: "Profile Details."}).serializable_hash, status: :ok
    end

    def destroy
      @profile.destroy
      render json: {message:"Profile was successfully destroyed."}, status: :ok
    end
    
    def get_all_customers
      return render json: all_customer
      # customer_list = []
      # @business_customers = BusinessCustomer.all.order('created_at desc').paginate(page: params[:page], per_page: 10)
      # customer_list << CustomerDetailsSerializer.new(@business_customers, params: {customer_type: "business"}).serializable_hash[:data]

      # @individual_customers = IndividualCustomer.order('created_at desc').all.paginate(page: params[:page], per_page: 10)
      # customer_list << CustomerDetailsSerializer.new(@individual_customers, params: {customer_type: "individual"}).serializable_hash[:data]
       
      # total_pages = @business_customers.total_pages
      # render json: {data: customer_list.flatten, meta:{total_pages: total_pages}}, status: :ok 
    end

    def delete_customers
      params["business_customers"] = params["business_customers"].class == Array ? params["business_customers"] : JSON.parse(params["business_customers"])
      params["individual_customers"] = params["individual_customers"].class == Array ? params["individual_customers"] : JSON.parse(params["individual_customers"])
      
      return render json: {errors:"Please enter business customer ids or individual customer ids."} unless params["business_customers"].present? || params["individual_customers"].present?
      customers_arr = []
      if params["business_customers"].present?
        @business_customers = BusinessCustomer.where(id: params["business_customers"])
        if @business_customers.present?
          @business_customers.destroy_all
          customers_arr << {message:"Business Customers is successfully destroyed."}
        else
          customers_arr << {errors:"Business Customers not present."}
        end
      end
      if params["individual_customers"].present?
        @individual_customers = IndividualCustomer.where(id: params["individual_customers"])
        if @individual_customers.present?
          @individual_customers.destroy_all
          customers_arr << {message:"Individual Customers is successfully destroyed."}
        else
          customers_arr << {errors:"Individual Customers not present."}
        end
      end
      render json: {data: customers_arr}, status: :ok
    end


    def filter
      if params[:customer_type].present? && params[:customer_type] == "individual"
        customer = BxBlockProfile::IndividualCustomer.all
      elsif params[:customer_type].present? && params[:customer_type] == "business"
        customer = BxBlockProfile::BusinessCustomer.all
      else 
        return render json: all_customer
        # customer = BxBlockProfile::BusinessCustomer.all + BxBlockProfile::IndiviCustomer.all 
      end

      if customer.present?
        if params[:company_name].present? && params[:customer_type].present? && params[:customer_type] == "business"
          customer  = customer.where("company_name  ILIKE ?","%#{params[:company_name]}%")
        end
        if params[:primary_contact].present? && params[:customer_type].present? && params[:customer_type] == "business"
          customer  = customer.where("primary_contact  ILIKE ?","%#{params[:primary_contact]}%")
        elsif params[:primary_contact].present? && params[:customer_type] == "individual"
          customer  = customer.where("phone_number  ILIKE ?","%#{params[:primary_contact]}%")
        end
        # if params[:secondary_contact].present? && params[:customer_type].present? && params[:customer_type] == "business"
        #   vendors  = vendors.where(secondary_contact: params[:secondary_contact])
        # end
        if params[:email].present?
          customer  = customer.where("email  ILIKE ?","%#{params[:email]}%")
        end
        if params[:contact_number].present? && params[:customer_type].present? && params[:customer_type] == "business"
          customer  = customer.where("contact_number  ILIKE ?","%#{params[:contact_number]}%")
        elsif params[:contact_number].present? && params[:customer_type] == "individual"
          customer  = customer.where("phone_number  ILIKE ?","%#{params[:contact_number]}%")
        end
        page = params[:page].present? ? params[:page] : 1
        customer = customer.order("created_at DESC").paginate(page: page, per_page: 10)
        if params[:customer_type].present? && params[:customer_type] == "individual"
          customer_list = CustomerDetailsSerializer.new(customer, params: {customer_type: "individual"}).serializable_hash[:data]
          total_pages = customer.total_pages
          render json: {data: customer_list.flatten, meta:{total_pages: total_pages}}, status: :ok 
        elsif params[:customer_type].present? && params[:customer_type] == "business"
          customer_list = CustomerDetailsSerializer.new(customer, params: {customer_type: "business"}).serializable_hash[:data]
          total_pages = customer.total_pages
          render json: {data: customer_list.flatten, meta:{total_pages: total_pages}}, status: :ok 
        else
        render json: {data: [], message:"customer not found"}, :status => :not_found
        end
      else
        render json: {data: [], message:"customer not found"}, :status => :not_found
      end
      
    end 
 
    private

    def set_profile
      @profile = Profile.find_by(id: params[:id], account_id: current_user.id)
      render json: {message:"Profile not found"}, :status => :not_found unless @profile.present?
    end

    def profile_params
      params.require(:profile).permit(:name, :business_location, :address, :address2, :email, :contact_no, :license_no, :fiscal_year, :city, :state, :pin_code, :website_url, :fax_no, :profile_image)
    end

    def customers_params
      jsonapi_deserialize(params)
    end
    
    def all_customer
      customer_list = []
      @business_customers = BusinessCustomer.all.order('created_at desc').paginate(page: params[:page], per_page: 10)
      customer_list << CustomerDetailsSerializer.new(@business_customers, params: {customer_type: "business"}).serializable_hash[:data]

      @individual_customers = IndividualCustomer.order('created_at desc').all.paginate(page: params[:page], per_page: 10)
      customer_list << CustomerDetailsSerializer.new(@individual_customers, params: {customer_type: "individual"}).serializable_hash[:data]
       
      total_pages = @business_customers.total_pages
      {data: customer_list.flatten, meta:{total_pages: total_pages}, status: :ok}
    end 

  end
end
