module BuilderBase
  class ApplicationController < ::ApplicationController
    include JSONAPI::Deserialization
    # include Pundit

    rescue_from ActiveRecord::RecordNotFound, :with => :not_found
    protect_from_forgery with: :null_session

    def not_found
      render :json => {'errors' => ['Record not found']}, :status => :not_found
    end

    def current_user
      # begin
        # @current_user = AccountBlock::Account.find(@token.id)
        # @current_user = AccountBlock::Account.find_by(lms_token: request.headers[:token])
      # rescue ActiveRecord::RecordNotFound => e
      # return render json: {errors: [{message: 'Token has Expired, Please login again.'},]}, status: :unprocessable_entity if @current_user.nil?
      # end
      user = AccountBlock::Account.find_by(lms_token: request.headers[:token])
      if user.present? && user.lms_token.present?
        return user
      else
        return render json: {errors: [{token: 'Token has Expired, Please login again.'},]}, status: :unprocessable_entity
      end
    end
  end
end
