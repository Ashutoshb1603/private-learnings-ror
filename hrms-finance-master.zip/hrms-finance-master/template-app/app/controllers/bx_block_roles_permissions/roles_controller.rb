module BxBlockRolesPermissions
  class RolesController < ApplicationController
    before_action :current_user
    before_action :set_role, only: [:update,:show, :destroy]

    def index
      roles = Role.order_by_created.paginate(page: params[:page], per_page: 20)
      if roles.present?
        render json: ListsRoleSerializer.new(roles, meta: {total_pages: roles.total_pages, message: "Roles List"}).serializable_hash, status: :ok
      else
        render json: {message:"No records."}, status: :ok
      end
    end

    def create
      role = Role.new(role_params)
      if role.save
        current_user.role_created_bies.create(role_id: role.id)
        if params[:role][:role_permissions].present?
          params[:role][:role_permissions].each do |role_perm|
            unless role.role_permissions.where(menu_id: role_perm['menu_id']).present?
              actions = role_perm['actions'].map(&:camelize)
              actions.prepend('View') if %w[Create Edit Delete Approve].any? {|obj| actions.include?(obj) } && !actions.include?("View")
              permission = role.role_permissions.build(menu_id: role_perm['menu_id'], actions: actions)
              permission.save
            end
          end  
        end
        render json: RoleSerializer.new(role, meta: {message: "Role successfully Created."}).serializable_hash, status: :created
      else
        error = role.errors.messages
        if error.keys.include?(:name)
          render json: {name_error: error[:name][0]}, status: :unprocessable_entity
        else
          render json: {other_error: error[error.keys[0]][0]}, status: :unprocessable_entity
        end
      end
    end

    def bulk_update
      roles = Role.includes(:role_created_bie).where(id: params[:ids])
      if roles.any?
        begin
          roles.update_all(status: params[:status])
          render json: RoleSerializer.new(roles, meta: {message: "Roles successfully Updated."}).serializable_hash, status: :created
        rescue => e
          render json: { error: e }
        end
      else
        no_records_found
      end
    end

    def update
      return render json: {errors: [{message: "Please pass valid parameter"}]}, status: :unprocessable_entity unless params[:role].present?
      if @role.update(role_params)
        if params[:role][:role_permissions].present?
          params[:role][:role_permissions].each do |role_perm|
            permission = @role.role_permissions.find_or_initialize_by(menu_id: role_perm['menu_id'])
            if permission.present?
              actions = role_perm['actions'].map(&:camelize)
              actions.prepend('View') if %w[Create Edit Delete Approve].any? {|obj| actions.include?(obj) } && !actions.include?("View")
              permission.actions = actions if permission.actions != actions
              permission.save
            end
          end
          menu_ids = params[:role][:role_permissions].map{ |obj| obj[:menu_id] }
          permission = @role.role_permissions.where("menu_id NOT IN (?)", menu_ids)
          permission.destroy_all if permission.any?
        end
        render json: RoleSerializer.new(@role, meta: {message: "Role successfully Updated."}).serializable_hash, status: :created
      else
        error = @role.errors.messages
        if error.keys.include?(:name)
          render json: {name_error: error[:name][0]}, status: :unprocessable_entity
        else
          render json: {other_error: error[error.keys[0]][0]}, status: :unprocessable_entity
        end
      end 
    end

    def show
      render json: RoleSerializer.new(@role, meta: {message: "Role Details."}).serializable_hash, status: :ok
    end

    def destroy
      @role.destroy
      render json: {message:"Role was successfully destroyed."}, status: :ok
    end

    def bulk_destroy
      roles = Role.where(id: params[:ids].split(","))
      return no_records_found unless roles.any?
      if roles.destroy_all
        render json: { message: 'Roles was successfully destroyed.' }, status: :ok
      else
        render json: { errors: roles.errors }, status: :unprocessable_entity
      end
    end

    def destroy_permission
      @role =  Role.find_by(id: params[:role_id])
      return render json: {message:"Role not found"}, :status => :not_found unless @role.present?
      if @role.role_permissions.present?
        role_permission = @role.role_permissions.find_by(id: params[:role_premission_id])
        role_permission.destroy if role_permission.present?
      end
      render json: RoleSerializer.new(@role, meta: {message: "Permission successfully destroyed."}).serializable_hash, status: :ok
    end

    def module_menu_list
      permission_category = PermissionCategory.includes(:menus).order(:id)
      if permission_category.present?
        render json: PermissionCategorySerializer.new(permission_category), status: :ok
      else
        no_records_found
      end
    end

    def import
      if CSV.read(params[:file].path)[0].empty?
        return render json: { common_error: 'No records in CSV.' }, status: :not_found
      end
      unless (["role_name", "status"] - CSV.open(params[:file].path, &:readline)).empty?
        return render json: { common_error: 'Invalid headers' }, status: :not_found
      end
      begin
        invaild_data = Role.import(params[:file], current_user)
        if invaild_data.present?
          respond_to do |format|
            format.csv { send_data generate_csv(invaild_data), filename: "invaild_data_of_role.csv" }
            # format.json { "invaild_data_of_role csv" }
          end
        else
          render json: { message: 'All roles are imported successfully.' }, status: :ok
        end
      rescue => e
        e.to_s.slice!("Validation failed: Name") if e.to_s.include?("Validation failed: Name")
        render json: { error: e }
      end
    end

    def role_csv_sample_file
      csv_data = Role.includes(role_created_bie: :role_created_byable).order(:id).limit(3)
      respond_to do |format|
        format.csv { send_data csv_data.to_sample_csv, filename: "sample_file_for_role.csv" }
      end
    end

    def export
      csv_data = Role.includes(role_created_bie: :role_created_byable).order(:id)
      respond_to do |format|
        format.csv { send_data csv_data.to_csv, filename: "role-#{DateTime.now}.csv" }
      end
    end

    def search
      roles = Role.includes(role_created_bie: :role_created_byable).where('name ILIKE ?', "%#{params[:name]}%").order_by_created.paginate(page: params[:page], per_page: 20)
      if roles.present?
        render json: RoleSerializer.new(roles, meta: { total_pages: roles.total_pages, message: 'Role search list' }).serializable_hash,
               status: :ok
      else
        no_records_found
      end
    end

    private
    def no_records_found
      render json: { message: 'No records.' }, status: :not_found
    end
    def set_role
      @role =  Role.find_by(id: params[:id])
      render json: {message:"Role not found"}, :status => :not_found unless @role.present?
    end

    def role_params
      params.require(:role).permit(:name, :status, :created)
    end

    def generate_csv(data)
      attributes = %w[role_name status] + Menu.get_all + ["errors"]
      CSV.generate(headers: true) do |csv|
        csv << attributes
        data.each do |role|
          csv << role.to_h
        end
      end
    end
  end
end
