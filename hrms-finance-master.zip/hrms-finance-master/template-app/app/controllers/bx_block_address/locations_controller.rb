module BxBlockAddress
  class LocationsController < ApplicationController
    before_action :set_location, only: %i[update show destroy]

    def index
      locations = Location.paginate(page: params[:page], per_page: 20)
      if locations.present?
        render json: LocationSerializer.new(locations, meta: { total_pages: locations.total_pages, message: 'Locations list' }).serializable_hash,
               status: :ok
      else
        render json: { errors: format_activerecord_errors(locations.errors) }, status: :unprocessable_entity
      end
    end

    def create
      location = Location.new(location_params)
      if location.save
        render json: LocationSerializer.new(location, meta: {
                                          message: 'Location successfully Created.'
                                        }).serializable_hash, status: :created
      else
        render json: { errors: format_activerecord_errors(location.errors) }, status: :unprocessable_entity
      end
    end

    def update
      if @location.update(location_params)
        render json: LocationSerializer.new(@location, meta: { message: 'Location successfully Updated.' }).serializable_hash,
               status: :ok
      else
        render json: { errors: format_activerecord_errors(@location.errors) }, status: :unprocessable_entity
      end
    end

    def show
      render json: LocationSerializer.new(@location, meta: { message: 'Location Details.' }).serializable_hash, status: :ok
    end

    def destroy
      if @location.destroy
        render json: { message: 'Location was successfully destroyed.' }, status: :ok
      else
        render json: { errors: @location.errors }, status: :unprocessable_entity
      end
    end

    def import
      csv_data = Location.import(params[:file])
      render json: { message: 'Location data is successfully Imported' }, status: :created
    end

    def export
      csv_data = Location.all
      respond_to do |format|
        format.csv { send_data csv_data.to_csv, filename: "location-#{DateTime.now}.csv" }
      end
    end

    private

    def location_params
      params.permit(:branch_id, :branch_name, :country, :state, :time_zone, :address, :street, :phone_number, :zip_code, :url)
    end

    def set_location
      @location = Location.find(params[:id])
      render json: { message: 'Record not found' }, status: :not_found unless @location.present?
    end
  end
end
