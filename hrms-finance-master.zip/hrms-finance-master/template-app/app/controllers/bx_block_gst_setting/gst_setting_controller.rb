module BxBlockGstSetting
  class GstSettingController < ApplicationController
    before_action :current_user
    before_action :set_gst_setting, only: [:update]

    def index
      gst_setting = GstSetting.last
      if gst_setting.present?
        render json: GstSettingSerializer.new(gst_setting, meta: {message: "GST Details"}).serializable_hash, status: :ok
      else
        render json: {message:"No records."}, status: :ok
      end
    end

    def create
      if GstSetting.last.present?
        return render json: {message:"GST Already Created."}, status: :created
      else
        gst_setting = BxBlockGstSetting::GstSetting.new(gst_setting_params)
        if gst_setting.save
          render json: GstSettingSerializer.new(gst_setting, meta: {message: "Gst  successfully Created."}).serializable_hash, status: :created
        else
          render json: {errors: gst_setting.errors}, status: :unprocessable_entity
        end
      end
    end

    def update
      if @gst_setting.update(gst_setting_params)
        render json: GstSettingSerializer.new(@gst_setting, meta: {message: "Gst Details successfully Updated."}).serializable_hash, status: :created
      else
        render json: {errors: @gst_setting.errors}, status: :unprocessable_entity
      end 
    end

    def show
      render json: GstSettingSerializer.new(@gst_setting, meta: {message: "Gst Details."}).serializable_hash, status: :created
    end

    private

    def set_gst_setting
      @gst_setting =  GstSetting.find_by(id: params[:id])
      render json: {message:"Gst not found"}, :status => :not_found unless @gst_setting.present?
    end

    def gst_setting_params
      params.require(:gst_setting).permit(:gst_number, :legal_name, :trade_name, :regesterd_on)
    end
  end
end
