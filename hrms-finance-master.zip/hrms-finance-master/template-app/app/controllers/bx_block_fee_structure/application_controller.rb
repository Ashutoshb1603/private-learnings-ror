module BxBlockFeeStructure
  class ApplicationController < BuilderBase::ApplicationController
    include BuilderJsonWebToken::JsonWebTokenValidation

    # before_action :validate_json_web_token
    rescue_from ActiveRecord::RecordNotFound, :with => :not_found

    private

    def not_found
      render :json => {'errors' => ['Record not found']}, :status => :not_found
    end

    def current_user
      # begin
        # @current_user = AccountBlock::Account.find(token.id)
        # @current_user = AccountBlock::Account.find_by(lms_token: request.headers[:token])
      # rescue ActiveRecord::RecordNotFound => e
      #   return render json: {errors: [
      #        {message: 'Please login again.'},
      #       ]}, status: :unprocessable_entity
      # end
      if user = AccountBlock::Account.find_by(lms_token: request.headers[:token])
        return user
      else
        return render json: {errors: [{token: 'Token has Expired, Please login again.'},]}, status: :unprocessable_entity if @current_user.nil?
      end
    end
  end
end
