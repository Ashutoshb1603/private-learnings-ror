module BxBlockFeeStructure
  class FeeCollectionsController < ApplicationController
    def index
      students = LmsBlock::StudentBlock::StudentsService.new.students_list(current_user.school_id, params[:page],
                                                                           per_page: 20)
      return render json: students unless students['status'] == 200

      fee_collection = students['data'].map { |student| student_fee_collection(student) }
      if fee_collection.present?
        render json: { data: fee_collection }, status: :ok
      else
        render json: { message: 'No records.' }, status: :not_found
      end
    end

    def show
      student = LmsBlock::StudentBlock::StudentsService.new.student_details(params[:id])
      return render json: student unless student['status'] == 200

      render json: { data: student_fee_collection(student['data']) }, status: :ok
    end

    def update
      sfs = StudentBlock::StudentFeeStructure.find_by(student_id: params[:id])
      sfs.update(fee_structure_id: params[:data][:fee_structure_id]) if params[:data][:fee_structure_id].present?
      if sfs.fee_structure.update(fee_collection_params)
        render json: FeeCollectionSerializer.new(sfs.fee_structure, meta: { message: 'Fee Collection updated sussefully.' }).serializable_hash,
               status: :ok
      else
        render json: sfs.errors, status: :unprocessable_entity
      end
    end

    def bulk_update
      sfs = StudentBlock::StudentFeeStructure.where(student_id: params[:data][:student_ids])
      return render json: { message: 'No records.' }, status: :not_found if sfs.nil?

      if sfs.update_all(bulk_update_params.to_hash)
        if params[:data][:installment_type].present?
          sfs.each { |object| object.fee_structure.installments.update_all(name: params[:data][:installment_type]) }
        end
        render json: { message: 'Fee Collection updated sussefully.' }, status: :ok
      else
        render json: sfs.errors, status: :unprocessable_entity
      end
    end

    def destroy
      if @fee_collection.destroy
        render json: { message: 'Fee Collection destroy sussefully.' }, status: :ok
      else
        render json: @fee_collection.errors, status: :unprocessable_entity
      end
    end

    def search
      students = LmsBlock::StudentBlock::StudentsService.new.get_accounts_by_search(params[:account_name],
                                                                                    current_user.school_id, params[:page])
      return render json: students, status: students['status'] unless students['status'] == 200

      fee_collection = students['data'].map { |student| student_fee_collection(student) }
      if fee_collection.present?
        render json: { data: fee_collection }, status: :ok
      else
        render json: { message: 'No records.' }, status: :not_found
      end
    end

    def export
      students = LmsBlock::StudentBlock::StudentsService.new.students_list(current_user.school_id, params[:page],
                                                                           per_page: 20)
      return render json: students unless students['status'] == 200

      fee_collection = students['data'].map { |student| student_fee_collection(student) }
      respond_to do |format|
        format.csv { send_data BxBlockFeeStructure::FeeCollectionService.new.export_csv(fee_collection), filename: "fee_collection_#{DateTime.now}.csv" }
      end
    end

    def filter
      sfs = StudentBlock::StudentFeeStructure.joins(:fee_structure)
      sfs = if (params[:grade_id] && params[:division_id]).present?
              sfs.where('fee_structures.grade_id = ? AND fee_structures.division_id = ?', params[:grade_id],
                        params[:division_id])
            elsif params[:grade_id].present?
              sfs.where('fee_structures.grade_id = ?', params[:grade_id])
            end
      sfs = sfs.where('fee_structures.id = ?', params[:fee_structure_id]) if params[:fee_structure_id].present?

      student_ids = sfs.pluck(:student_id).uniq
      students = LmsBlock::StudentBlock::StudentsService.new.get_students_by_filter(student_ids, params[:page])
      return render json: students, status: students['status'] unless students['status'] == 200

      fee_collection = students['data'].map { |student| student_fee_collection(student) }
      if fee_collection.present?
        render json: { data: fee_collection }, status: :ok
      else
        render json: { message: 'No records.' }, status: :not_found
      end
    end

    private

    # Only allow a trusted parameter "white list" through.
    def fee_collection_params
      params.require(:data).permit(sub_fee_structures_attributes: %i[id fee_concession_id],
                                   installments_attributes: %i[id name])
    end

    def sub_fee_structure_params
      params.require(:data).permit(sub_fee_structures_attributes: %i[id fee_amount])
    end

    def bulk_update_params
      params.require(:data).permit(:id, :fee_structure_id, :description)
    end

    def student_fee_collection(student)
      fee_structures = FeeStructure.includes(:installments).joins(:student_fee_structures).find_by(
        'student_fee_structures.student_id = ?', student['id']
      )
      fee_structures = FeeCollectionSerializer.new(fee_structures).serializable_hash
      student.merge(fee_structures: fee_structures)
    end

  end
end
