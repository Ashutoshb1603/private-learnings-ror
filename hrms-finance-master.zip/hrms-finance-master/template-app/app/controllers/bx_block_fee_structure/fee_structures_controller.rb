module BxBlockFeeStructure
  class FeeStructuresController < ApplicationController
    before_action :current_user #, except: %i[create classes classes_and_divisions]
    before_action :set_fee_structure, only: [:update,:show, :destroy]
    # skip_before_action :validate_json_web_token, :only => [:create, :classes, :classes_and_divisions]

    def index
      fee_structures = FeeStructure.order("created_at DESC").paginate(page: params[:page], per_page: 20)
      if fee_structures.present?
        render json: FeeStructureSerializer.new(fee_structures, meta: {total_pages: fee_structures.total_pages, message: "Fee Structure List"}).serializable_hash, status: :ok
      else
        render json: {message:"No records."}, status: :ok
      end
    end

    def structure_list
      fee_structures = FeeStructure.order("created_at DESC").select(:id, :name)
      if fee_structures.present?
        render json: { data: fee_structures }, status: :ok
      else
        render json: { message:"No records" }, status: :ok
      end
    end

    def classes
      classes = LmsBlock::StudentBlock::StudentsService.new.classes_list(current_user.lms_token, current_user.school_id)
      render json: classes, status: :ok if classes.present?
    end

    def classes_and_divisions
      classes = LmsBlock::StudentBlock::StudentsService.new.classes_and_divisions_list(current_user.lms_token, current_user.school_id, params[:grade_id])
      render json: classes, status: :ok if classes.present?
    end

    def student_list
      students = if params[:student_name].present?
                    students = LmsBlock::StudentBlock::StudentsService.new.get_accounts_by_search(params[:student_name],current_user.school_id, params[:page])
                    return render json: students unless students['status'] == 200
                    students["data"]
                  elsif params[:grade_id].present? && params[:division_id].present?
                    students = LmsBlock::StudentBlock::StudentsService.new.get_students_by_division(current_user.lms_token, current_user.school_id, params[:grade_id], params[:division_id])
                    return render json: students unless students['status'] == 200
                    students["data"]
                  elsif params[:grade_id].present?
                    students = LmsBlock::StudentBlock::StudentsService.new.get_students_by_class(current_user.lms_token, current_user.school_id, params[:grade_id])
                    return render json: students unless students['status'] == 200
                    students["data"].map{ |k, v| v.map{ |data| data["account"]["data"]}}.flatten
                  end   
      data = []
      students.each do |student|
        id = student['id']
        email = student["attributes"]["email"]
        name = student["attributes"]["first_name"] + " " + student["attributes"]["last_name"]
        fee_structures = StudentBlock::StudentFeeStructure.joins(:fee_structure).where("student_id = #{id}").select('id',"fee_structures.name","status","fee_structure_id")
        data << {id: id, name: name, email: email, fee_structures: fee_structures}
      end
      data =  filter_data(data, params[:status], params[:fee_structure]) if params[:status].present? || params[:fee_structure].present?
      render json: { data: data}, status: :ok
    end
  
    def create
      return render json: {errors: {message: ["Please enter name"]}}, status: :unprocessable_entity if !params[:fee_structure].present? || !params[:fee_structure][:name].present?
      return render json: {errors: {message: ["Please select academic year"]}}, status: :unprocessable_entity if !params[:fee_structure].present? || !params[:fee_structure][:academic_year_id].present?
      if params[:fee_structure][:is_class]
        return render json: {errors: {message: ["Please select class"]}}, status: :unprocessable_entity if !params[:fee_structure].present? || !params[:fee_structure][:grade_id].present?
      elsif params[:fee_structure][:is_class_and_division]
        return render json: {errors: {message: ["Please select class"]}}, status: :unprocessable_entity if !params[:fee_structure].present? || !params[:fee_structure][:grade_id].present?
        return render json: {errors: {message: ["Please select division"]}}, status: :unprocessable_entity if !params[:fee_structure].present? || !params[:fee_structure][:division_id].present?
      end
      fee_structure = BxBlockFeeStructure::FeeStructure.new(fee_structure_params)
      if fee_structure.save
        student_ids = if params[:fee_structure][:is_class]
                        students = LmsBlock::StudentBlock::StudentsService.new.get_students_by_class(current_user.lms_token, current_user.school_id, params[:fee_structure][:grade_id])
                        return render json: students unless students['status'] == 200
                        students["data"].map{ |k, v| v.pluck('account_id')}.flatten
                      elsif params[:fee_structure][:is_class_and_division]
                        students = LmsBlock::StudentBlock::StudentsService.new.get_students_by_division(current_user.lms_token, current_user.school_id, params[:fee_structure][:grade_id], params[:fee_structure][:division_id])
                        return render json: students unless students['status'] == 200
                        students["data"].pluck("id")
                      elsif params[:fee_structure][:is_group]
                        params[:fee_structure][:group_attributes][:student_ids]
                      end

        group_id = fee_structure.group.blank? ? nil : fee_structure.group.id

        student_ids.each{ |student_id| fee_structure.student_fee_structures.create(student_id: student_id, group_id: group_id)}
        render json: FeeStructureSerializer.new(fee_structure, meta: {message: "Fee Structure successfully Created."}).serializable_hash, status: :created
      else
        render json: {errors: fee_structure.errors}, status: :unprocessable_entity
      end
    end

    def update
      if @fee_structure.update(fee_structure_params)
        render json: FeeStructureSerializer.new(@fee_structure, meta: {message: "Fee Structure successfully Updated."}).serializable_hash, status: :created
      else
        render json: {errors: @fee_structure.errors}, status: :unprocessable_entity
      end 
    end

    def show
      render json: SubFeeStructureSerializer.new(@fee_structure, meta: {message: "Fee Structure Details."}).serializable_hash, status: :ok
    end

    def import
      csv_data = BxBlockFeeStructure::FeeStructure.import(params[:file])
      render json: {message: "Fee Structure data is successfully Imported"}, status: :created
    end

    def export
      csv_data = BxBlockFeeStructure::FeeStructure.all
      respond_to do |format|
        format.csv { send_data csv_data.to_csv, filename: "FeeStructure-#{DateTime.now}.csv" }
      end
    end

    def destroy
      @fee_structure.destroy
      render json: {message:"Fee Structure was successfully destroyed."}, status: :ok
    end

    def bulk_destroy
      fee_structures = FeeStructure.where(id: params[:ids].split(","))
      return render json: {message:"No records."}, status: :not_found unless fee_structures.any?
      if fee_structures.destroy_all
        render json: { message: 'Fee structures was successfully destroyed.' }, status: :ok
      else
        render json: { errors: fee_structuresusers.errors }, status: :unprocessable_entity
      end
    end

    def assign_sub_fee_structures
      @fee_structure =  FeeStructure.find_by(id: params[:fee_structure_id])
      return render json: {message:"Fee Structure not found"}, :status => :not_found unless @fee_structure.present?
      return render json: {errors: [{message: "Please pass valid parameter"}]}, status: :unprocessable_entity unless params[:sub_fee_structure].present?
      @fee_structure.update(fee_type: params[:fee_type])
      params[:sub_fee_structure].each do |sub_fee|
        if sub_fee["sub_fee_structure_id"].present?
          get_fee_struc = BxBlockFeeStructure::SubFeeStructure.find_by(id: sub_fee["sub_fee_structure_id"], fee_structure_id: @fee_structure.id)
          get_fee_struc.update(fee_id: sub_fee["fee_id"], fee_amount: sub_fee['fee_amount'], tax_ids: sub_fee["tax_ids"])
        else
          sub_fee_struc = @fee_structure.sub_fee_structures.build(fee_id: sub_fee["fee_id"], fee_amount: sub_fee['fee_amount'], tax_ids: sub_fee["tax_ids"])
          sub_fee_struc.save
        end
      end
      render json: SubFeeStructureSerializer.new(@fee_structure, meta: {message: "Fee Structure Details."}).serializable_hash, status: :ok
    end

    def create_installments
      @fee_structure =  FeeStructure.find_by(id: params[:fee_structure_id])
      return render json: {message:"Fee Structure not found"}, :status => :not_found unless @fee_structure.present?
      return render json: {errors: [{message: "Please pass valid parameter"}]}, status: :unprocessable_entity unless params[:installment_details].present?
      if params[:installments].present?
        @installment = @fee_structure.installments.create(installment_params)
      end
      if @installment.present?
        if params[:installment_details].present?
          if params[:installment_details][:attributes].present?
            params[:installment_details][:attributes].each do |install_detail|
              installment_detail = @installment.installment_details.build(name: install_detail['name'], due_date: install_detail['due_date'], fine_id: install_detail['fine_id'])
                installment_detail.save
            end
          end
        end
      end
      render json: InstallmentsSerializer.new(@fee_structure.installments, meta: {message: "Installment successfully added."}).serializable_hash, status: :created
    end

    def installment_lists
      @fee_structure =  FeeStructure.find_by(id: params[:fee_structure_id])
      return render json: {message:"Fee Structure not found"}, :status => :not_found unless @fee_structure.present?
      render json: InstallmentDetailsSerializer.new(@fee_structure.installments, meta: {message: "List of installment with fee structure"}).serializable_hash, status: :ok
    end

    def delete_installment
      fee_structure =  FeeStructure.find_by(id: params[:fee_structure_id])
      return render json: {message:"Fee Structure not found"}, :status => :not_found unless fee_structure.present?
      if fee_structure.installments.present?
        installment = fee_structure.installments.find_by(id: params[:installment_id])
        installment.destroy if installment.present?
      end
      installments = BxBlockInstallment::Installment.where(fee_structure_id: fee_structure.id)
      render json: InstallmentDetailsSerializer.new(installments, meta: {message: "Installment successfully destroyed."}).serializable_hash, status: :ok
    end

    def get_installment_record
      fee_structure =  FeeStructure.find_by(id: params[:fee_structure_id])
      return render json: {message:"Fee Structure not found"}, :status => :not_found unless fee_structure.present?
      installment = fee_structure.installments.find_by(id: params[:installment_id])
      render json: InstallmentDetailsSerializer.new(installment, meta: {}).serializable_hash, status: :ok
    end

    def update_installments
      fee_structure =  FeeStructure.find_by(id: params[:fee_structure_id])
      return render json: {message:"Fee Structure not found"}, :status => :not_found unless fee_structure.present?
      if params[:installments].present?
        @installment = fee_structure.installments.find_by(id: params[:id])
        if @installment.present?
          @installment.update(installment_params)
        end
      end
      if @installment.present?
        if params[:installment_details].present?
          if params[:installment_details][:attributes].present?
            params[:installment_details][:attributes].each do |install_detail|
              if install_detail[:installment_detail_id].present?
                installment_detail = @installment.installment_details.find_by(id: install_detail[:installment_detail_id])
                installment_detail.update(name: install_detail['name'], due_date: install_detail['due_date'], fine_id: install_detail['fine_id']) if installment_detail.present?
              else
                installment_detail = @installment.installment_details.build(name: install_detail['name'], due_date: install_detail['due_date'], fine_id: install_detail['fine_id'])
                installment_detail.save
              end
            end
          end
        end
      end
      render json: InstallmentDetailsSerializer.new(@installment, meta: {message: "Installment successfully updated."}).serializable_hash, status: :created
    end

    def destroy_sub_fee_structure
      @fee_structure =  FeeStructure.find_by(id: params[:fee_structure_id])
      return render json: {message:"Fee Structure not found"}, :status => :not_found unless @fee_structure.present?
      if @fee_structure.sub_fee_structures.present?
        sub_fee_structure = @fee_structure.sub_fee_structures.find_by(id: params[:sub_fee_structure_id])
        sub_fee_structure.destroy if sub_fee_structure.present?
      end
      render json: SubFeeStructureSerializer.new(@fee_structure, meta: {message: "Sub Fee Structure successfully destroyed."}).serializable_hash, status: :ok
    end

    def filter
      fee_structures = FeeStructure.all
      if params[:id].present?
        fee_structures  = fee_structures.where(id: params[:id])
      end
      if params[:academic_year_id].present?
        fee_structures  = fee_structures.where(academic_year_id: params[:academic_year_id])
      end
      if params[:grade_id].present?
        fee_structures  = fee_structures.where(grade_id: params[:grade_id])
      end
      if params[:division_id].present?
        fee_structures  = fee_structures.where(division_id: params[:division_id])
      end
      fee_structures = fee_structures.order("created_at DESC").paginate(page: params[:page], per_page: 20)
      render json: FeeStructureSerializer.new(fee_structures, meta: {total_pages: fee_structures.total_pages}).serializable_hash, status: :ok
    end

    def search
      fee_structures = FeeStructure.where('name ILIKE ?', "%#{params[:name]}%").order("created_at DESC").paginate(page: params[:page], per_page: 20)
      if fee_structures.present?
        render json: FeeStructureSerializer.new(fee_structures, meta: { total_pages: fee_structures.total_pages, message: 'Fee structures search list' }).serializable_hash,
               status: :ok
      else
        render json: { message: 'No records.' }, status: :not_found
      end
    end

    def invoice_template_lists
      @invoice_templates = BxBlockInvoiceTemplate::InvoiceTemplate.order("created_at DESC")
      render json: InvoiceTemplateSerializer.new(@invoice_templates, meta: {message: "Invoice templates list"}).serializable_hash, status: :ok
    end

    def email_template_lists
      @email_templates = BxBlockEmailTemplate::EmailTemplate.order("created_at DESC")
      render json: EmailTemplateSerializer.new(@email_templates, meta: {message: "Email templates list"}).serializable_hash, status: :ok
    end

    private

    def filter_data(data, status, fee_structure_id)
      if status.present? && fee_structure_id.present?
        data.select { |student| student[:fee_structures].any? { |obj| obj[:status] == status && obj[:fee_structure_id] == fee_structure_id.to_i}}
      elsif status.present?
        data.select { |student| student[:fee_structures].any? { |obj| obj[:status] == status}}
      elsif fee_structure_id.present?
        data.select { |student| student[:fee_structures].any? { |obj| obj[:fee_structure_id] == fee_structure_id.to_i}}
      end
    end

    def set_fee_structure
      @fee_structure =  FeeStructure.find_by(id: params[:id])
      render json: {message:"Fee Structure not found"}, :status => :not_found unless @fee_structure.present?
    end

    def installment_params
      params.require(:installments).permit(:name, :installment_code, :total_amount, :concession, :concession_type, :discounted_amount, :bill_duration_no, :bill_duration, :billing_cycle, :payment_collection, :invoice_template_id, :email_template_id, :payment_option)
    end

    def fee_structure_params
      params.require(:fee_structure).permit(:academic_year_id, :due_date, :fine_id, :name, :division, :division_id, :grade, :grade_id, :is_class, :is_class_and_division, :is_group, :fee_type, sub_fee_structures_attributes: [:id, :_destroy, :fee_id, fee_attributes: [:id, :amount, tax_ids: []]], installments_attributes: [:id, :name, :installment_code, :total_amount, :concession, :concession_type, :discounted_amount, :bill_duration_no, :bill_duration, :billing_cycle, :payment_collection, :invoice_template_id, :email_template_id, :payment_option, installment_details_attributes: [:id, :name, :due_date, :fine_id, :_destroy]], group_attributes: [:id, :_destroy, student_ids: []])
    end
  end 
end
