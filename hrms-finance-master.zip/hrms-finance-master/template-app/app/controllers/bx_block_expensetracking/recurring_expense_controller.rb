module BxBlockExpensetracking
  class RecurringExpenseController < ApplicationController
    before_action :current_user
    before_action :find_expense,only: [:show,:update,:destroy,:stop_recurring_expense, :recurring_expense_history, :expense_history] 

    def index
      @recurring_expenses = BxBlockExpensetracking::RecurringExpense.all.order(id: :desc).paginate(page: params[:page], per_page: 20)
      render json: {data: BxBlockExpensetracking::RecurringExpenseSerializer.new(@recurring_expenses),meta: @recurring_expenses.total_pages}
    end

    def recurring_expenses_list
      @recurring_expenses = RecurringExpense.all.order(id: :desc)
      return not_found if @recurring_expenses.empty?
      render json: {data: RecurringExpenseSerializer.new(@recurring_expenses)}
    end

    def show
      render json: {data: RecurringExpenseSerializer.new(@recurring_expense),status: 200}  
    end 

    def create
      if params[:data][:customer_type] == "business"
        @customer = BxBlockProfile::BusinessCustomer.find_by(id: params[:data][:customer_id])
      elsif params[:data][:customer_type] == "individual"
        @customer = BxBlockProfile::IndividualCustomer.find_by(id: params[:data][:customer_id])
      else
        return render json: { errors: "Please confirm customer type" }
      end
      @recurring_expense = @customer.recurring_expenses.new(permit_params)
      @recurring_expense.set_last_expense_date
      @recurring_expense.expense_recipt.attach(params[:expense_recipt]) if params[:expense_recipt].present?
      if @recurring_expense.save
        message = "Recurring Expense created for #{@recurring_expense.ammount} by #{current_user.first_name.to_s + current_user.last_name.to_s}"
        @recurring_expense.store_history(message)
        render json: {data: BxBlockExpensetracking::RecurringExpenseSerializer.new(@recurring_expense),status:200,message:'created sussefully'}
      else
        render json: {errors: @recurring_expense.errors.full_messages}
      end
    end

    def update
      message = "Tax details have been updated by #{current_user.first_name.to_s + current_user.last_name.to_s}"
      @recurring_expense.store_history(message) if permit_params[:tax].present? && @recurring_expense.tax != permit_params[:tax]
      @recurring_expense.expense_recipt.attach(params[:expense_recipt]) if params[:expense_recipt].present?
      if @recurring_expense.update(permit_params)
        render json: {data: BxBlockExpensetracking::RecurringExpenseSerializer.new(@recurring_expense),status:200,message:'created sussefully'}
      else
        render json: {errors: @recurring_expense.errors.full_messages}
      end 
    end

    def destroy
      if @recurring_expense.delete
        render json: {message: "expense deleted sucessfully",status: 200}  
      else 
        render json: {error: @recurring_expense.errors.full_messages}          
      end 	 
    end

    def bulk_destroy
      expense = BxBlockExpensetracking::RecurringExpense.where(id:(params[:ids]))
      return render json: {message:"No records."}, status: :not_found unless expense.any?
      if expense.destroy_all
        render json: { message: 'expense was successfully destroyed.' }, status: :ok
      else
        render json: { errors: expense.errors }, status: :unprocessable_entity
      end 
    end

    def import 
      csv_data = BxBlockExpensetracking::RecurringExpense.import(params[:file])
      render json: {message: "User data is successfully imported"}, status: :ok
    end 

    def export
      csv_data = BxBlockExpensetracking::RecurringExpense.order(:id)
      respond_to do |format|
        format.csv { send_data csv_data.to_csv, filename: "Vendor-#{DateTime.now}.csv" }
      end 
    end

    def bulk_update
      expenses = BxBlockExpensetracking::RecurringExpense.where(id: params[:ids])
      if expenses.any?
        expenses.each do |expense|
          expense.update(permit_params)
        end
        render json: BxBlockExpensetracking::RecurringExpenseSerializer.new(expenses, meta: {message: "expenses successfully Updated."}).serializable_hash, status: :created
      else
        render json: {message:"No records."}, status: :not_found
      end
    end

    def get_currency_list
      currencies = []
      Money::Currency.table.values.each do |currency|
        currencies = currencies + [[currency[:name] + ' (' + currency[:iso_code] + ')', currency[:iso_code]]]
      end
      render json: {data: currencies}
    end 

    def get_indian_states
      return render json: {data: BxBlockExpensetracking::StateList.states}
    end 
    
    def get_expense_account
      @account = AccountBlock::Account.joins(:role).where("roles.name ILIKE ?", '%Expenses%')
      return not_found if @account.empty?
      render json: {data: @account}
    end


    def get_all_accounts
      @account = BxBlockAcademicAccount::AcademicAccount.where(account_type_id: 3).select(:id,:name)
      return render json: {data: @account}
      # @account = BxBlockAcademicAccount::AccountType.where(id: 3).select(:id,:name)
      # return render json: {data: @account}
    end

    def stop_recurring_expense
      if @recurring_expense.update!(stop: true)
        message = "Recurring Expense stoped by #{current_user.first_name.to_s + current_user.last_name.to_s}"
        @recurring_expense.store_history(message)
        return render json: {message: "recurring expenses stoped sucessfully"}
      else
        return render json: {message: @recurring_expense.errors.full_messages}
      end 
    end

    def filter
      recurring_expense = BxBlockExpensetracking::RecurringExpense.all
      if params[:expense_id].present?
        recurring_expense = recurring_expense.where(expense_id: params[:expense_id])
      end
      if params[:vendor_name].present?
        recurring_expense = recurring_expense.includes(:vendor).where('vendors.first_name ILIKE ?', params[:vendor_name]).references(:vendors)
      end
      if params[:status].present?
        recurring_expense = recurring_expense.where(stop: params[:status])
      end
      return not_found if recurring_expense.empty?
      recurring_expense = recurring_expense.order(created_at: :desc).paginate(page: params[:page], per_page: 20)
      render json: BxBlockExpensetracking::RecurringExpenseSerializer.new(recurring_expense, meta: {total_pages: recurring_expense.total_pages}).serializable_hash, status: :ok
    end

    def search
      if params[:search_keyword].present?
        recurring_expense = BxBlockExpensetracking::RecurringExpense.where("expense_name ILIKE", 
                                                "%#{params[:search_keyword]}%").paginate(page: params[:page], per_page: 20)
      else
        recurring_expense = BxBlockExpensetracking::RecurringExpense.order("created_at DESC").paginate(page: params[:page], per_page: 20)
      end
     if recurring_expense.present?
        render json: BxBlockExpensetracking::RecurringExpenseSerializer.new(recurring_expense, meta: {total_pages: recurring_expense.total_pages, message: "User search list"}).serializable_hash, status: :ok
      else
        render json: { message: 'No records.' }, status: :not_found
      end
    end

    def recurring_expense_history
      history = @recurring_expense.recurring_expense_histories
      if history.present?
        render json: RecurringExpenseHistorySerializer.new(history, meta: { message: 'Recurring expenses history'} ).serializable_hash, status: :ok
      else
        not_found
      end
    end
    
    def expense_history
      expense_history = @recurring_expense.expense_histories
      if expense_history.present?
        render json: ExpenseHistorySerializer.new(expense_history, meta: { message: 'Expenses history'} ).serializable_hash, status: :ok
      else
        not_found
      end
    end

    private
      def find_expense
        @recurring_expense = BxBlockExpensetracking::RecurringExpense.find(params[:id])
        unless @recurring_expense.present?
          render json: {error: "recurring expense not found"}  
        end 
      end 

      def permit_params
      	params.require(:data).permit( :reason_for_exemption,:expense_type, :sac, :hsn, :expense_name, :paid_through, :currency, :exchange_rate, :exchange_amount, :ammount , :repeat_every, :repeat_count, :start_date , :end_date , :expense_id, :vendor_id, :tax_id, :source_of_supply, :destination_of_supply, :gst_treatment_id, :reverse_charge_account_id, :reverse_charge, :comment, :ammount_is,:gst_in,:bill_every_count,:bill_every_option, :is_reverse_charge, :reverse_charge_mode)
      end
  end
end