
module BxBlockExpensetracking
  class ExpenseController < ApplicationController
    
    before_action :find_expense,only: [:show,:update,:destroy] 

    def index
      @expenses = BxBlockExpensetracking::Expense.order(created_at: :desc).paginate(page: params[:page], per_page: 20)
      render json: {data: BxBlockExpensetracking::ExpenseSerializer.new(@expenses),meta: @expenses.total_pages}
    end

    # def index
    #   @expenses = BxBlockExpensetracking::Expense.order(created_at: :desc)
    #   render json: {data: BxBlockExpensetracking::ExpenseSerializer.new(@expenses),meta: @expenses.total_pages}
    # end

    def show
      render json: {data: BxBlockExpensetracking::ExpenseSerializer.new(@expense),status: 200}  
    end 

    def create 
      @expense = BxBlockExpensetracking::Expense.new(permit_params)
      @expense.expense_recipt.attach(params[:expense_recipt]) if params[:expense_recipt].present?
      if @expense.save
        render json: {data: BxBlockExpensetracking::ExpenseSerializer.new(@expense),status:200,message:'created sussefully'}
      else
        render json: {errors: @expense.errors.full_messages}
      end 
    end

    def update
      @expense.expense_recipt.attach(params[:expense_recipt]) if params[:expense_recipt].present?
      if @expense.update(permit_params)
        render json: {data: BxBlockExpensetracking::ExpenseSerializer.new(@expense),status:200,message:'created sussefully'}
      else
        render json: {errors: @expense.errors.full_messages}
      end 
    end

    def destroy
      if @expense.delete
        render json: {message: "expense deleted sucessfully",status: 200}  
      else 
        render json: {error: @expense.errors.full_messages}          
      end 	 
    end

    def bulk_destroy
      expense = BxBlockExpensetracking::Expense.where(id:(params[:ids]))
      return render json: {message:"No records."}, status: :not_found unless expense.any?
      if expense.destroy_all
        render json: { message: 'expense was successfully destroyed.' }, status: :ok
      else
        render json: { errors: expense.errors }, status: :unprocessable_entity
      end
    end

    def bulk_update
      expenses = BxBlockExpensetracking::Expense.where(id: params[:ids])
      if expenses.any?
        expenses.each do |expense|
          expense.update(permit_params)
        end
        render json: BxBlockExpensetracking::ExpenseSerializer.new(expenses, meta: {message: "expenses successfully Updated."}).serializable_hash, status: :created
      else
        render json: {message:"No records."}, status: :not_found
      end
    end


    def gst_treatment_list
      @gst_treatment = BxBlockProfile::GstTreatment.select(:id,:name)
      return render json: {data: @gst_treatment} 
    end

    private
      def find_expense
        @expense = BxBlockExpensetracking::Expense.find(params[:id])
        unless @expense.present?
          render json: {error: "expense not found"}  
        end 
      end 

      def permit_params
      	params.require(:data).permit(:hns_code, :date, :currency, :expence_account, :ammount, :tax, :vendor_id, :invoice, :paid_trough, :source_of_supply, :destination_of_supply, :gst_treatment, :reverse_charge, :reverse_charge_account, :reverse_charge_ammount, :comment,:expense_recipt,:expense_type,:account_is,:exchange_rate,:exchange_amount,:is_tax_inclusive)
      end 
  end 
end

