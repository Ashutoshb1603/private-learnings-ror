module BxBlockForgotPassword
  class OtpConfirmationsController < ApplicationController
    require "faraday"
    def create
      if create_params[:token].present? && create_params[:otp_code].present?
        # Try to decode token with OTP information
        begin
          token = BuilderJsonWebToken.decode(create_params[:token])
        rescue JWT::ExpiredSignature
          return render json: {
            errors: [{
              pin: 'OTP has expired, please request a new one.',
            }],
          }, status: :unauthorized
        rescue JWT::DecodeError => e
          return render json: {
            errors: [{
              token: 'Invalid token',
            }],
          }, status: :bad_request
        end

        # Try to get OTP object from token
        begin
          otp = token.type.constantize.find(token.id)
        rescue ActiveRecord::RecordNotFound => e
          return render json: {
            errors: [{
              otp: 'Token invalid',
            }],
          }, status: :unprocessable_entity
        end

        # Check OTP code
        if otp.pin == create_params[:otp_code].to_i
          if otp.created_at + 60.seconds < Time.now
            otp.destroy
            return render json: {errors: [{pin: 'OTP has expired, please request a new one or Resend OTP.'}]}, status: :unauthorized
          else
            otp.activated = true
            otp.save
            if params[:data][:type] == "login_with_otp"
              if otp.class.name == "AccountBlock::SmsOtp"
                account = AccountBlock::Account.find_by(full_phone_number: otp.full_phone_number)
              else
                account = AccountBlock::Account.find_by(email: otp.email)
              end
              token = BuilderJsonWebToken.encode(account.id)
              # Delete OTP object as it's not needed anymore
              otp.destroy
              role = account&.role&.name
              return render json: {meta: {role: role, account: account, token: token, profile_id: account&.profile&.id}}
            else
              render json: {
                messages: [{
                  otp: 'OTP validation success',
                }],
              }, status: :created
            end
          end
        else
          return render json: {
            errors: [{
              otp: 'Invalid OTP provided',
            }],
          }, status: :unprocessable_entity
        end
      else
        return render json: {
          errors: [{
            otp: 'Token and OTP code are required',
          }],
        }, status: :unprocessable_entity
      end
    end

    def otp_confirmation_with_lms
      if create_params[:token].present? && create_params[:otp_code].present?
        token = create_params[:token]
        otp = create_params[:otp_code]
        type = create_params[:type]
        if ActiveModel::Type::Boolean.new.cast(create_params[:is_otp_from_lms])
          user_data = LmsBlock::AccountBlock::LoginService.new().login_otp_confirmation(token, otp, type)
          if user_data["status"] == 201
            user = AccountBlock::Account.find_by(lms_account_id: user_data["data"]["id"])
            params = {"data":{"attributes": {"first_name": user_data["data"]["attributes"]["first_name"], "email": user_data["data"]["attributes"]["email"], "full_phone_number": user_data["data"]["attributes"]["full_phone_number"], "activated": user_data["data"]["attributes"]["activated"], "lms_account_id": user_data["data"]["id"], "lms_token": user_data["meta"]["token"], "is_lms_user": true, "lms_role": "admin", "school_id": user_data["data"]["attributes"]["school_id"]}}}
            if user.present?
              user.update(jsonapi_deserialize(params))
            else
              AccountBlock::Account.create(jsonapi_deserialize(params))
            end
            render json: user_data
          elsif user_data["status"] == 404
            render :json => {'errors' => ['Record not found']}, :status => :not_found 
          else
            # render json: {
            #   errors: [{
            #     pin: user_data["errors"][0]['pin'],
            #   }],
            # }, status: :unprocessable_entity
            render json: user_data, status: :unprocessable_entity
          end
        else
          # begin
          #   hrms_token = BuilderJsonWebToken.decode(create_params[:token])
          # rescue JWT::ExpiredSignature
          #   return render json: {
          #     errors: [{
          #       pin: 'OTP has been expired/invalid. Please request a new one and try again.',
          #     }],
          #   }, status: :unauthorized
          # rescue JWT::DecodeError => e
          #   return render json: {
          #     errors: [{
          #       token: 'Invalid token',
          #     }],
          #   }, status: :bad_request
          # end
          # begin
          #   otp = hrms_token.type.constantize.find(hrms_token.id)
          # rescue ActiveRecord::RecordNotFound => e
          #   return render json: {
          #     errors: [{
          #       otp: 'Token invalid',
          #     }],
          #   }, status: :unprocessable_entity

          # end
          # if create_params[:type] == "email_otp"
          #   otp_account = AccountBlock::EmailOtp.find(hrms_token.id)
          #   account = AccountBlock::Account.find_by(email: otp_account.email)
          # else
          #   otp_account = AccountBlock::SmsOtp.find(hrms_token.id)
          #   account = AccountBlock::Account.find_by(full_phone_number: otp_account.full_phone_number)
          # end
          user_data = HrmsBlock::AccountBlock::LoginService.new().login_otp_confirmation(create_params[:token], create_params[:otp_code], create_params[:type])
          render json: user_data
        end
      else
        return render json: {
          errors: [{
            otp: 'Token and OTP code are required',
          }],
        }, status: :unprocessable_entity
      end
    end

    def otp_confirm_forgot_pass_lms
      if ActiveModel::Type::Boolean.new.cast(create_params[:is_otp_from_lms])
        data = LmsBlock::AccountBlock::ForgotPasswordService.new().otp_confirmation(create_params[:token], create_params[:otp_code])
        render json: data, status: :ok if data.present?
      else
        data = HrmsBlock::AccountBlock::ForgotPasswordService.new().otp_confirmation(create_params[:token], create_params[:otp_code])
        render json: data, status: :ok if data.present?
      end
    end

    private

    def create_params
      params.require(:data)
        .permit(*[
          :email,
          :full_phone_number,
          :token,
          :otp_code,
          :new_password,
          :type,
          :is_otp_from_lms,
        ])
    end
  end
end
