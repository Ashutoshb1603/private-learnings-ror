module AccountBlock
  class AccountsController < ApplicationController
    before_action :current_user
    before_action :set_user, only: [:update, :show, :destroy]

    def index
      accounts = Account.where(is_lms_user: false).newest_first.paginate(page: params[:page], per_page: 20)
      if accounts.present?
        render json: AccountSerializer.new(accounts, meta: {total_pages: accounts.total_pages, message: "Account lists"}).serializable_hash, status: :ok
      else
        render json: {message:"No records."}, status: :ok
      end  
    end

    def create
      account_params = jsonapi_deserialize(params)

      return required_parameter(account_params) unless (account_params['role_id'].present? && account_params['email'].present? && account_params['full_phone_number'].present?)

      if account_params['email'].present?
        validator = EmailValidation.new(account_params['email'])
        return check_email if !validator.valid?
      end
      if account_params['full_phone_number'].present?
        phone = Phonelib.parse(account_params['full_phone_number']).sanitized
        unless Phonelib.valid?(phone)
          return check_mobile_number
        end
      end
      @account = Account.new(jsonapi_deserialize(params))
      @account.activated = true
      @account.referenceable_id = current_user.id
      @account.referenceable_type = "AccountBlock::Account"
      if @account.save
        @relative_account = AccountBlock::RelativeAccount.create(relative_accountable_id:current_user.id, relative_accountable_type: "AccountBlock::Account", account_id:@account.id )
        render json: AccountSerializer.new(@account, meta: {}).serializable_hash, status: :created
      else
        render json: {errors: @account.errors}, status: :unprocessable_entity
      end
    end

    def update
      account_params = jsonapi_deserialize(params)
      if account_params['password'].present?
        return render json: {errors: {current_password: ['Incorrect current password']}}, status: :unprocessable_entity unless @user.authenticate(account_params['current_password'])
      end

      return required_parameter(account_params) unless (account_params['role_id'].present? && account_params['email'].present? && account_params['full_phone_number'].present?)

      if account_params['email'].present?
        validator = EmailValidation.new(account_params['email'])
        return check_email if !validator.valid?
      end
      
      if account_params['full_phone_number'].present?
        phone = Phonelib.parse(account_params['full_phone_number']).sanitized
        unless Phonelib.valid?(phone)
          return check_mobile_number
        end 
      end
      if @user.update(jsonapi_deserialize(params))
        if account_params['password'].present?
          account_password = @user.account_passwords.new(password: account_params['password'])
          account_password.save
        end
        render json: AccountSerializer.new(@user, meta: {message: "User successfully Updated"}).serializable_hash, status: :created
      else
        render json: {errors: @user.errors}, status: :unprocessable_entity
      end
    end

    def show
      render json: AccountSerializer.new(@user, meta: {message: "User details"}).serializable_hash, status: :ok
    end

    def destroy
      @user.destroy
      render json: {message:"User successfully destroyed."}, status: :ok
    end

    def bulk_destroy
      users = Account.where(id: params[:ids].split(","))
      return no_records_found unless users.any?
      if users.destroy_all
        render json: { message: 'Users was successfully destroyed.' }, status: :ok
      else
        render json: { errors: users.errors }, status: :unprocessable_entity
      end
    end

    def filter
      accounts = Account.all
      if params[:role_id].present?
        @role =  BxBlockRolesPermissions::Role.find_by(id: params[:role_id])
        accounts = @role.accounts
      end
      if params[:status].present?
        accounts  = accounts.where(activated: params[:status])
      end
      accounts = accounts.newest_first.paginate(page: params[:page], per_page: 20)
      render json: AccountSerializer.new(accounts, meta: {total_pages: accounts.total_pages}).serializable_hash, status: :ok
    end

    def role
      accounts = Account.by_role(params[:role]).paginate(page: params[:page], per_page: 20)
      if accounts.present?
        render json: AccountSerializer.new(accounts, meta: {total_pages: accounts.total_pages, message: "Accounts lists by there role"}).serializable_hash, status: :ok
      else
        no_records_found
      end
    end

    def bulk_update
      users = Account.where(id: params[:ids])
      if users.any?
        users.each do |user|
          user.update(account_params)
        end
        render json: AccountSerializer.new(users, meta: {message: "Users successfully Updated."}).serializable_hash, status: :created
      else
        no_records_found
      end
    end

    def import
      if CSV.read(params[:file].path).empty? || CSV.read(params[:file].path)[0].empty?
        return render json: { common_error: 'No records in CSV.' }, status: :not_found
      end
      unless CSV.foreach(params[:file], headers: true).count >= 1
        return render json: { common_error: 'No records in CSV.' }, status: :not_found
      end
      unless (["Name", "Role", "Email", "Phone"] - CSV.open(params[:file].path, &:readline)).empty?
        return render json: { common_error: 'Invalid headers' }, status: :not_found
      end
      begin
        invaild_data = Account.import(params[:file], current_user)
        if invaild_data.present?
          respond_to do |format|
            format.csv { send_data generate_csv(invaild_data), filename: "invaild_data_of_users.csv" }
          end
        else
          render json: { message: 'All Users are imported successfully.' }, status: :ok
        end
      rescue => e
        e.to_s.slice!("Validation failed: Name") if e.to_s.include?("Validation failed: Name")
        render json: { error: e }
      end
    end

    def account_csv_sample_file
      csv_data = Account.order(:id).limit(3)
      respond_to do |format|
        format.csv { send_data csv_data.to_sample_csv, filename: "sample_file_for_account.csv" }
      end
    end

    def export
      csv_data = Account.order(:id)
      respond_to do |format|
        format.csv { send_data csv_data.to_csv, filename: "User-#{DateTime.now}.csv" }
      end
    end

    def search
      if BxBlockRolesPermissions::Role.where("name ILIKE ?", "#{params[:name].strip}%").present?
        accounts = Account.joins('INNER JOIN roles r on r.id = accounts.role_id').where('r.name ILIKE ?', "#{params[:name].strip}%").newest_first.paginate(page: params[:page], per_page: 20)
      else
        accounts = Account.where('first_name ILIKE ? OR email ILIKE ? OR full_phone_number ILIKE ?', "%#{params[:name]}%", "%#{params[:name]}%", "#{params[:name]}%").newest_first.paginate(page: params[:page], per_page: 20)
      end
      if accounts.present?
        render json: AccountSerializer.new(accounts, meta: {total_pages: accounts.total_pages, message: "User search list"}).serializable_hash, status: :ok
      else
        no_records_found
      end
    end

    def all_country_codes
      arr=[]
      c= ISO3166::Country.all
      c.map {|t| arr<<t.country_code } 
      render json: {country_codes: arr.uniq}
    end

    def get_roles
      roles = BxBlockRolesPermissions::Role.order_by_created
      render json: RolesSerializer.new(roles, meta: {message: "Roles List"}).serializable_hash, status: :ok
    end

    private
    def no_records_found
      render json: { message: 'No records.' }, status: :not_found
    end

    def set_user
      @user = Account.find_by(id: params[:id])
      return render json: {message: "User not found"}, :status => :not_found unless @user.present?
    end

    def required_parameter(account_params)
      return render json: {errors: {role_id: ["Please select Role"]}}, status: :unprocessable_entity if !account_params['role_id'].present?

      return render json: {errors: {email: ['Please enter email']}}, status: :unprocessable_entity unless account_params['email'].present?

      return render json: {errors: {full_phone_number: ['Please enter phone number']}}, status: :unprocessable_entity unless account_params['full_phone_number'].present?
    end

    def check_email
      render json: {errors: {email: ['Invalid email.']}}, status: :unprocessable_entity
    end

    def check_mobile_number
      render json: {errors: {full_phone_number: ["Invalid or Unrecognized Phone Number"]}}, status: :unprocessable_entity
    end

    def account_params
      params.permit(:role_id, :activated)
    end

    def encode(id)
      BuilderJsonWebToken.encode id
    end

    def generate_csv(data)
      attributes = %w[Name Role Email Phone Status Error]
      CSV.generate(headers: true) do |csv|
        csv << attributes
        data.each do |role|
          csv << role.to_h
        end
      end
    end
  end
end
