module AccountBlock
  class EmployeesController < ApplicationController

    def index
      accounts = Account.employees.paginate(page: params[:page], per_page: 20)
      if accounts.present?
        render json: EmployeeSerializer.new(accounts, meta: {total_pages: accounts.total_pages, message: "Employee lists"}).serializable_hash, status: :ok
      else
        render json: {message:"No records."}, status: :not_found
      end
    end

    def update
      account = Account.find_by(id: params[:id])
      if account.update(employee_params)
        render json: EmployeeSerializer.new(account, meta: { message: "Employee updated" }).serializable_hash, status: :ok
      else
        render json: { message: "No records" }, status: :not_found
      end
    end

    private

    def employee_params
      params.permit(:department_id, :designation_id)
    end
  end
end
