module AccountBlock
  class VendorsController < ApplicationController
    # include BuilderJsonWebToken::JsonWebTokenValidation
    before_action :current_user
    # before_action :set_account
    before_action :find_vendor,only: [:show,:update,:destroy]

    def index 
      @vendors = AccountBlock::Vendor.order_by_created.paginate(page: params[:page], per_page: 20)
      if @vendors.present?
        render json: AccountBlock::VendorSerializer.new(@vendors, meta: {total_pages: @vendors.total_pages, message: "Vendor lists"}).serializable_hash, status: :ok
      else
        no_records_found
      end
    end

    def show 
      return render :json => (AccountBlock::VendorSerializer.new(@vendor))
    end 

    def create
      if ActiveModel::Type::Boolean.new.cast(params[:data][:is_same_billing_address])
        @vendor = AccountBlock::Vendor.new(same_billing_addre_vendor_params)
      else
        @vendor = AccountBlock::Vendor.new(vendor_params)
      end
      @vendor.account_id = current_user.id
      if @vendor.save
        return render json: AccountBlock::VendorSerializer.new(@vendor, meta: {message: "vendor created sussefully"}).serializable_hash, status: :created
      else 
        return render json: {error: @vendor.errors}, status: :unprocessable_entity
      end 
    end

    def update
      if ActiveModel::Type::Boolean.new.cast(params[:data][:is_same_billing_address])
        if @vendor.update(same_billing_addre_vendor_params)
          return render json: AccountBlock::VendorSerializer.new(@vendor, meta: {message: "vendor updated sussefully."}).serializable_hash, status: :created
        else
          return render json: {error: @vendor.errors}, status: :unprocessable_entity
        end
      else
        if @vendor.update(vendor_params)
          return render json: AccountBlock::VendorSerializer.new(@vendor, meta: {message: "vendor updated sussefully"}).serializable_hash, status: :created
        else
          return render json: {error: @vendor.errors}, status: :unprocessable_entity
        end
      end
    end 

    def destroy
      if @vendor.destroy
        return render json: {message: "vendor destroy sussefully",status: 200}
      else 
        return render json: {error: @vendor.errors}, status: :unprocessable_entity
      end 
    end 

    def filter
      vendors = AccountBlock::Vendor.all
      if params[:first_name].present?
        vendors = vendors.where("first_name ILIKE ?", "%#{params[:first_name].strip}%")
      end
      if params[:last_name].present?
        vendors  = vendors.where("last_name ILIKE ?", "%#{params[:last_name].strip}%")
      end
      if params[:vendor_email].present?
        vendors  = vendors.where("vendor_email ILIKE ?", "%#{params[:vendor_email].strip}%")
      end

      if params[:phone_no_mob].present?
        vendors  = vendors.where("phone_no_mob ILIKE ?", "%#{params[:phone_no_mob].strip}%")
      end
      if params[:gst_treatment_id].present?
        vendors  = vendors.where(gst_treatment_id: params[:gst_treatment_id])
      end
      vendors = vendors.order_by_created.paginate(page: params[:page], per_page: 20)
      if vendors.present?
        render json: AccountBlock::VendorSerializer.new(vendors, meta: {total_pages: vendors.total_pages}).serializable_hash, status: :ok
      else
        no_records_found
      end
    end

    def search  
      if params[:name].present?
        vendors = AccountBlock::Vendor.where("first_name ILIKE ? OR last_name ILIKE ? OR company_name ILIKE ? OR vendor_email ILIKE ? OR phone_no_mob ILIKE ?", "%#{params[:name]}%", "%#{params[:name]}%", "%#{params[:name]}%", "#{params[:name]}%", "#{params[:name]}%").order_by_created.paginate(page: params[:page], per_page: 20)
      else
        vendors = AccountBlock::Vendor.all.paginate(page: params[:page], per_page: 20)
      end
     if vendors.present?
        render json: AccountBlock::VendorSerializer.new(vendors.order_by_created, meta: {total_pages: vendors.total_pages, message: "Vendor search list"}).serializable_hash, status: :ok
      else
        no_records_found
      end
    end

    def import
      if (CSV.read(params[:file].path).empty? || CSV.read(params[:file].path)[0].empty?) || (CSV.foreach(params[:file], headers: true).count == 0) || (!(["Salutation", "First name", "Last name", "Company", "Email", "Contact no mob", "Phone no work", "Website url", "GST treatment", "GSTIN/UIN", "PAN Number", "Source of Supply", "Currency", "Payment Tearms", "TDS", "Billing Street", "Billing Address", "Same as Billing Address", "Shipping Street", "Shipping Address"] - CSV.open(params[:file].path, &:readline)).empty?)
        return render json: { common_error: 'No records in CSV.' }, status: :not_found
      end
      # unless CSV.foreach(params[:file], headers: true).count >= 1
      #   return render json: { common_error: 'No records in CSV.' }, status: :not_found
      # end
      # unless (["Salutation", "First name", "Last name", "Company", "Email", "Contact no mob", "Phone no work", "Website url", "Website url", "GSTIN/UIN", "PAN Number", "Source of Supply", "Currency", "Payment Tearms", "TDS", "Billing Street", "Billing Address", "Same as Billing Address", "Shipping Street", "Shipping Address"] - CSV.open(params[:file].path, &:readline)).empty?
      #   return render json: { common_error: 'Invalid headers' }, status: :not_found
      # end
      begin
        invaild_data = AccountBlock::Vendor.import(params[:file], current_user)
        if invaild_data.present?
          send_data generate_csv(invaild_data), filename: "invaild_data_of_vendors.csv"
        else
          render json: {message: "Vendor data is successfully Imported"}, status: :ok
        end
      rescue => e
        e.to_s.slice!("Validation failed: Name") if e.to_s.include?("Validation failed: Name")
        render json: { error: e }
      end
    end

    def csv_sample_file
       csv_data = AccountBlock::Vendor.order(id: :DESC).limit(3)
       send_data csv_data.to_sample_csv, filename: "sample_file_for_vendor.csv"
     end 

    def export
      csv_data = AccountBlock::Vendor.order(:id)
      send_data csv_data.to_csv, filename: "Vendor-#{DateTime.now}.csv"
    end

    def bulk_destroy
      vendor = AccountBlock::Vendor.where(id:(params[:ids]))
      return no_records_found unless vendor.any?
      if vendor.destroy_all
        render json: { message: 'vendor was successfully destroyed.' }, status: :ok
      else
        render json: { errors: vendor.errors }, status: :unprocessable_entity
      end
    end

    # def bulk_update
    #   vendors = AccountBlock::Vendor.where(id: params[:ids])
    #   if vendors.any?
    #     vendors.each do |vendor|
    #       vendor.update(vendor_params)
    #     end
    #     render json: AccountBlock::VendorSerializer.new(vendors, meta: {message: "expenses successfully Updated."}).serializable_hash, status: :created
    #   else
    #     no_records_found
    #   end
    # end

    def vendor_name_list
      vendors =  AccountBlock::Vendor.select(:first_name,:last_name,:id,:company_name,:phone_no_mob)
      vendors = vendors.where('phone_no_mob ILIKE ?', "%#{params[:phone].gsub(/[^0-9A-Za-z]/, '')}%") if params[:phone].present?
      vendors = vendors.where("first_name ILIKE :q OR last_name ILIKE :q", q:"%#{params[:vendor_name]}%") if params[:vendor_name].present?
      vendors = vendors.where('company_name ILIKE ?', "%#{params[:company_name]}%") if params[:company_name].present?
      vendors = vendors.where('vendor_email ILIKE ?', "%#{params[:vendor_email]}%") if params[:vendor_email].present?
      vendors = vendors.where(id: params[:id]) if params[:id].present?
      return render json: {data: vendors} 
    end

    def payment_term_list
      payment_term =  BxBlockProfile::PaymentTerm.all
      return render json: BxBlockProfile::PaymentTermSerializer.new(payment_term)
    end

    def create_payment_term
      if params[:data].present?
        success_data = []
        error_data = []
        params[:data].each do |payment_term|
          pay_term = BxBlockProfile::PaymentTerm.new(account_id:current_user.id, term_name:payment_term[:term_name], no_of_days: payment_term[:no_of_days])
          if pay_term.save
            success_data << pay_term
          else
            error_data << pay_term.errors
          end
        end
        success_ids = success_data.map(&:id)
        @payment_term = BxBlockProfile::PaymentTerm.where(id: success_ids)
        # return render json: BxBlockProfile::PaymentTermSerializer.new(@payment_term)
        return render json: BxBlockProfile::PaymentTermSerializer.new(@payment_term, meta: {message: "Payment Terms created sussefully", failed_data: error_data}).serializable_hash, status: :created
      end
      # @payment_term =  BxBlockProfile::PaymentTerm.create!(account_id:@account.id,term_name:params[:term_name],no_of_days:params[:no_of_days])
    end 

    def tds_list
      tds =  AccountBlock::AccountTd.all
      return render json: AccountBlock::AccountTdSerializer.new(tds).serializable_hash, status: :ok
    end

    def create_tds
      tds = AccountBlock::AccountTd.new(tds_params)
      if tds.save
        return render json:AccountBlock::AccountTdSerializer.new(tds, meta: {message: "TDS created sussefully"}).serializable_hash, status: :ok
      else 
        return render json: {error: tds.errors}, status: :unprocessable_entity
      end 
    end

    def section_creation
      section = AccountBlock::Section.new(name: params[:name])
      if section.save
        return render json: AccountBlock::SectionSerializer.new(section)
      else
        return render json: {error: section.errors}, status: :unprocessable_entity
      end
    end 

    def get_all_section
      @sections = AccountBlock::Section.all
      return render json: AccountBlock::SectionSerializer.new(@sections)
    end  

    private
      def vendor_params
        params.require(:data).permit(:salutation,:first_name,:last_name,:company_name,:vendor_email,:phone_no_mob, :phone_no_mob_code,:phone_no_work, :phone_no_work_code, :website_url,:currency,:pan_number,:state_source_of_supply,:gst_treatment_id, :payment_term_id, :account_td_id, :gstin_uin,:billing_address, :billing_address2, :is_same_billing_address, :shipping_address, :shipping_address2, :remarks)
      end

      def same_billing_addre_vendor_params
        params.require(:data).permit(:salutation,:first_name,:last_name,:company_name,:vendor_email,:phone_no_mob, :phone_no_mob_code,:phone_no_work, :phone_no_work_code, :website_url,:currency,:pan_number,:state_source_of_supply,:gst_treatment_id, :payment_term_id, :account_td_id, :gstin_uin,:billing_address, :billing_address2, :is_same_billing_address, :remarks)
      end

      def no_records_found
        render json: { message: 'No records.' }, status: :not_found
      end

      def tds_params
        params.require(:data).permit(:section_id, :tax_rate, :tax_name, :status )
      end

      def find_vendor
        @vendor = AccountBlock::Vendor.find_by(id: params[:id]) 
        if @vendor.nil?
          return render json: {error: "vendor not found"}, status: :not_found
        end 
      end

      def generate_csv(data)
        attributes = ['Salutation', 'First name', 'Last name', 'Company', 'Email', 'Contact No code', 'Contact No mob', 'Phone no work code', 'Phone no work', 'Website url', 'GST treatment', 'GSTIN/UIN', 'PAN Number', 'Source of Supply', 'Currency', 'Payment Tearms', 'TDS', 'Billing Street', 'Billing Address', 'Same as Billing Address', 'Shipping Street', 'Shipping Address', 'Remarks', "Error"]
        CSV.generate(headers: true) do |csv|
          csv << attributes
          data.each do |vendor|
            csv << vendor.to_h
          end
        end
      end

      # def set_account #only untill the token issue solves
      #   @account = AccountBlock::Account.first 
      # end
  end
end
