module BxBlockAcademicClass
  class AcademicClassesController < ApplicationController
    before_action :current_user
    before_action :set_academic_class, only: [:update,:show, :destroy]

    def index
      academic_classes = AcademicClass.order("created_at DESC").paginate(page: params[:page], per_page: 20)
      if academic_classes.present?
        render json: AcademicClassSerializer.new(academic_classes, meta: {total_pages: academic_classes.total_pages, message: "Academic class lists"}).serializable_hash, status: :ok
      else
        render json: {message:"No records."}, status: :ok
      end
    end

    def class_lists
      academic_classes = AcademicClass.order("created_at DESC")
      if academic_classes.present?
        render json: AcademicClassSerializer.new(academic_classes, meta: {message: "Academic class lists"}).serializable_hash, status: :ok
      else
        render json: {message:"No records."}, status: :ok
      end
    end
    
    def create
      return render json: {errors: [{message: "Please select academic year"}]}, status: :unprocessable_entity if !params[:academic_class].present? || !params[:academic_class][:academic_year_id].present?
      academic_class = BxBlockAcademicClass::AcademicClass.new(academic_class_params)
      if academic_class.save
        render json: AcademicClassSerializer.new(academic_class, meta: {message: "Academic Class successfully Created."}).serializable_hash, status: :created
      else
        render json: {errors: format_activerecord_errors(academic_class.errors)}, status: :unprocessable_entity
      end
    end

    def update
      if @academic_class.update(academic_class_params)
        render json: AcademicClassSerializer.new(@academic_class, meta: {message: "Academic Class successfully Updated."}).serializable_hash, status: :created
      else
        render json: {errors: format_activerecord_errors(@academic_class.errors)}, status: :unprocessable_entity
      end 
    end

    def show
      render json: AcademicClassSerializer.new(@academic_class, meta: {message: "AcademicClass Details."}).serializable_hash, status: :created
    end

    def destroy
      @academic_class.destroy
      render json: {message:"Academic Class was successfully destroyed."}, status: :ok
    end

    def yearly_classes
      @academic_year =  BxBlockAcademicYear::AcademicYear.find_by(id: params[:academic_year_id])
      return render json: {message:"Academic year not found"}, :status => :not_found unless @academic_year.present?
      academic_classes = @academic_year.academic_classes.order("created_at DESC")
      return render json: {message:"No classes for this year"}, :status => :not_found unless academic_classes.present?
      render json: AcademicClassSerializer.new(academic_classes, meta: {message: "Academic class lists"}).serializable_hash, status: :ok
    end

    private

    def set_academic_class
      @academic_class =  AcademicClass.find_by(id: params[:id])
      render json: {message:"Academic Class not found"}, :status => :not_found unless @academic_class.present?
    end

    def academic_class_params
      params.require(:academic_class).permit(:name, :academic_year_id)
    end
  end
end
