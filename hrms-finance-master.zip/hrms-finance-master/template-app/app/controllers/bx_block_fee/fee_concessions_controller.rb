module BxBlockFee
  class FeeConcessionsController < ApplicationController
    before_action :set_fee_concession, only: %i[update show destroy]

    def index
      fee_concessions = FeeConcession.order("created_at DESC").paginate(page: params[:page], per_page: 20)
      if fee_concessions.present?
        render json: FeeConcessionSerializer.new(fee_concessions, meta: { total_pages: fee_concessions.total_pages, message: 'Fee Concession list' }).serializable_hash,
               status: :ok
      else
        render json: { message: 'No records.' }, status: :not_found
      end
    end

    def create
      if params[:data][:amount].to_i <= 0
        return render json: { message: "#{params[:data][:amount]} not a valid amount. Amount should be more than 0." },
                      status: :unprocessable_entity
      else
        fee_concession = FeeConcession.new(fee_concession_params)
        if fee_concession.save
          render json: FeeConcessionSerializer.new(fee_concession, meta: { message: 'Fee Concession successfully Created.' }).serializable_hash,
                 status: :created
        else
          render json: { errors: fee_concession.errors }, status: :unprocessable_entity
        end
      end
    end

    def update
      if @fee_concession.update(fee_concession_params)
        render json: FeeConcessionSerializer.new(@fee_concession, meta: { message: 'Fee Concession successfully Updated.' }).serializable_hash,
               status: :ok
      else
        render json: { errors: @fee_concession.errors }, status: :unprocessable_entity
      end
    end

    def bulk_update
      concessions = FeeConcession.where(id: params[:data][:ids])
      if concessions.any?
        begin
          concessions.update_all(bulk_update_params.as_json)
          render json: FeeConcessionSerializer.new(concessions, meta: {message: "Concessions successfully Updated."}).serializable_hash, status: :created
        rescue => e
          render json: { error: e }
        end
      else
        render json: {message:"No records."}, status: :not_found
      end
    end

    def show
      render json: FeeConcessionSerializer.new(@fee_concession, meta: { message: 'Fee concession Details.' }).serializable_hash,
             status: :ok
    end

    def destroy
      if @fee_concession.destroy
        render json: { message: 'Fee concession was successfully destroyed.' }, status: :ok
      else
        render json: { errors: @fee_concession.errors }, status: :unprocessable_entity
      end
    end

    def bulk_destroy
      concessions = FeeConcession.where(id: params[:ids].split(","))
      return render json: {message:"No records."}, status: :not_found unless concessions.any?
      if concessions.destroy_all
        render json: { message: 'Fee concessions was successfully destroyed.' }, status: :ok
      else
        render json: { errors: concessions.errors }, status: :unprocessable_entity
      end
    end

    def filter
      fee_concessions = fee_concession_data
      if params[:fee_concession_type_id].present?
        fee_concessions = fee_concessions.where(fee_concession_type_id: params[:fee_concession_type_id])
      end
      fee_concessions = fee_concessions.where(valid_until: params[:valid_until]) if params[:valid_until].present?
      unless params[:mode] == 'all'
      fee_concessions = fee_concessions.where(mode: params[:mode]) if  params[:mode].present?
      end
      if params[:amount_start].present? && params[:amount_end].present?
        fee_concessions = fee_concessions.where(amount: params[:amount_start].to_i..params[:amount_end].to_i)
      end
      fee_concessions = fee_concessions.order("created_at DESC").paginate(page: params[:page], per_page: 20)
      if fee_concessions.present?
        render json: FeeConcessionSerializer.new(fee_concessions, meta: { total_pages: fee_concessions.total_pages, message: ' Fee Concessions filtered list' }).serializable_hash,
               status: :ok
      else
        render json: { message: 'No records.' }, status: :not_found
      end
    end

    def search
      fee_concessions = FeeConcession.where('name ILIKE ?', "%#{params[:name]}%").order("created_at DESC").paginate(page: params[:page], per_page: 20)
      if fee_concessions.present?
        render json: FeeConcessionSerializer.new(fee_concessions, meta: { total_pages: fee_concessions.total_pages, message: 'Fee Concessions search list' }).serializable_hash,
               status: :ok
      else
        render json: { message: 'No records.' }, status: :not_found
      end
    end

    def import
      if CSV.read(params[:file].path)[0].empty?
        return render json: { common_error: 'File is empty.' }, status: :not_found
      end
      unless (CSV.open(params[:file].path, &:readline) - ["fee_concession_type", "name", "valid_until", "mode", "amount"]).empty?
        return render json: { common_error: 'Invalid headers' }, status: :not_found
      end
      if CSV.read(params[:file].path)[1].empty?
        return render json: { common_error: 'No records in CSV.' }, status: :not_found
      end
      invaild_data = FeeConcession.import(params[:file])
      if invaild_data.present?
        respond_to do |format|
            format.csv { send_data generate_csv(invaild_data), filename: "invaild_data_of_concession.csv" }
        end
      else
        render json: { message: 'All concession are imported successfully.' }, status: :created
      end
    end

    def export
      respond_to do |format|
        format.csv { send_data fee_concession_data.order(:id).to_csv, filename: "fee_concessions_#{DateTime.now}.csv" }
      end
    end

    def csv_sample_file
      send_file(
        "#{Rails.root}/app/assets/csv_files/sample_file_for_concession.csv",
        filename: "sample_file_for_concessions.csv"
      )
    end

    private

    def set_fee_concession
      @fee_concession = FeeConcession.find_by(id: params[:id])
      render json: { message: 'Record not found' }, status: :not_found unless @fee_concession.present?
    end

    def fee_concession_params
      params.require(:data).permit(:name, :valid_until, :mode, :fee_concession_type_id, :amount)
    end

    def bulk_update_params
      params.require(:data).permit(:mode, :fee_concession_type_id, :valid_until)
    end

    def fee_concession_data
      FeeConcession.all
    end

    def generate_csv(data)
      attributes = %w[fee_concession_type name valid_until mode amount errors]
      CSV.generate(headers: true) do |csv|
        csv << attributes
        data.each do |role|
          csv << role.to_h
        end
      end
    end
  end
end
