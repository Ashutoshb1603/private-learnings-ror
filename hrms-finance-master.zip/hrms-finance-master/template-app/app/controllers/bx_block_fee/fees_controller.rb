module BxBlockFee
  class FeesController < ApplicationController
    before_action :current_user
    before_action :set_fee, only: [:update,:show, :destroy]

    def index
      fees = Fee.order_by_created.paginate(page: params[:page], per_page: 20)
      if fees.present?
        render json: FeeSerializer.new(fees, meta: {total_pages: fees.total_pages, message: "Fee lists"}).serializable_hash, status: :ok
      else
        render json: {message:"No records."}, status: :not_found
      end
    end
    
    def create
      return render json: {message:"Please select unti date"}, status: :unprocessable_entity unless params[:fee][:valid_until].present?
      return render json: {message:"Amount should be more than 0."}, status: :unprocessable_entity unless params[:fee][:amount].present? && params[:fee][:amount].to_i > 0
      fee = BxBlockFee::Fee.new(fee_params)
      if fee.save
        render json: FeeSerializer.new(fee, meta: {message: "Fee successfully Created."}).serializable_hash, status: :created
      else
        render json: {errors: fee.errors}, status: :unprocessable_entity
      end
    end

    def import
      if CSV.read(params[:file].path).empty? || CSV.read(params[:file].path)[0].empty?
        return render json: { common_error: 'File is empty.' }, status: :not_found
      end
      unless CSV.foreach(params[:file], headers: true).count >= 1
        return render json: { common_error: 'No records in CSV.' }, status: :not_found
      end
      unless (["Fee Name", "Valid Until", "Amount"] - CSV.open(params[:file].path, &:readline)).empty?
        return render json: { common_error: 'Invalid headers' }, status: :not_found
      end

      begin
        invaild_data = BxBlockFee::Fee.import(params[:file])
        if invaild_data.present?
          send_data generate_csv(invaild_data), filename: "invaild_data_of_fees.csv"
        else
          render json: {message: "Fee data is successfully Imported"}, status: :ok
        end
      rescue => e
        e.to_s.slice!("Validation failed: Name") if e.to_s.include?("Validation failed: Name")
        render json: { error: e }
      end
    end

    def export
      csv_data = BxBlockFee::Fee.all.order(:id)
      send_data csv_data.to_csv, filename: "Fee-#{DateTime.now}.csv"
    end

    def fee_csv_sample_file
      csv_data = Fee.order(:id).limit(3)
      send_data csv_data.to_sample_csv, filename: "sample_file_for_account.csv"
    end

    def search_fee
      fees = BxBlockFee::Fee.where('name ILIKE ?', "%#{params[:name]}%").paginate(page: params[:page], per_page: 20)
      if fees.present?
        render json: FeeSerializer.new(fees, meta: { total_pages: fees.total_pages, message: 'Fee search list' }).serializable_hash,
               status: :ok
      else
        render json: { message: 'No records.' }, status: :not_found
      end
    end

    def filter
      @fees = BxBlockFee::Fee.all
      if params[:name].present?
        @fees = @fees.where('name ILIKE ?', "%#{params[:name].strip}%")
      end
      if params[:valid_until].present?
        @fees = @fees.where(valid_until: params[:valid_until])
      end
      if params[:start_range].present? && params[:end_range].present?
        @fees = @fees.where(amount: params[:start_range]..params[:end_range])
      end
      @fees = @fees.order_by_created.paginate(page: params[:page], per_page: 20)
      if @fees.present?
        render json: FeeSerializer.new(@fees, meta: { total_pages: @fees.total_pages, message: 'Fee filter list' }).serializable_hash,
               status: :ok
      else
        render json: { message: 'No records.' }, status: :not_found
      end
    end

    def update
      return render json: {message:"Amount should be more than 0."}, status: :unprocessable_entity unless params[:fee][:amount].present? && params[:fee][:amount].to_i > 0
      if @fee.update(fee_params)
        render json: FeeSerializer.new(@fee, meta: {message: "Fee successfully Updated."}).serializable_hash, status: :created
      else
        render json: {errors: @fee.errors}, status: :unprocessable_entity
      end 
    end

    def bulk_update
      fees = Fee.where(id: params[:fee][:ids])
      if fees.any?
        begin
          fees.update_all(fee_bulk_update_params.to_h)
          render json: FeeSerializer.new(fees, meta: {message: "fees successfully Updated."}).serializable_hash, status: :created
        rescue => e
          render json: { error: e }
        end
      else
        render json: {message:"No records."}, status: :not_found
      end
    end

    def show
      render json: FeeSerializer.new(@fee, meta: {message: "Fee Details."}).serializable_hash, status: :created
    end

    def destroy
      @fee.destroy
      render json: {message:"Fee was successfully destroyed."}, status: :ok
    end

    def bulk_destroy
      fees = Fee.where(id: params[:ids].split(","))
      return render json: {message:"No records."}, status: :not_found unless fees.any?
      if fees.destroy_all
        render json: { message: 'Fees was successfully destroyed.' }, status: :ok
      else
        render json: { errors: fees.errors }, status: :unprocessable_entity
      end
    end

    def search
      if BxBlockAcademicAccount::AcademicAccount.where("name ILIKE ?", "#{params[:name].strip}%").present?
        fees = Fee.joins('INNER JOIN academic_accounts a on a.id = fees.academic_account_id').where('a.name ILIKE ?', "#{params[:name].strip}%").order_by_created.paginate(page: params[:page], per_page: 20)
      else
        fees = Fee.where('name ILIKE ?', "%#{params[:name].strip}%").or(Fee.where(amount: params[:name].strip)).order_by_created.paginate(page: params[:page], per_page: 20)
      end
      if fees.present?
        render json: FeeSerializer.new(fees, meta: { total_pages: fees.total_pages, message: 'fee search list' }).serializable_hash,
               status: :ok
      else
        render json: { message: 'No records.' }, status: :not_found
      end
    end

    def fee_lists
      render json: FeeListsSerializer.new(Fee.order_by_created, meta: {}).serializable_hash,status: :ok
    end

    private

    def set_fee
      @fee =  Fee.find_by(id: params[:id])
      render json: {message:"Fee not found"}, :status => :not_found unless @fee.present?
    end

    def fee_params
      params.require(:fee).permit(:name, :valid_until, :academic_account_id, :amount, tax_ids: [])
    end

    def fee_bulk_update_params
      params.require(:fee).permit(:valid_until, :academic_account_id, tax_ids: [])
    end

    def generate_csv(data)
      attributes = ["Fee Name", "Valid Until", "Tax%", "Amount", "Account", "Error"]
      CSV.generate(headers: true) do |csv|
        csv << attributes
        data.each do |fee|
          csv << fee.to_h
        end
      end
    end
  end
end
