module BxBlockFee
  class FeeConcessionTypesController < ApplicationController
    before_action :set_fee_concession_type, only: %i[update destroy]

    def index
      fee_concession_types = FeeConcessionType.all
      if fee_concession_types.present?
        render json: FeeConcessionTypeSerializer.new(fee_concession_types).serializable_hash, status: :ok
      else
        render json: { message: 'No records.' }, status: :ok
      end
    end

    def create
      fee_concession_type = FeeConcessionType.new(fee_concession_type_params)
      if fee_concession_type.save
        render json: FeeConcessionTypeSerializer.new(fee_concession_type, meta: { message: 'Fee concession type successfully Created.' }).serializable_hash,
               status: :created
      else
        render json: { errors: fee_concession_type.errors }, status: :unprocessable_entity
      end
    end

    def update
      if @fee_concession_type.update(fee_concession_type_params)
        render json: FeeConcessionTypeSerializer.new(@fee_concession_type, meta: { message: 'Fee Concession type successfully Updated.' }).serializable_hash,
               status: :ok
      else
        render json: { errors: @fee_concession_type.errors }, status: :unprocessable_entity
      end
    end

    def destroy
      if @fee_concession_type.destroy
        render json: { message: 'Fee concession type was successfully destroyed.' }, status: :ok
      else
        render json: { errors: @fee_concession_type.errors }, status: :unprocessable_entity
      end
    end

    private

    def set_fee_concession_type
      @fee_concession_type = FeeConcessionType.find_by(id: params[:id])
      render json: { message: 'Record not found' }, status: :not_found unless @fee_concession_type.present?
    end


    def fee_concession_type_params
      params.permit(:name, :description)
    end
  end
end
