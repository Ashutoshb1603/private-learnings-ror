module BxBlockDivision
  class DivisionsController < ApplicationController
    before_action :current_user
    before_action :set_division, only: [:update,:show, :destroy]

    def index
      divisions = Division.order("created_at DESC").paginate(page: params[:page], per_page: 20)
      if divisions.present?
        render json: DivisionSerializer.new(divisions, meta: {total_pages: divisions.total_pages, message: "Division lists"}).serializable_hash, status: :ok
      else
        render json: {message:"No records."}, status: :ok
      end
    end

    def division_lists
      divisions = Division.order("created_at DESC")
      if divisions.present?
        render json: DivisionListsSerializer.new(divisions, meta: {message: "Division lists"}).serializable_hash, status: :ok
      else
        render json: {message:"No records."}, status: :ok
      end
    end
    
    def create
      return render json: {errors: [{message: "Please select academic class"}]}, status: :unprocessable_entity if !params[:division].present? || !params[:division][:academic_class_id].present?
      division = BxBlockDivision::Division.new(division_params)
      if division.save
        render json: DivisionSerializer.new(division, meta: {message: "Division successfully Created."}).serializable_hash, status: :created
      else
        render json: {errors: format_activerecord_errors(division.errors)}, status: :unprocessable_entity
      end
    end

    def update
      if @division.update(division_params)
        render json: DivisionSerializer.new(@division, meta: {message: "Division successfully Updated."}).serializable_hash, status: :created
      else
        render json: {errors: format_activerecord_errors(@division.errors)}, status: :unprocessable_entity
      end 
    end

    def show
      render json: DivisionSerializer.new(@division, meta: {message: "Division Details."}).serializable_hash, status: :created
    end

    def destroy
      @division.destroy
      render json: {message:"Division was successfully destroyed."}, status: :ok
    end

    def get_class_divisions
      @academic_class =  BxBlockAcademicClass::AcademicClass.find_by(id: params[:academic_class_id])
      return render json: {message:"Academic class not found"}, :status => :not_found unless @academic_class.present?
      divisions = @academic_class.divisions.order("created_at DESC")
      return render json: {message:"No divisions for this class please select another class."}, :status => :not_found unless divisions.present?
      render json: DivisionSerializer.new(divisions, meta: {message: "Division lists"}).serializable_hash, status: :ok
    end

    private

    def set_division
      @division =  Division.find_by(id: params[:id])
      render json: {message:"Division not found"}, :status => :not_found unless @division.present?
    end

    def division_params
      params.require(:division).permit(:title, :academic_class_id)
    end
  end
end
