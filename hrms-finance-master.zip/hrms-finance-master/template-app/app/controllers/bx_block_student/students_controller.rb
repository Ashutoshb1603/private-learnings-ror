module BxBlockStudent
  class StudentsController < ApplicationController
    before_action :current_user
    before_action :set_student, only: [:update,:show, :destroy]

    def index
     students = Student.order("created_at DESC").paginate(page: params[:page], per_page: 20)
      if students.present?
        render json: StudentSerializer.new(students, meta: {total_pages: students.total_pages, message: "Student lists"}).serializable_hash, status: :ok
      else
        render json: {message:"No records."}, status: :ok
      end
    end
    
    def create
      student = BxBlockStudent::Student.new(student_params)
      if student.save
        render json: StudentSerializer.new(student, meta: {message: "Student successfully Created."}).serializable_hash, status: :created
      else
        render json: {errors: student.errors}, status: :unprocessable_entity
      end
    end


    def update
      if @student.update(student_params)
        render json: StudentSerializer.new(@student, meta: {message: "Student successfully Updated."}).serializable_hash, status: :created
      else
        render json: {errors: format_activerecord_errors(@student.errors)}, status: :unprocessable_entity
      end 
    end

    def show
      render json: StudentSerializer.new(@student, meta: {message: "Student Details."}).serializable_hash, status: :created
    end

    def destroy
      @student.destroy
      render json: {message:"Student was successfully destroyed."}, status: :ok
    end

    def get_division_students
      division =  BxBlockDivision::Division.find_by(id: params[:id])
      return render json: {message:"Division not found"}, :status => :not_found unless division.present?
      @students =  division.students
      render json: BxBlockStudent::StudentsDivisionSerializer.new(@students), status: :ok
    end

    def fee_receivables
      student_list = BxBlockStudent::Student.all.paginate(page: params[:page], per_page: 20)
      if student_list.present?
        render json: BxBlockStudent::FeeReceivablesSerializer.new(student_list, meta: { total_pages: student_list.total_pages, message: 'fee search list' }).serializable_hash,
               status: :ok
      else
        render json: { message: 'No fee receivables records' }, status: :not_found
      end
    end

    def fee_due_payment
      student_list = BxBlockStudent::Student.all.paginate(page: params[:page], per_page: 20)
      if student_list.present?
        render json: BxBlockStudent::FeeDueSerializer.new(student_list, meta: { total_pages: student_list.total_pages, message: 'fee search list' }).serializable_hash,
               status: :ok
      else
        render json: { message: 'No fee due payment records' }, status: :not_found
      end
    end

    private

    def set_student
      @student =  Student.find_by(id: params[:id])
      render json: {message:"Student not found"}, :status => :not_found unless @student.present?
    end

    def student_params
      params.require(:student).permit(:first_name, :last_name, :father_name, :mother_name , :division_id, :image, :dob, :gender  ,:registration_no, :roll_no)
    end
  end
end
