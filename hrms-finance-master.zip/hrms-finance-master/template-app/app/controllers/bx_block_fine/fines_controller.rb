module BxBlockFine
  class FinesController < ApplicationController
    before_action :set_fine, only: %i[update show destroy]

    def index
      fines = Fine.where("fine_id is null").order("created_at DESC").paginate(page: params[:page], per_page: 20)
      if fines.present?
        render json: FineSerializer.new(fines, meta: { total_pages: fines.total_pages, message: 'Fines list' }).serializable_hash,
               status: :ok
      else
        render json: {message:"No records."}, status: :ok
      end
    end

    def fines_list
      fines = Fine.where("fine_id is null")
      if fines.present?
        render json: FineSerializer.new(fines, meta: { message: 'Fines list' }).serializable_hash,
               status: :ok
      else
        render json: {message:"No records."}, status: :ok
      end
    end

    def create
      fine = BxBlockFine::Fine.new(fine_update_params)
      if fine.save
        fine.sub_fines.create(sub_fines_params) if fine.late_fine?
        render json: FineSerializer.new(fine, meta: {
                                          message: 'Fine successfully Created.'
                                        }).serializable_hash, status: :created
      else
        render json: { errors: format_activerecord_errors(fine.errors) }, status: :unprocessable_entity
      end
    end

    def update
      if @fine.update(fine_update_params)
        render json: FineSerializer.new(@fine, meta: { message: 'Fine successfully Updated.' }).serializable_hash,
               status: :ok
      else
        render json: { errors: format_activerecord_errors(@fine.errors) }, status: :unprocessable_entity
      end
    end

    def bulk_update
      fines = Fine.where(id: params[:ids])
      if fines.any?
        begin
          fines.update_all(fine_category: params[:fine_category])
          render json: FineSerializer.new(fines, meta: {message: "Fines successfully Updated."}).serializable_hash, status: :created
        rescue => e
          render json: { error: e }
        end
      else
        render json: {message:"No records."}, status: :not_found
      end
    end

    def show
      render json: FineSerializer.new(@fine, meta: { message: 'Fine Details.' }).serializable_hash, status: :ok
    end

    def destroy
      if @fine.destroy
        render json: { message: 'Fine was successfully destroyed.' }, status: :ok
      else
        render json: { errors: @fine.errors }, status: :unprocessable_entity
      end
    end

    def bulk_destroy
      fines = Fine.where(id: params[:ids].split(","))
      return render json: {message:"No records."}, status: :not_found unless fines.any?
      if fines.destroy_all
        render json: { message: 'Fines was successfully destroyed.' }, status: :ok
      else
        render json: { errors: fines.errors }, status: :unprocessable_entity
      end
    end

    def import
      if CSV.read(params[:file].path)[0].empty?
        return render json: { common_error: 'File is empty.' }, status: :not_found
      end
      unless (%w[name fine_category day duration fine_amount mode] - CSV.open(params[:file].path, &:readline)).empty?
        return render json: { common_error: 'Invalid headers' }, status: :not_found
      end
      if CSV.read(params[:file].path)[1].empty?
        return render json: { common_error: 'No records in CSV.' }, status: :not_found
      end
      invaild_data = BxBlockFine::Fine.import(params[:file])
      if invaild_data.present?
        respond_to do |format|
            format.csv { send_data generate_csv(invaild_data), filename: "invaild_data_of_fines.csv" }
        end
      else
        render json: { message: 'All fines are imported successfully.' }, status: :ok
      end
    end

    def export
      csv_data = BxBlockFine::Fine.all.order(:id)
      respond_to do |format|
        format.csv { send_data csv_data.to_csv, filename: "fine-#{DateTime.now}.csv" }
      end
    end

    def csv_sample_file
      send_file(
        "#{Rails.root}/app/assets/csv_files/sample_file_for_fines.csv",
        filename: "sample_file_for_fines.csv"
      )
    end

    def filter
      fines = Fine.all
      fines = fines.where("name ILIKE ?", "%#{params[:name].strip}%") if params[:name].present?
      # fines = fines.where(mode: params[:mode]) if params[:mode].present?
      fines = fines.where(fine_category: params[:fine_category]) if params[:fine_category].present?
      if params[:start_range].present? && params[:end_range].present?
        fines = fines.where(fine_amount: params[:start_range].to_i..params[:end_range].to_i)
      end
      fines = fines.paginate(page: params[:page], per_page: 20)
      if fines.present?
        render json: FineSerializer.new(fines, meta: { total_pages: fines.total_pages, message: ' Fine filtered list' }).serializable_hash,
               status: :ok
      else
        render json: { message: 'No records.' }, status: :not_found
      end
    end

    def search
      fines = BxBlockFine::Fine.where('name ILIKE ?', "%#{params[:name]}%").paginate(page: params[:page], per_page: 20)
      if fines.present?
        render json: FineSerializer.new(fines, meta: { total_pages: fines.total_pages, message: 'Fine search list' }).serializable_hash,
               status: :ok
      else
        render json: { message: 'No records.' }, status: :not_found
      end
    end

    private

    def fine_params
      params.require(:fine).permit(:name, :day, :duration, :fine_amount, :mode, :fine_category)
    end

    def sub_fines_params
      params.require(:fine)[:sub_fines_attributes].as_json
    end

    def fine_update_params
      params.require(:fine).permit(:name, :day, :duration, :fine_amount, :mode, :fine_category, sub_fines_attributes: [:id, :name, :day, :duration, :fine_amount, :mode, :fine_category])
    end

    def set_fine
      @fine = Fine.find(params[:id])
      render json: { message: 'Record not found' }, status: :not_found unless @fine.present?
    end

    def generate_csv(data)
      attributes = BxBlockFine::Fine::CSV_HEADERS + ['errors'] - ["id"]
      CSV.generate(headers: true) do |csv|
        csv << attributes
        data.each do |role|
          csv << role.to_h
        end
      end
    end
  end
end

