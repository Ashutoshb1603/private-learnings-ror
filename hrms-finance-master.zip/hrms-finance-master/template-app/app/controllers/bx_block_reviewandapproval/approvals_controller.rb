module BxBlockReviewandapproval 
  class ApprovalsController < ApplicationController
    before_action :find_approvals,only:[:show,:update,:destroy,:individual_deletion,:individual_updation ]
    # skip_before_action :validate_json_web_token

    def index
      @approvals = BxBlockReviewandapproval::Approval.all.select(:id,:module_name,:approval_name,:created_at,:updated_at).paginate(page: params[:page], per_page: 20)
      render json: {data: @approvals,status: 200}
    end 

    def show
      render json: {data: BxBlockReviewandapproval::ApprovalSerializer.new(@approval),status: 200}
    end 

    def create
      @approval = BxBlockReviewandapproval::Approval.new(permit_params)
      if @approval.save
        if params[:data][:rules].present?
          create_rules(params[:data][:rules],@approval.id)
        end
        if params[:data][:approvars].present?
          create_approvars(params[:data][:approvars],@approval.id)
        end 
        render json: {data: BxBlockReviewandapproval::ApprovalSerializer.new(@approval),status: 200}
      else
        render json: {errors: @approval.errors.full_messages,status: 404}
      end 
    end

    def update
      if @approval.update(permit_params)
        if params[:data][:rules].present?
          update_rules(params[:data][:rules],@approval.id)
        end
        if params[:data][:approvars].present?
          update_approvars(params[:data][:approvars],@approval.id)
        end 
        render json: {data: BxBlockReviewandapproval::ApprovalSerializer.new(@approval) ,status: 200}
      else
        render json: {errors: @approval.errors.full_messages,status: 404}
      end
    end

    def destroy
      if @approval.destroy
        render json: {message: "approval deleted sucessfully",status:200}
      end 
    end 

    def individual_updation
      # return render json: {message: "this is an optional api for updating individual models"}
      # unless params.dig(:ids,:approvar_id).nil?
      #   approvar = @approval.approvars.includes(:approvar_tasks,:approvar_actions).find(params.dig(:ids,:approvar_id))
      #   if approvar.present?
      #     if params.dig(:ids,:task_id).present?
      #       task =  approvar.approvar_tasks.find(params.dig(:ids,:task_id))
      #       return render json: {data: "task deleted sucessfully"} if task.destroy
      #     elsif params.dig(:ids,:action_id).present?
      #       action =  approvar.approvar_actions.find(params.dig(:ids,:action_id))
      #       return render json: {data: "action deleted sucessfully"} if action.destroy
      #     else 
      #       return render json: {data: "approval deleted sucessfully"} if approvar.destroy
      #     end    
      #   end 
      # end 
  
      # unless params.dig(:ids,:rule_id).nil?
      #   rule = @approval.rules.find(params.dig(:ids,:rule_id))
      #   if rule.present?
      #     return render json: {data: "rule deleted sucessfully"} if rule.destroy
      #   end 
      # end 
    end 

    def individual_deletion
      unless params.dig(:ids,:approvar_id).nil?
        approvar = @approval.approvars.includes(:approvar_tasks,:approvar_actions).find(params.dig(:ids,:approvar_id))
        if approvar.present?
          if params.dig(:ids,:task_id).present?
            task =  approvar.approvar_tasks.find(params.dig(:ids,:task_id))
            return render json: {data: "task deleted sucessfully"} if task.destroy
          elsif params.dig(:ids,:action_id).present?
            action =  approvar.approvar_actions.find(params.dig(:ids,:action_id))
            return render json: {data: "action deleted sucessfully"} if action.destroy
          else 
            return render json: {data: "approval deleted sucessfully"} if approvar.destroy
          end    
        end 
      end 
  
      unless params.dig(:ids,:rule_id).nil?
        rule = @approval.rules.find(params.dig(:ids,:rule_id))
        if rule.present?
          return render json: {data: "rule deleted sucessfully"} if rule.destroy
        end 
      end 
    end

    private
      def permit_params
        params.require(:data).permit(:module_name,:approval_name, :execution_on, :description)
      end 

      def find_approvals
        @approval = BxBlockReviewandapproval::Approval.includes(:approvars,:rules).find(params[:id])
        if @approval.nil?
          render json: {message: "no approval were found"}
        end 
      end

      # create approvals
      def create_rules(values,approval_id)
        values.each do |value|
          BxBlockReviewandapproval::Rule.create!(value.permit(:field_name,:criteria,:value).merge(approval_id:approval_id)) 
        end  
      end

      def create_approvars(values,approval_id)
        values[:approvars_data].each do |value| 
          @approvar = BxBlockReviewandapproval::Approvar.create!(approvar_type: value[:approvar_type],approvar_name: value[:approvar_name],approval_id: approval_id, description: value[:description]) 
          create_task(value[:approvar_tasks],@approvar.id) unless value[:approvar_tasks].nil?
          create_actions(value[:approvar_action],@approvar.id) unless value[:approvar_action].nil?       
        end  
      end

      def create_task(values,approvar_id)
        values.each do |value|
          BxBlockReviewandapproval::ApprovarTask.create!(value.permit(:task_name,:due_date,:status,:notify_assignee,:remined_assignee,:notify_mode,:description,alert_mode:{},remined_on:{}).merge(approvar_id:approvar_id))
        end
      end 

      def create_actions(values,approvar_id)
        values.each do |value|
          BxBlockReviewandapproval::ApprovarAction.create(value.permit( :work_flow_status, :description, :send_email_to).merge( {approvar_id: approvar_id}))
        end 
      end

      #update approvals
      def update_rules(values,approval_id)
        values.each do |value|
          if value[:id].nil?
            # create_rules(value,approval_id)
            BxBlockReviewandapproval::Rule.create!(value.permit(:field_name,:criteria,:value).merge(approval_id:approval_id))
          else 
            rule = BxBlockReviewandapproval::Rule.find(value[:id])
            rule.update!(value.permit(:field_name,:criteria,:value).merge(approval_id:approval_id)) 
          end 
        end  
      end

      def update_approvars(values,approval_id)
        values.each do |value|                      
          if value[:id].nil? 
            create_approvars(value,approval_id)
          else
            approvar = BxBlockReviewandapproval::Approvar.find(value[:id])
            approvar.update!(approvar_type: value[:approvar_type],approvar_name: value[:approvar_name],approval_id: approval_id, description: value[:description]) 
            update_task(value[:approvar_tasks],approvar.id) unless value[:approvar_tasks].nil?
            update_actions(value[:approvar_action],approvar.id) unless value[:approvar_action].nil?
          end 
        end  
      end

      def update_task(values,approvar_id)
        values.each do |value|
          if value[:id].nil?
            # create_task(value,approvar_id)
            BxBlockReviewandapproval::ApprovarTask.create!(value.permit(:task_name,:due_date,:status,:notify_assignee,:remined_assignee,:notify_mode,:description,alert_mode:{},remined_on:{}).merge(approvar_id:approvar_id))
          else 
            task =  BxBlockReviewandapproval::ApprovarTask.find(value[:id])
            task.update!(value.permit(:task_name,:due_date,:status,:notify_assignee,:remined_assignee,:notify_mode,:description,alert_mode:{},remined_on:{}).merge(approvar_id:approvar_id))
          end 
        end
      end 
      
      def update_actions(values,approvar_id)
        values.each do |value|
          if value[:id].nil?
            BxBlockReviewandapproval::ApprovarAction.create(value.permit( :work_flow_status, :description, :send_email_to).merge( {approvar_id: approvar_id}))
          else
            action = BxBlockReviewandapproval::ApprovarAction.find(value[:id])
            action.update!(value.permit( :work_flow_status, :description, :send_email_to))
          end 
        end 
      end

  end
end
