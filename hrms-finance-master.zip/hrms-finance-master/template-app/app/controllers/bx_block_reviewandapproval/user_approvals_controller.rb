module BxBlockReviewandapproval 
  class UserApprovalsController < ApplicationController
    before_action :find_student ,only: [:show,:update]
    def index
      @students = BxBlockStudent::Student.includes(division: [academic_class: :academic_year]).paginate(page: params[:page], per_page: 20)
      render json: BxBlockReviewandapproval::UserApprovalSerializer.new(@students)
    end

    def show 
      render json: resp_hash_for_individual(@student)
    end
    
    def update
      if @student.update(status: params[:status])
        render json: {message: "status updated sussefully to #{params[:status]}"}
      else 
        render json: {errors: @student.errors.full_messages}
      end 
    end 

    private
      def resp_hash_for_individual(student)
        {
         fee_assignment: BxBlockReviewandapproval::UserApprovalSerializer.new(student),
         fee_structure: student.division.academic_class.academic_year.fee_structures,
         installment: student.division.academic_class.academic_year.fee_structures.includes(:installments).map(&:installments)
        }
      end 

      def find_student
      @student = BxBlockStudent::Student.includes(division: [academic_class: :academic_year]).find(params[:id])
         if @student.nil?
           return render json: {error: "student not found"}
         end 
      end 
  end  
end
