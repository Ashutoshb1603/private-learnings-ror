module BxBlockInstallment
  class InstallmentsController < ApplicationController
    before_action :current_user
    before_action :set_installment, only: [:update,:show, :destroy]

    def index
      installments = Installment.order("created_at DESC").paginate(page: params[:page], per_page: 20)
      if installments.present?
        render json: InstallmentSerializer.new(installments, meta: {total_pages: installments.total_pages, message: "Installment lists"}).serializable_hash, status: :ok
      else
        render json: {message:"No records."}, status: :ok
      end
    end

    def create
      installment = BxBlockInstallment::Installment.new(installment_params)
      if installment.save
        render json: InstallmentSerializer.new(installment, meta: {message: "Installment successfully Created."}).serializable_hash, status: :created
      else
        render json: {errors: format_activerecord_errors(installment.errors)}, status: :unprocessable_entity
      end
    end

    def import
      csv_data = BxBlockInstallment::Installment.import(params[:file])
      render json: {message: "Installment data is successfully Imported"}, status: :created
    end

    def export
      csv_data = BxBlockInstallment::Installment.all
      respond_to do |format|
        format.csv { send_data csv_data.to_csv, filename: "Installment-#{DateTime.now}.csv" }
      end
    end

    def update
      if @installment.update(installment_params)
        render json: InstallmentSerializer.new(@installment, meta: {message: "Installment successfully Updated."}).serializable_hash, status: :created
      else
        render json: {errors: format_activerecord_errors(@installment.errors)}, status: :unprocessable_entity
      end 
    end

    def show
      render json: InstallmentSerializer.new(@installment, meta: {message: "Installment Details."}).serializable_hash, status: :created
    end

    def destroy
      @installment.destroy
      render json: {message:"Installment was successfully destroyed."}, status: :ok
    end

    private

    def set_installment
      @installment =  Installment.find_by(id: params[:id])
      render json: {message:"Installment not found"}, :status => :not_found unless @installment.present?
    end

    def installment_params
      params.require(:installment).permit(:name, :duration_no, :duration, :description)
    end
  end
end
