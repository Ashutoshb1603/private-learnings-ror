module BxBlockTax
  class TaxesController < ApplicationController
    before_action :current_user
    before_action :set_tax, only: [:update,:show, :destroy]

    def index
      taxes = Tax.order("created_at DESC").paginate(page: params[:page], per_page: 20)
      if taxes.present?
        render json: TaxSerializer.new(taxes, meta: {tax_type: [:SGST, :CGST, :IGST, :UTGST],total_pages: taxes.total_pages, message: "Tax lists"}).serializable_hash, status: :ok
      else
        render json: {message:"No records."}, status: :ok
      end
    end

    def create
      if params[:tax][:is_gst]
        # return render json: {errors: {message: ["Please select tax type"]}}, status: :unprocessable_entity unless params[:tax][:tax_type].present?
        # return render json: {errors: {message: ["Please add valid tax type"]}}, status: :unprocessable_entity unless Tax.tax_types.keys.include?(params[:tax][:tax_type])
      end
      return render json: {errors: {message: ["Please enter name"]}}, status: :unprocessable_entity unless params[:tax][:name].present?
      return render json: {errors: {message: ["Please enter tax %"]}}, status: :unprocessable_entity unless params[:tax][:tax_percentage].present?
      tax = BxBlockTax::Tax.new(tax_params)
      if tax.save
        render json: TaxSerializer.new(tax, meta: {message: "Tax successfully Created."}).serializable_hash, status: :created
      else
        render json: {errors: tax.errors}, status: :unprocessable_entity
      end
    end

    def update
      if @tax.update(tax_params)
        render json: TaxSerializer.new(@tax, meta: {message: "Tax successfully Updated."}).serializable_hash, status: :created
      else
        render json: {errors: @tax.errors}, status: :unprocessable_entity
      end 
    end

    def bulk_update
      taxes = Tax.where(id: params[:ids])
      if taxes.any?
        begin
          taxes.update_all(tax_type: params[:tax_type])
          render json: TaxSerializer.new(taxes, meta: {message: "Taxes successfully Updated."}).serializable_hash, status: :created
        rescue => e
          render json: {errors: {message: [e]}}, status: :unprocessable_entity
        end
      else
        render json: {message:"No records."}, status: :not_found
      end
    end

    def show
      render json: TaxSerializer.new(@tax, meta: {message: "Tax Details."}).serializable_hash, status: :created
    end

    def destroy
      @tax.destroy
      render json: {message:"Tax was successfully destroyed."}, status: :ok
    end

    def bulk_destroy
      taxes = Tax.where(id: params[:ids].split(","))
      return render json: {message:"No records."}, status: :not_found unless taxes.any?
      if taxes.destroy_all
        render json: { message: 'Taxes was successfully destroyed.' }, status: :ok
      else
        render json: { errors: taxes.errors }, status: :unprocessable_entity
      end
    end

    def filter
      @taxes = BxBlockTax::Tax.all
      if params[:name].present? 
        # @taxes = @taxes.where(name: params[:name])
        @taxes = @taxes.where("name ILIKE ?", "%#{params[:name].strip}%")
      end
      if params[:tax_type].present? 
        @taxes = @taxes.where(tax_type: params[:tax_type])
      end
      if params[:start_range].present? && params[:end_range].present?
        @taxes = @taxes.where(tax_percentage: params[:start_range].to_i..params[:end_range].to_i)
      end
      @taxes = @taxes.paginate(page: params[:page], per_page: 20)
      render json: TaxSerializer.new(@taxes, meta: {message: "Tax lists", total_pages: @taxes.total_pages}).serializable_hash, status: :ok
    end

    def import
      if CSV.read(params[:file].path).empty? || CSV.read(params[:file].path)[0].empty?
        return render json: { common_error: 'No records in CSV.' }, status: :not_found
      end
      unless CSV.foreach(params[:file], headers: true).count >= 1
        return render json: { common_error: 'No records in CSV.' }, status: :not_found
      end
      unless (["Tax Name", "Is GST?", "Tax Type", "Tax%"] - CSV.open(params[:file].path, &:readline)).empty?
        return render json: { common_error: 'Invalid headers' }, status: :not_found
      end
      begin
        invaild_data = csv_data = Tax.import(params[:file])
        if invaild_data.present?
          respond_to do |format|
            format.csv { send_data generate_csv(invaild_data), filename: "invaild_data_of_tax.csv" }
          end
        else
          render json: {message: "All Taxes are imported successfully."}, status: :ok
        end
      rescue => e
        e.to_s.slice!("Validation failed: Name") if e.to_s.include?("Validation failed: Name")
        render json: { error: e }
      end
    end

    def tax_csv_sample_file
      csv_data = Tax.order(:id).limit(3)
      respond_to do |format|
        format.csv { send_data csv_data.to_sample_csv, filename: "sample_file_for_tax.csv" }
      end
    end

    def export
      csv_data = BxBlockTax::Tax.all.order(:id)
      respond_to do |format|
        format.csv { send_data csv_data.to_csv, filename: "Tax-#{DateTime.now}.csv" }
      end
    end

    def tax_rate_names
      render json: TaxNamesSerializer.new(Tax.order("created_at DESC"), meta: {tax_type: [:SGST, :CGST, :IGST, :UTGST]}).serializable_hash, status: :ok
      # render json: {tax_name: Tax.all.map(&:name), tax_type: [:SGST, :CGST, :IGST, :UTGST]}, status: :ok
    end

    def search
      taxs = Tax.where('name ILIKE ?', "%#{params[:name].strip}%").or(Tax.where(tax_percentage: params[:name])).paginate(page: params[:page], per_page: 20)
      if taxs.present?
        render json: TaxSerializer.new(taxs, meta: { total_pages: taxs.total_pages, message: 'tax search list' }).serializable_hash, status: :ok
      else
        render json: { message: 'No records.' }, status: :not_found
      end
    end

    private

    def set_tax
      @tax =  Tax.find_by(id: params[:id])
      render json: {message:"tax not found"}, :status => :not_found unless @tax.present?
    end

    def tax_params
      params.require(:tax).permit(:name, :tax_percentage, :description, :tax_type, :is_gst)
    end

    def generate_csv(data)
      attributes = ["Tax Name", "Tax%", "Tax Type", "Description", "Error"]
      CSV.generate(headers: true) do |csv|
        csv << attributes
        data.each do |acad_account|
          csv << acad_account.to_h
        end
      end
    end
  end
end
