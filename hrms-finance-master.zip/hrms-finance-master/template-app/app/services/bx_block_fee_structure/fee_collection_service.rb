module BxBlockFeeStructure
  class FeeCollectionService

    CSV_HEADER = %w[full_name class_name division total_amount fee_structure installments fee_name amount
          concession_type concession concession_mode amount_after_concession]

    def export_csv(fee_collection)
      attributes = CSV_HEADER
      CSV.generate(headers: true) do |csv|
        csv << attributes
        fee_collection.each do |fc|
          fc[:fee_structures][:data][:attributes][:sub_fee_structures].as_json['data'] rescue next
          
          fc[:fee_structures][:data][:attributes][:sub_fee_structures].as_json['data'].each do |sfc|
            fee_structure_data = fc[:fee_structures][:data][:attributes] rescue nil
            school_class = fc['attributes']['school_class']['data']['attributes'] rescue nil
            concession_data = sfc['attributes']['concession']['data']['attributes'] rescue nil
            sfc_data = sfc['attributes'] rescue nil

            full_name = fc['attributes']['first_name'] rescue nil
            class_name = school_class['class_name'] rescue nil
            division = school_class['divisions']['data']['attributes']['name'] rescue nil
            total_amount = fee_structure_data[:total_amount] rescue nil
            fee_structure = fee_structure_data[:name] rescue nil
            installments = fee_structure_data[:installment].as_json['data'].first['attributes']['name'] rescue nil
            fee_name = sfc_data['fee_name'] rescue nil
            amount = sfc_data['amount'] rescue nil
            concession_type = concession_data['fee_concession_type']['data']['attributes']['name'] rescue nil
            concession = concession_data['amount'] rescue nil
            concession_mode = concession_data['mode'] rescue nil
            amount_after_concession = sfc_data['amount_after_concession'] rescue nil

            csv << [full_name, class_name, division, total_amount, fee_structure, installments, fee_name, amount,
                concession_type, concession, concession_mode, amount_after_concession]
          end
        end
      end
    end
  
  end
end
