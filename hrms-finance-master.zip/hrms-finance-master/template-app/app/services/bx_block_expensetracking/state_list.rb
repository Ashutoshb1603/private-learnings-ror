module BxBlockExpensetracking
  class StateList
      def self.states
        return {"AN": "Andaman and Nicobar","AP": "Andhra Pradesh","AR": "Arunachal Pradesh","AS": "Assam","BR": "Bihar","CH": "Chandigarh","CT": "Chhattisgarh","DD": "Daman and Diu","DL": "National Capital Territory of Delhi","DN": "Dadra and Nagar Haveli","GA": "Goa","GJ": "Gujarat","HP": "Himachal Pradesh","HR": "Haryana","JH": "Jharkhand","JK": "Jammu and Kashmir","KA": "Karnataka","KL": "Kerala","LA": "Ladakh","LD": "Lakshadweep","MH": "Maharashtra","ML": "Meghalaya","MN": "Manipur","MP": "Madhya Pradesh","MZ": "Mizoram","NL": "Nagaland","OR": "Odisha","PB": "Punjab","PY": "Union Territory of Puducherry","RJ": "Rajasthan","SK": "Sikkim","TG": "Telangana","TN": "Tamil Nadu","TR": "Tripura","UP": "Uttar Pradesh","UT": "Uttarakhand","WB": "West Bengal"    }
      end 
  end 
end
