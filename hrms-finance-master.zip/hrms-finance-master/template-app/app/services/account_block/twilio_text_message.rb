module AccountBlock
  class TwilioTextMessage
    attr_reader :message, :to

    def initialize(to, message)
      #@to      = to
      @to      = '+' + to.to_s
      @message = message
    end

    def call
      #client = Twilio::REST::Client.new
      client = Twilio::REST::Client.new(ENV["TWILIO_ACCOUNT_SID"], ENV["TWILIO_AUTH_TOKEN"])
      client.messages.create({
        #from: Rails.application.credentials.twilio_phone_number,
        from: ENV["TWILIO_PHONE_NUMBER"],
        to: @to,
        body: @message
      })
    rescue => e
      e.message
    end
  end
end
