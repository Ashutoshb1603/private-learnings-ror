module BxBlockDashboard
    class DashboardService

    end
end
  