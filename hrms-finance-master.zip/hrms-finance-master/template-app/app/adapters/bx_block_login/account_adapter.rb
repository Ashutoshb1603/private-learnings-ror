module BxBlockLogin
  class AccountAdapter
    include Wisper::Publisher

    def login_account(account_params)
      case account_params.type
      when 'sms_account'
        phone_number = account_params['full_phone_number']
        phone_number = phone_number.gsub("+", "")
        phone_number = phone_number.gsub(" ", "")
        # if phone_number.include?("91")
        #   full_phone_number = phone_number
        # else
        #   full_phone_number = "91" + phone_number
        # end
        full_phone_number = phone_number
        phone = Phonelib.parse(full_phone_number).sanitized
        account = AccountBlock::Account.find_by("full_phone_number = ? or phone_number = ?", phone, phone)
      when 'email_account'
        email = account_params.email.downcase

        account = AccountBlock::Account
          .where('LOWER(email) = ?', email)
          .where(:activated => true)
          .first
      when 'social_account'
        account = AccountBlock::SocialAccount.find_by(
          email: account_params.email.downcase,
          unique_auth_id: account_params.unique_auth_id,
          activated: true)
      end

      unless account.present? && account.activated?
        broadcast(:account_not_found)
        return
      end

      if account.authenticate(account_params.password)
        token = BuilderJsonWebToken.encode(account.id)
        broadcast(:successful_login, account, token)
      else
        broadcast(:failed_login)
      end
    end
  end
end
