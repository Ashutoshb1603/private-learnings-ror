# **Ruby** | _**21KSchoolHRMSFinance**_ | _**51700** | _**studio_pro**_

## **Catalog ProjectId: 45877** | **Catalog BuildId: 18246**

## NOTE FOR DEVELOPERS:
Clone the code-engine branch into your working branch. The contents of the branch may get overwritten.
## Author:
Code-Engine
## Assembled Features To Block Status

| **Feature-Name**        | **Block-Name**        | **Path**  | **Status**  |
|:-------------|:-------------|:-------------|:-------------|
| EmailSignIn2      | account_block<br>      | {+app/controllers/account_block+}<br> | {+Non-Empty+} |
| UserGroups2      | bx_block_account_groups<br>bx_block_admin<br>bx_block_roles_permissions<br>bx_block_login<br>account_block<br>bx_block_sms<br>      | {+app/controllers/bx_block_account_groups+}<br>{+app/controllers/bx_block_admin+}<br>{+app/controllers/bx_block_roles_permissions+}<br>{+app/controllers/bx_block_login+}<br>{+app/controllers/account_block+}<br>{++}<br> | {+Non-Empty+} |
| GraphicalCharts      | bx_block_visual_analytics<br>bx_block_followers<br>bx_block_login<br>account_block<br>bx_block_sms<br>      | {++}<br>{+app/controllers/bx_block_followers+}<br>{+app/controllers/bx_block_login+}<br>{+app/controllers/account_block+}<br>{++}<br> | {+Non-Empty+} |
| AdminConsole2      | bx_block_admin<br>      | {+app/controllers/bx_block_admin+}<br> | {+Non-Empty+} |
| AdHocReporting      | bx_block_visual_analytics<br>bx_block_followers<br>bx_block_login<br>account_block<br>bx_block_sms<br>      | {++}<br>{+app/controllers/bx_block_followers+}<br>{+app/controllers/bx_block_login+}<br>{+app/controllers/account_block+}<br>{++}<br> | {+Non-Empty+} |
| PaymentAdmin      | bx_block_payment_admin<br>account_block<br>bx_block_sms<br>      | {+app/controllers/bx_block_payment_admin+}<br>{+app/controllers/account_block+}<br>{++}<br> | {+Non-Empty+} |
| Payments      | bx_block_payments<br>      | {+app/controllers/bx_block_payments+}<br> | {+Non-Empty+} |
| CustomForm2      | bx_block_custom_form<br>bx_block_login<br>account_block<br>bx_block_sms<br>      | {+app/controllers/bx_block_custom_form+}<br>{+app/controllers/bx_block_login+}<br>{+app/controllers/account_block+}<br>{++}<br> | {+Non-Empty+} |
| Scheduling2      | bx_block_scheduling<br>bx_block_calendar<br>bx_block_appointment_management<br>bx_block_login<br>account_block<br>bx_block_sms<br>bx_block_roles_permissions<br>      | {+app/controllers/bx_block_scheduling+}<br>{+app/controllers/bx_block_calendar+}<br>{+app/controllers/bx_block_appointment_management+}<br>{+app/controllers/bx_block_login+}<br>{+app/controllers/account_block+}<br>{++}<br>{+app/controllers/bx_block_roles_permissions+}<br> | {+Non-Empty+} |
| AdvancedSearch      | bx_block_advanced_search<br>bx_block_custom_form<br>bx_block_login<br>account_block<br>bx_block_sms<br>      | {+app/controllers/bx_block_advanced_search+}<br>{+app/controllers/bx_block_custom_form+}<br>{+app/controllers/bx_block_login+}<br>{+app/controllers/account_block+}<br>{++}<br> | {+Non-Empty+} |
| EmployeeLogin      | account_block<br>bx_block_login<br>bx_block_forgot_password<br>bx_block_sms<br>      | {+app/controllers/account_block+}<br>{+app/controllers/bx_block_login+}<br>{+app/controllers/bx_block_forgot_password+}<br>{++}<br> | {+Non-Empty+} |
| SingleSignonsso2      | account_block<br>bx_block_login<br>      | {+app/controllers/account_block+}<br>{+app/controllers/bx_block_login+}<br> | {+Non-Empty+} |
| OrganisationHierarchy      | bx_block_organisationhierarchy      | {-app/controllers/bx_block_organisationhierarchy-} | {-Empty-} |
| GoalManagement      | bx_block_goalmanagement      | {-app/controllers/bx_block_goalmanagement-} | {-Empty-} |
| JobListing2      | bx_block_joblisting2      | {-app/controllers/bx_block_joblisting2-} | {-Empty-} |
| ApiIntegration18      | bx_block_apiintegration18      | {-app/controllers/bx_block_apiintegration18-} | {-Empty-} |
| CvresumeCandidateManagement2      | bx_block_cvresumecandidatemanagement2      | {-app/controllers/bx_block_cvresumecandidatemanagement2-} | {-Empty-} |
| InvoiceBilling      | bx_block_invoicebilling      | {-app/controllers/bx_block_invoicebilling-} | {-Empty-} |
| Referrals      | bx_block_referrals      | {-app/controllers/bx_block_referrals-} | {-Empty-} |
| PeopleManagement2      | bx_block_peoplemanagement2      | {-app/controllers/bx_block_peoplemanagement2-} | {-Empty-} |
| AcceptPrepayments2      | bx_block_acceptprepayments2      | {-app/controllers/bx_block_acceptprepayments2-} | {-Empty-} |
| GstIntegration2      | bx_block_gstintegration2      | {-app/controllers/bx_block_gstintegration2-} | {-Empty-} |
| CentralisedBilling      | bx_block_centralisedbilling      | {-app/controllers/bx_block_centralisedbilling-} | {-Empty-} |
| TaxCalculator      | bx_block_taxcalculator      | {-app/controllers/bx_block_taxcalculator-} | {-Empty-} |
| StripeGatewayApiFrontend      | bx_block_stripegatewayapifrontend      | {-app/controllers/bx_block_stripegatewayapifrontend-} | {-Empty-} |
| SpendAnalysis      | bx_block_spendanalysis      | {-app/controllers/bx_block_spendanalysis-} | {-Empty-} |
| BudgetingForecasting      | bx_block_budgetingforecasting      | {-app/controllers/bx_block_budgetingforecasting-} | {-Empty-} |
| ExpenseTracking      | bx_block_expensetracking      | {-app/controllers/bx_block_expensetracking-} | {-Empty-} |
| PasswordProtectedPages      | bx_block_passwordprotectedpages      | {-app/controllers/bx_block_passwordprotectedpages-} | {-Empty-} |
| DataEncryption      | bx_block_dataencryption      | {-app/controllers/bx_block_dataencryption-} | {-Empty-} |
| AutomaticReminders      | bx_block_automaticreminders      | {-app/controllers/bx_block_automaticreminders-} | {-Empty-} |
| ReviewAndApproval      | bx_block_reviewandapproval      | {-app/controllers/bx_block_reviewandapproval-} | {-Empty-} |
| LeaveTracker      | bx_block_leavetracker      | {-app/controllers/bx_block_leavetracker-} | {-Empty-} |
| TeamBuilder      | bx_block_teambuilder      | {-app/controllers/bx_block_teambuilder-} | {-Empty-} |
| BreadcrumbNavigation      | bx_block_breadcrumbnavigation      | {-app/controllers/bx_block_breadcrumbnavigation-} | {-Empty-} |
| PayrollIntegration2      | bx_block_payrollintegration2      | {-app/controllers/bx_block_payrollintegration2-} | {-Empty-} |
| AccountTransfer      | bx_block_accounttransfer      | {-app/controllers/bx_block_accounttransfer-} | {-Empty-} |
| PerformanceTracker      | bx_block_performancetracker      | {-app/controllers/bx_block_performancetracker-} | {-Empty-} |
| TabletSupport64      | bx_block_tabletsupport64      | {-app/controllers/bx_block_tabletsupport64-} | {-Empty-} |
| FeedbackCollection      | bx_block_feedbackcollection      | {-app/controllers/bx_block_feedbackcollection-} | {-Empty-} |
| MultilevelApproval      | bx_block_multilevelapproval      | {-app/controllers/bx_block_multilevelapproval-} | {-Empty-} |
| SummaryCard      | bx_block_summarycard      | {-app/controllers/bx_block_summarycard-} | {-Empty-} |
| CollectTransactionFees      | bx_block_collecttransactionfees      | {-app/controllers/bx_block_collecttransactionfees-} | {-Empty-} |

## GRAFANA BACKEND URL
 - https://grafana.<\<error-empty-cat-url>>

This application is a Ruby API. Full README coming soon...
